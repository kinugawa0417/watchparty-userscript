// KINUGAWA Party Theater 1.1.0（配布用）
/**
 * YouTube アダプタ。
 *
 * youtube.com のページには `#movie_player` があり、そこに操作用の関数が生えている
 * （MAIN world で動いているので触れる）:
 *
 *   getCurrentTime() / getDuration()   … 秒
 *   seekTo(sec, allowSeekAhead)
 *   playVideo() / pauseVideo()
 *   getPlayerState()                   … 1=再生中 2=停止 3=読み込み 0=終了
 *   getAdState() / getVideoData()
 *
 * Netflix と違い、**時間は最初から秒**。広告は本編とは別の動画として流れるため、
 * Prime / Netflix のような「本編の時間への換算」は要らない（下の「広告」を参照）。
 *
 * YouTube は SPA で、動画を切り替えても `#movie_player` は作り直されない。
 * そのため掴み直しではなく、URL の v= が変わったかで作品の切り替えを見る。
 */
(() => {
    const Base = globalThis.WPAdapters.Base;

    // watch?v=ID、youtu.be/ID、/shorts/ID、/embed/ID。ID は11文字
    const YT_ID = /(?:[?&]v=|youtu\.be\/|\/shorts\/|\/embed\/)([A-Za-z0-9_-]{11})(?=[/?&#]|$)/;

    const RESCAN_MS = 1000;

    /*
     * シークの検出。
     * YouTube のプレイヤーでも、人がシークバーを動かしたときに <video> の seeked が
     * 出ないことがある。時計の進みと再生位置の進みを比べ、食い違ったらシークとみなす。
     * （Netflix アダプタと同じ考え方）
     */
    const WATCH_MS = 250;
    const JUMP_SEC = 2.0;
    const SEEK_DEDUPE_MS = 1000;

    // 再生状態（getPlayerState の戻り値）
    const ST_ENDED = 0, ST_PLAYING = 1, ST_PAUSED = 2, ST_BUFFERING = 3;

    /*
     * 広告。
     * YouTube の広告は**本編とは別の動画**として流れ、その間 getCurrentTime() は
     * 広告自身の時間（0秒から）を返す（本編の位置は進まない）。Prime / Netflix のように
     * 「広告の分を差し引いて本編の時間を出す」必要は無い。
     *
     * 広告中は本編の位置が分からないので、最後に読めた本編の位置を外に見せる。
     *
     * **広告かどうかは、時間を読むたびにその場で確かめる**（見回りの結果を使わない）。
     * 見回りを待つと、広告に入った直後の隙間で「1200秒→0秒に飛んだ＝シーク」と誤検出し、
     * 全員を 0 秒へ飛ばしてしまう（テストで実際に起きた）。
     */
    const AD_WATCH_MS = 250;

    class YouTubeAdapter extends Base {
        static get service() { return 'youtube'; }

        static match(url) {
            return /^https:\/\/(www|m|music)\.youtube\.com\//.test(url);
        }

        constructor() {
            super();
            this._player = null;
            this._video = null;
            this._detach = null;
            this._rescanTimer = null;
            this._watchTimer = null;
            this._adTimer = null;
            this._inAd = false;          // 記録（ad-start / ad-end）を出すための、前回の状態
            this._lastContentTime = 0;   // 広告でないときに最後に読めた本編の位置
            this._lastSeekAt = 0;
            this._lastWatch = null;
        }

        /** `#movie_player` に必要な関数が生えているか */
        static _usable(el) {
            return Boolean(el &&
                typeof el.getCurrentTime === 'function' &&
                typeof el.seekTo === 'function' &&
                typeof el.getPlayerState === 'function');
        }

        _find() {
            const el = document.getElementById('movie_player') ||
                document.querySelector('.html5-video-player');
            return YouTubeAdapter._usable(el) ? el : null;
        }

        async ready() {
            // 再生ボタンを押すまでプレイヤーが現れないことがあるので、期限なしで待つ
            this._player = await Base.waitFor(() => this._find(), { timeoutMs: Infinity });
            this._video = document.querySelector('#movie_player video, .html5-video-player video');
            this._bind();
            this._rescanTimer = setInterval(() => this._rescan(), RESCAN_MS);
            this._watchTimer = setInterval(() => this._watch(), WATCH_MS);
            this._adTimer = setInterval(() => this._watchAds(), AD_WATCH_MS);
        }

        /** SPA でプレイヤーが作り直されたら掴み直す */
        _rescan() {
            const found = this._find();
            if (found && found !== this._player) {
                this._player = found;
                this._video = document.querySelector('#movie_player video, .html5-video-player video');
                this._bind();
            }
        }

        _bind() {
            if (this._detach) this._detach();
            const v = this._video;
            if (!v) { this._detach = null; return; }
            // 広告の再生/停止は本編の操作ではないので送らない（その場で確かめる）
            const onPlay = () => { if (!this._detectAd()) this._emit('play'); };
            const onPause = () => { if (!this._detectAd()) this._emit('pause'); };
            const onSeeked = () => this._seekDetected();
            v.addEventListener('play', onPlay);
            v.addEventListener('pause', onPause);
            v.addEventListener('seeked', onSeeked);
            this._detach = () => {
                v.removeEventListener('play', onPlay);
                v.removeEventListener('pause', onPause);
                v.removeEventListener('seeked', onSeeked);
            };
        }

        /** seeked と「時間の飛び」の両方で気づくことがあるので、近い時刻のものは1回にまとめる */
        _seekDetected() {
            // 広告の出入りでも時間は飛ぶ。シークと取り違えないよう、その場で確かめる
            if (this._detectAd()) return;
            const now = Date.now();
            if (now - this._lastSeekAt < SEEK_DEDUPE_MS) return;
            this._lastSeekAt = now;
            this._emit('seek');
        }

        /** 時計の進みと再生位置の進みを比べ、食い違ったらシークとみなす */
        _watch() {
            // 広告中の時間は広告自身のもの。比べると必ず「飛んだ」ことになるので比べない
            if (!this._player || this._detectAd()) { this._lastWatch = null; return; }
            let t;
            try { t = this._player.getCurrentTime(); } catch { return; }
            this._lastContentTime = t;
            const now = Date.now();
            const prev = this._lastWatch;
            this._lastWatch = { t, at: now };
            if (!prev || this.isPaused()) return;
            const elapsed = (now - prev.at) / 1000;
            if (Math.abs((t - prev.t) - elapsed) > JUMP_SEC) this._seekDetected();
        }

        /**
         * 広告の出入りを記録する（ad-start / ad-end）。
         * 時間の扱いには使わない（そちらは読むたびに _detectAd() で確かめる）。
         */
        _watchAds() {
            const now = this._detectAd();
            if (now === this._inAd) return;
            this._inAd = now;
            if (!now) this._lastWatch = null;   // 広告明けの時間の飛びをシークと取り違えない
            this._reportDiag(now ? 'ad-start' : 'ad-end');
        }

        _detectAd() {
            const p = this._player;
            if (!p) return false;
            // プレイヤー自身が名乗る（ad-showing はクラス名として長く使われている）
            try {
                if (typeof p.getAdState === 'function' && p.getAdState() > 0) return true;
            } catch { /* 版によっては無い */ }
            return p.classList?.contains('ad-showing') ||
                p.classList?.contains('ad-interrupting') || false;
        }

        _raw() {
            try { return this._player ? this._player.getCurrentTime() : 0; } catch { return 0; }
        }

        // --- Base のインターフェース ------------------------------------------

        getCurrentTime() {
            // 広告中は本編が進まないので、最後に読めた本編の位置を見せ続ける。
            // 広告かどうかはその場で確かめる（見回りの結果を待つと隙間で 0 秒が漏れる）
            if (this._detectAd()) return this._lastContentTime;
            const t = this._raw();
            this._lastContentTime = t;
            return t;
        }

        getDuration() {
            try { return this._player ? this._player.getDuration() : NaN; } catch { return NaN; }
        }

        isPaused() {
            try {
                const s = this._player.getPlayerState();
                return s === ST_PAUSED || s === ST_ENDED;
            } catch {
                return this._video ? this._video.paused : true;
            }
        }

        // その場で確かめる。bridge.js はこれを見て「広告中は送らない／合わせない」を決めるので、遅れると漏れる
        isInAd() { return this._detectAd(); }

        isPlayerOpen() {
            return Boolean(this._player) && Number.isFinite(this.getDuration()) && this.getDuration() > 0;
        }

        /**
         * YouTube は URL の v= がそのまま別の動画を意味する（Netflix と同じ）。
         * Prime のような「同じ作品なのに URL が書き換わる」現象は無い。
         */
        ignoreUrlChange() { return false; }

        play() {
            if (this._detectAd()) return;   // 広告に手を出すと本編の再生が乱れる
            try { this._player.playVideo(); } catch { this._video?.play?.(); }
        }

        pause() {
            if (this._detectAd()) return;
            try { this._player.pauseVideo(); } catch { this._video?.pause?.(); }
        }

        seek(seconds) {
            if (this._detectAd()) return;
            // 第2引数 true で、指定位置まで実際に読み込みに行く（false だと近くで止まる）
            try { this._player.seekTo(seconds, true); } catch {
                if (this._video) this._video.currentTime = seconds;
            }
            this._lastWatch = null;   // 次の _watch でシークと誤検出しないように
        }

        getContentId(url) {
            const m = YT_ID.exec(url || '');
            return m ? m[1] : null;
        }

        buildUrl(contentId) {
            return `https://www.youtube.com/watch?v=${contentId}`;
        }

        describeForDiag() {
            let state = null;
            try { state = this._player?.getPlayerState?.(); } catch { /* 無い版もある */ }
            return {
                url: location.href,
                raw: this._raw(),
                shown: this.getCurrentTime(),
                inAd: this._detectAd(),
                lastContentTime: this._lastContentTime,
                state,
                duration: this.getDuration(),
                paused: this.isPaused()
            };
        }
    }

    globalThis.WPAdapters.list.push(YouTubeAdapter);
    globalThis.WPAdapters.YouTube = YouTubeAdapter;
})();
