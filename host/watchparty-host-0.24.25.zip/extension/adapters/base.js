// Watch Party 0.24.25（配布用）
// Watch Party adapters/base.js（2026-09-16 Defender の誤検知で消されたため、同じ中身で戻したもの）
/**
 * サービスアダプタの基底クラス。
 *
 * サービスごとの差異はすべてこのインターフェースの内側に閉じ込める。
 * ここさえ守れば、対応サービスの追加は adapters/ にファイルを1枚足すだけで済む。
 *
 * 実装が必要なもの:
 *   static match(url)  … このアダプタが担当する URL か
 *   ready()            … プレイヤーが操作可能になるまで待つ
 *   getCurrentTime()   … 秒
 *   getDuration()      … 秒
 *   isPaused()
 *   isInAd()           … 広告を再生中か（広告の無いサービスは false のまま）
 *   play() / pause()
 *   seek(seconds)
 *   onStateChange(cb)  … cb({ type: 'play'|'pause'|'seek', currentTime })
 *   getContentId(url)  … ルーム共有用の作品 ID
 *   buildUrl(contentId)… 参加者を飛ばす先の URL
 */
(() => {
    class ServiceAdapter {
        /** @returns {string} サービス識別子 */
        static get service() { return 'base'; }

        /** @param {string} _url */
        static match(_url) { return false; }

        constructor() {
            this._listeners = [];
            this._diagListeners = [];
        }

        async ready() { throw new Error('not implemented'); }
        getCurrentTime() { throw new Error('not implemented'); }
        getDuration() { return NaN; }
        isPaused() { throw new Error('not implemented'); }
        isInAd() { return false; }
        /** プレイヤーが画面に開いているか */
        isPlayerOpen() { return false; }
        /**
         * URL が変わっても作品の切り替えとみなさないか。
         * 既定はプレイヤーが開いている間（Prime は再生を始めると同じ作品の URL を書き換える）。
         * Netflix のように、URL の変化がそのまま別の話数を意味するサービスは false を返す。
         */
        ignoreUrlChange() { return this.isPlayerOpen(); }
        /** ホストになったとき、ゲストとして合わせていた状態の強制をやめる（人の操作を邪魔しない） */
        releaseControl() {}
        /** 広告の見分けがうまくいっているかを確かめるための、ページの様子の記録 */
        describeForDiag() { return {}; }
        /**
         * サービス側の確認ダイアログ（Netflix の「まだ見ていますか？」など）を進める。
         * ホストのときだけ呼ばれる。押したら true。
         */
        dismissInterruption() { return false; }
        play() { throw new Error('not implemented'); }
        pause() { throw new Error('not implemented'); }
        seek(_seconds) { throw new Error('not implemented'); }
        getContentId(_url) { return null; }
        buildUrl(_contentId) { return null; }
        /**
         * スマホのアプリを開くときに使う、サービス内部の作品 ID（無ければ null）。
         * Prime は ASIN ではアプリが作品ページで止まるので、アプリ本来の形（GTI）を渡してみる。
         */
        getAppId() { return null; }

        onStateChange(cb) {
            this._listeners.push(cb);
            return () => {
                this._listeners = this._listeners.filter(f => f !== cb);
            };
        }

        /**
         * 記録に残したい出来事（広告らしきものの出入りなど）を受け取る。
         * 見分け方をまだ実機で確かめられていないサービスで、手がかりを集めるのに使う。
         */
        onDiag(cb) {
            this._diagListeners.push(cb);
            return () => {
                this._diagListeners = this._diagListeners.filter(f => f !== cb);
            };
        }

        /** @protected 派生クラスから記録を送る */
        _reportDiag(event, extra = {}) {
            let payload;
            try { payload = { event, ...this.describeForDiag(), ...extra }; }
            catch (e) { payload = { event, describeFailed: String(e && e.message) }; }
            for (const cb of this._diagListeners) {
                try { cb(payload); } catch (e) { console.error('[wp] diag listener error', e); }
            }
        }

        /** @protected 派生クラスから状態変化を通知する */
        _emit(type) {
            const payload = { type, currentTime: this.getCurrentTime() };
            for (const cb of this._listeners) {
                try { cb(payload); } catch (e) { console.error('[wp] listener error', e); }
            }
        }

        /**
         * 条件が満たされるまで待つ。プレイヤーの生成待ちに使う。
         * @param {() => any} probe 真値を返したら解決
         * timeoutMs に Infinity を渡すと期限なしで待つ。
         */
        static waitFor(probe, { intervalMs = 300, timeoutMs = 60_000 } = {}) {
            return new Promise((resolve, reject) => {
                const started = Date.now();
                const tick = () => {
                    let value;
                    try { value = probe(); } catch { value = null; }
                    if (value) return resolve(value);
                    if (Date.now() - started > timeoutMs) {
                        return reject(new Error('waitFor timed out'));
                    }
                    setTimeout(tick, intervalMs);
                };
                tick();
            });
        }
    }

    globalThis.WPAdapters = globalThis.WPAdapters || { list: [] };
    globalThis.WPAdapters.Base = ServiceAdapter;
})();
