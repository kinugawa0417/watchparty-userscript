// KINUGAWA Party Theater 1.1.5（配布用）
(() => {
    const WP = globalThis.WP;
    const api = globalThis.browser;
    const $ = (id) => document.getElementById(id);

    async function send(msg) {
        return api.runtime.sendMessage(msg);
    }

    function render(session) {
        const joined = Boolean(session && session.roomId);
        $('joined-view').classList.toggle('hidden', !joined);
        $('home-view').classList.toggle('hidden', joined);

        if (joined) {
            $('room-code').textContent = session.roomId;
            const who = session.isHost ? 'ホスト' : 'ゲスト';
            $('status').textContent = session.connected
                ? `${who} / ${session.participants.length} 人が視聴中`
                : '接続中...';
            // ゲストが作品へ移動できるかはホストの共有次第なので、ホストにだけ見せる
            $('share').textContent = !session.isHost ? ''
                : session.contentId ? '作品を共有中'
                : 'Prime Video / Netflix の作品ページを開いてください';
            renderParticipants(session);
        }
        if (session && session.serverUrl) {
            $('server').value = session.serverUrl;
        }
        const last = !joined && session && session.lastRoom;
        $('btn-resume').hidden = !last;
        if (last) $('btn-resume').textContent = `前のルーム（${last.roomId}）に戻る`;
    }

    /** 参加者の一覧（「ホストを渡す」は、動きがおかしくなるので外した。2026-09-14） */
    function renderParticipants(session) {
        const box = $('participants');
        box.textContent = '';
        if (!session.connected) return;
        for (const p of session.participants || []) {
            const row = document.createElement('div');
            row.className = 'person';

            const name = document.createElement('span');
            name.className = 'name';
            name.textContent = p.name;   // 名前は他人が決めるので textContent で入れる
            row.appendChild(name);

            if (p.id === session.socketId) {
                const me = document.createElement('span');
                me.className = 'me';
                me.textContent = '（自分）';
                row.appendChild(me);
            }
            if (p.isHost) {
                const tag = document.createElement('span');
                tag.className = 'tag';
                tag.textContent = 'ホスト';
                row.appendChild(tag);
            } else if (p.viewer) {
                // スマホ（観覧専用）の人。プレイヤーを操作できないので、ホストは渡せない（サーバーも拒否する）
                const tag = document.createElement('span');
                tag.className = 'tag';
                tag.textContent = 'スマホ';
                row.appendChild(tag);
            }
            // ホストとずれている・止まっている人
            const drift = WP.driftLabel(p);
            if (drift) {
                const tag = document.createElement('span');
                tag.className = 'tag drift';
                tag.textContent = drift;
                row.appendChild(tag);
            }
            box.appendChild(row);
        }
    }

    function username() {
        const name = $('username').value.trim();
        if (!name) {
            $('username').focus();
            return null;
        }
        localStorage.setItem('wp:username', name);
        return name;
    }

    async function applyServer() {
        const url = $('server').value.trim() || WP.DEFAULT_SERVER;
        await send({ type: 'SET_SERVER', serverUrl: url });
    }

    $('btn-create').addEventListener('click', async () => {
        const name = username();
        if (!name) return;
        await applyServer();
        render(await send({ type: 'CREATE_ROOM', username: name }));
    });

    $('btn-resume').addEventListener('click', async () => {
        await applyServer();
        render(await send({ type: 'RESUME_ROOM' }));
    });

    $('btn-leave').addEventListener('click', async () => {
        render(await send({ type: 'LEAVE' }));
    });

    $('btn-copy').addEventListener('click', async () => {
        await navigator.clipboard.writeText($('room-code').textContent);
        $('btn-copy').textContent = 'コピーしました';
        setTimeout(() => { $('btn-copy').textContent = 'ルームコードだけコピー'; }, 1500);
    });

    /**
     * 友達へ送る文面。リンクの後ろに #ルームコード を付けておくと、
     * 開いた時点でコードが入っている（スマホで6桁を打たせない）。
     * 宛先は同伴ページ＝同期サーバーと同じ住所。
     */
    function inviteText() {
        return WP.inviteText($('server').value.trim(), $('room-code').textContent.trim());
    }

    async function copyTo(id, text, label) {
        await navigator.clipboard.writeText(text);
        $(id).textContent = 'コピーしました';
        setTimeout(() => { $(id).textContent = label; }, 1500);
    }
    $('btn-invite').addEventListener('click', () =>
        copyTo('btn-invite', inviteText(), 'メッセージ付き招待URLをコピー'));
    $('btn-invite-url').addEventListener('click', () =>
        copyTo('btn-invite-url', WP.inviteUrl($('room-code').textContent.trim()), 'URLだけコピー'));

    // 初期表示
    $('version').textContent = `バージョン ${api.runtime.getManifest().version}`;
    $('username').value = localStorage.getItem('wp:username') || '';
    send({ type: 'GET_SESSION' }).then(render).catch(() => render(null));

    // 開いている間は状態を追う
    api.runtime.onMessage.addListener((msg) => {
        if (msg && msg.type === 'SESSION') render(msg.payload);
    });
})();
