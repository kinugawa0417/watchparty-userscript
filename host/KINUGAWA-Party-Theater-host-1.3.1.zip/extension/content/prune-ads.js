// KINUGAWA Party Theater 1.3.1（配布用）
/*
 * **Prime Video の広告を消す**（2026-09-25 ユーザー要望）。
 *
 * ■ 何をしているか（Brave が既定で配っている公開のフィルターと同じ内容）
 * Brave では Prime の広告が出ないので、Brave がページに差し込むプログラムを捕まえて調べた
 * （tools/.probe-brave/*-injected-shields-on.json）。やっていたのは2つ:
 *   ① json-prune … 再生情報（JSON）から**広告の予定**を消す。`JSON.parse` を包む
 *   ② xml-prune  … 動画の配信リスト（.mpd）から**広告の区間そのもの**を消す。`fetch` と XHR の返事を書き換える。
 *                  あわせて全体の長さと各区間の開始位置も消し、プレイヤーに時間を計算し直させる
 * 最初は①だけを入れていたが、別の会話の調べで**実際に効いているのは②**と分かった（2026-09-25）。
 *   ③ HLS（iPhone）… 配信リスト（.m3u8）の**アドレスから「広告を差し込む印」を外す**（2026-10-14 実機で解明）。
 *                  iPhone の Safari は配信の形式が違い（.mpd ではなく .m3u8）、しかも動画の部品が自分で取りに行くので、
 *                  ②のように返事を書き換えられない。調べたら、アドレスの途中に `1@…`（35 文字ほど）という部分があり、
 *                  **これを外したアドレスは、本編だけの配信リストを返す**（広告 30 秒×3 本が入っていた作品で、長さが本編ちょうどになった。
 *                  映像・音声・動画本体とも取れる）。ページがリストを取りに行くとき・動画に渡すときに外す。Brave の指定には無い、こちらで見つけた方法
 *
 * ■ 消し方は uBlock（Brave が使っているもの）の決まりに合わせる
 * `intraTitlePlaylist.[-].shouldShowOnScrubBar` は「その項目を持つ**要素を並びから取り除く**」という意味
 * （項目だけを消すのではない。最初の版はここを取り違えていた）。
 *
 * ■ やらないこと
 * **広告を「流したことにして飛ばす」ことはしない。** それは広告主をだますことになる（2026-09-11 の決め）。
 * ここでやるのは「広告を取りに行かせない」だけ。
 *
 * ■ 気をつけること
 * ・`JSON.parse` と `fetch` はページ中で何度も使われるので、**関わるものでなければ何も触らない**
 * ・**例外を外に出さない**。ここで throw すると Amazon のページ全体が止まる
 * ・スマホ用スクリプトでは、招待から開いたタブでだけ読み込む（ふだんの Amazon には入れない）
 * ・ホストの拡張機能では prime-plan.js の後に読み込む（prime-plan は消される前の並びを読むため、
 *   元の JSON.parse を先に取っておく）。Chrome でホストをしても広告が出ないようにするため（2026-09-25）
 */
const WP_PRUNE = (() => {
    'use strict';

    // テストで一部だけ外して比べるための指定（例: ['mpd'] で ② を入れない）
    const SKIP = Array.isArray(globalThis.__wpPruneSkip) ? globalThis.__wpPruneSkip : [];

    /*
     * ① 再生情報から消す場所（Brave の指定そのまま）。`.[-].` は「並びの要素のうち、続きを持つものを取り除く」。
     * **`ads`（いちばん外側）は入れない**（2026-09-25）。Brave の指定には入っているが、
     * これを消すと本物の Prime でホストと 8〜16 秒ずれた（2回とも再現）。名前がありふれていて、
     * 再生情報以外の返事にある同名の項目まで消してしまうためとみられる。**効き目より、再生を壊さないことを優先する。**
     */
    const JSON_PATHS = [
        'cuepointPlaylist',
        'vodPlaybackUrls.result.playbackUrls.cuepoints',
        'vodPlaylistedPlaybackUrls.result.playbackUrls.pauseBehavior',
        'vodPlaylistedPlaybackUrls.result.playbackUrls.pauseAdsResolution',
        'vodPlaylistedPlaybackUrls.result.playbackUrls.intraTitlePlaylist.[-].shouldShowOnScrubBar',
    ].filter((p) => !SKIP.includes(p)).map((p) => p.split('.'));

    /** 関わりのある返事かどうかを、文字列のうちに手早く見分ける（ほとんどの JSON.parse はここで素通り） */
    const QUICK = /"(?:cuepointPlaylist|cuepoints|pauseBehavior|pauseAdsResolution|shouldShowOnScrubBar)"/;

    /*
     * ② 配信リスト（.mpd）から消すもの（Brave の指定そのまま）。
     * check … 文書にこれが無ければ何もしない。select … 消すもの（区間の要素と、長さ・開始位置の属性）
     */
    const MPD_URL = /\.mpd/;
    const MPD_RULES = [
        { check: '[value="Draper"]',
          select: '//*[name()="Period"][.//*[@value="Draper"]] | /*[name()="MPD"]/@mediaPresentationDuration | //*[name()="Period"]/@start' },
        { check: '[value="Ad"]',
          select: '//*[name()="Period"][.//*[@value="Ad"]] | /*[name()="MPD"]/@mediaPresentationDuration | //*[name()="Period"]/@start' },
        { check: '',
          select: '//*[name()="Period"][.//*[name()="BaseURL" and contains(text(),"/interstitial/")]]' +
            ' | /*[name()="MPD"][.//*[name()="BaseURL" and contains(text(),"/interstitial/")]]/@mediaPresentationDuration' +
            ' | /*[name()="MPD"][.//*[name()="BaseURL" and contains(text(),"/interstitial/")]]/*[name()="Period"]/@start' },
    ];

    /*
     * ③ HLS の配信リストのアドレスにある「広告を差し込む印」。`/1@` ＋英数字 のひと区切り（実機: `1@` ＋ 33 文字）。
     * .m3u8 のアドレスにこれがあるときだけ、その区切りを取り除く
     */
    const HLS_TOKEN = /\/\d@[A-Za-z0-9]{16,60}(?=\/)/;

    /** 何をどれだけ消したか（テストと記録用。作品の中身や鍵は持たない） */
    const stats = { json: 0, removedEntries: {}, mpd: 0, mpdPruned: 0, periods: 0, errors: 0, hls: 0,
        /*
         * 効かなかったときに理由を突き止めるための記録（2026-10-14 iPhone 実機: 広告が流れた・配信リストを1回も見ていない）。
         * **数と、項目の名前だけ**（作品名・アドレス・鍵は持たない）
         *   seen … 配信リストらしい通信を、誰が何回取りに行ったか（f=fetch x=XHR r=ページの通信の記録。mpd / m3u8 の別）
         *   keys … 再生情報の中にあった、広告らしい項目の場所（名前の道のり）。Amazon が項目の名前を変えていないかを見る
         *   at   … 包んだときの読み込みの段階（loading なら最初に入れられた）
         */
        seen: {}, keys: [], at: '' };
    let ownFetch = null, ownXhr = null;

    function note(kind, url) {
        try {
            const m = /\.(mpd|m3u8)(?:[?#]|$)/.exec(String(url));
            if (!m) return;
            const k = kind + m[1];
            stats.seen[k] = (stats.seen[k] || 0) + 1;
        } catch { /* 無視 */ }
    }

    /** 広告らしい名前の項目の場所を集める（名前だけ。値は見ない）。並びは先頭の要素だけたどる */
    const KEY_HINT = { test: (k) => /cue|adbreak|interstitial|playlist|pause/i.test(k) || /^ads?$|^ad[A-Z_]|[a-z]Ads?(?:[A-Z]|$)/.test(k) };
    function collectKeys(obj) {
        let budget = 4000;
        const visit = (node, path, depth) => {
            if (!node || typeof node !== 'object' || depth > 7 || budget-- <= 0) return;
            if (Array.isArray(node)) { if (node.length) visit(node[0], path + '[]', depth + 1); return; }
            for (const key of Object.keys(node)) {
                if (stats.keys.length >= 24) return;
                const p = path ? path + '.' + key : key;
                if (KEY_HINT.test(key) && /^[A-Za-z0-9_]{1,40}$/.test(key) && p.length <= 120 && !stats.keys.includes(p)) stats.keys.push(p);
                visit(node[key], p, depth + 1);
            }
        };
        visit(obj, '', 0);
    }
    const KEY_QUICK = /"(?:vodPlaybackUrls|vodPlaylistedPlaybackUrls|playbackUrls|cuepointPlaylist|intraTitlePlaylist)"/;

    const hasOwn = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

    /** その道のりの先に項目があるか（uBlock の objectFindOwnerFn の「消さない」ほう） */
    function has(node, parts) {
        for (let i = 0; i < parts.length; i++) {
            if (!node || typeof node !== 'object') return false;
            if (i === parts.length - 1) return hasOwn(node, parts[i]);
            if (!hasOwn(node, parts[i])) return false;
            node = node[parts[i]];
        }
        return false;
    }

    /** 道のりをたどって消す（uBlock の objectFindOwnerFn の「消す」ほう） */
    function walk(node, parts) {
        if (!node || typeof node !== 'object') return false;
        const [key, ...rest] = parts;
        if (rest.length === 0) {
            if (!hasOwn(node, key)) return false;
            delete node[key];
            return true;
        }
        if (key === '[-]') {
            if (!Array.isArray(node)) return false;
            let hit = false;
            for (let i = node.length - 1; i >= 0; i--) {
                if (!has(node[i], rest)) continue;
                const type = node[i] && typeof node[i].type === 'string' ? node[i].type.slice(0, 20) : '?';
                stats.removedEntries[type] = (stats.removedEntries[type] || 0) + 1;
                node.splice(i, 1);
                hit = true;
            }
            return hit;
        }
        if (!hasOwn(node, key)) return false;
        return walk(node[key], rest);
    }

    /** 返ってきた中身から、広告の指定だけを消す */
    function prune(obj) {
        let hit = false;
        for (const parts of JSON_PATHS) if (walk(obj, parts)) hit = true;
        if (hit) stats.json++;
        return hit;
    }

    /** 配信リストの文書から広告の区間を消す。消したら true */
    function pruneMpdDoc(doc) {
        let changed = false;
        for (const rule of MPD_RULES) {
            if (rule.check && !doc.querySelector(rule.check)) continue;
            const found = doc.evaluate(rule.select, doc, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
            for (let i = 0; i < found.snapshotLength; i++) {
                const node = found.snapshotItem(i);
                if (node.nodeType === 1) { node.remove(); stats.periods++; changed = true; }
                else if (node.nodeType === 2 && node.ownerElement) { node.ownerElement.removeAttribute(node.nodeName); changed = true; }
            }
        }
        return changed;
    }

    /** 配信リストの文字列を書き換える。形が違えばそのまま返す */
    function pruneMpdText(text) {
        if (typeof text !== 'string' || !/^\s*</.test(text) || !/>\s*$/.test(text)) return text;
        try {
            const doc = new DOMParser().parseFromString(text, 'text/xml');
            if (doc.getElementsByTagName('parsererror').length) return text;
            stats.mpd++;
            if (!pruneMpdDoc(doc)) return text;
            stats.mpdPruned++;
            return new XMLSerializer().serializeToString(doc);
        } catch {
            stats.errors++;
            return text;
        }
    }

    /** HLS の配信リストのアドレスから、広告を差し込む印を外す。関係のないアドレスはそのまま返す */
    function fixHlsUrl(url) {
        try {
            if (typeof url !== 'string' || url.indexOf('.m3u8') < 0 || !HLS_TOKEN.test(url)) return url;
            stats.hls++;
            return url.replace(HLS_TOKEN, '');
        } catch { stats.errors++; return url; }
    }

    /** 動画の部品に渡すアドレス（video.src など）でも外す。ページが別の道で渡したときの備え */
    function wrapMediaSrc() {
        const wrapProp = (proto) => {
            const d = Object.getOwnPropertyDescriptor(proto, 'src');
            if (!d || !d.set || !d.get) return;
            Object.defineProperty(proto, 'src', { configurable: true, enumerable: d.enumerable,
                get() { return d.get.call(this); }, set(v) { d.set.call(this, fixHlsUrl(String(v))); } });
        };
        wrapProp(HTMLMediaElement.prototype);
        wrapProp(HTMLSourceElement.prototype);
        const setAttribute = Element.prototype.setAttribute;
        Element.prototype.setAttribute = function (name, value) {
            if ((this instanceof HTMLMediaElement || this instanceof HTMLSourceElement) && String(name).toLowerCase() === 'src') {
                return setAttribute.call(this, name, fixHlsUrl(String(value)));
            }
            return setAttribute.apply(this, arguments);
        };
    }

    function urlOf(input) {
        try {
            if (typeof input === 'string') return input;
            if (input instanceof Request) return input.url;
            return String(input);
        } catch { return ''; }
    }

    function wrapJsonParse() {
        const native = JSON.parse;
        JSON.parse = function (text, reviver) {
            const obj = native.apply(this, arguments);
            try {
                if (typeof text === 'string' && KEY_QUICK.test(text)) collectKeys(obj);
            } catch { /* 記録だけなので無視 */ }
            try {
                if (typeof text === 'string' && QUICK.test(text)) prune(obj);
            } catch { stats.errors++; }
            return obj;
        };
        try {
            Object.defineProperty(JSON.parse, 'name', { value: 'parse', configurable: true });
            Object.defineProperty(JSON.parse, 'length', { value: native.length, configurable: true });
        } catch { /* 変えられなくても構わない */ }
    }

    function wrapFetch() {
        const native = window.fetch;
        if (typeof native !== 'function') return;
        window.fetch = function (input) {
            const args = Array.from(arguments);
            if (!SKIP.includes('hls')) {
                try {
                    const before = urlOf(input);
                    const fixed = fixHlsUrl(before);
                    if (fixed !== before) args[0] = input instanceof Request ? new Request(fixed, input) : fixed;
                } catch { stats.errors++; }
            }
            const pending = native.apply(this, args);
            note('f', urlOf(input));
            if (!MPD_URL.test(urlOf(input))) return pending;
            return pending.then((before) => before.clone().text().then((text) => {
                const after = new Response(pruneMpdText(text),
                    { status: before.status, statusText: before.statusText, headers: before.headers });
                Object.defineProperties(after, {
                    ok: { value: before.ok }, redirected: { value: before.redirected },
                    type: { value: before.type }, url: { value: before.url },
                });
                return after;
            }).catch(() => before));
        };
        ownFetch = window.fetch;
    }

    function wrapXhr() {
        const Native = window.XMLHttpRequest;
        if (typeof Native !== 'function') return;
        // 配信リストを取りに行った XHR だけ覚える。書き換えた結果は1回だけ作って使い回す
        const marked = new WeakMap();
        const pruned = (xhr, value) => {
            const m = marked.get(xhr);
            if (!m || xhr.readyState !== 4) return value;
            try {
                if (typeof value === 'string') {
                    if (m.src !== value) { m.src = value; m.out = pruneMpdText(value); }
                    return m.out;
                }
                if (value && typeof value === 'object' && value.nodeType === 9 && !m.doc) {
                    m.doc = true;
                    stats.mpd++;
                    if (pruneMpdDoc(value)) stats.mpdPruned++;
                }
            } catch { stats.errors++; }
            return value;
        };
        class XMLHttpRequest extends Native {
            open(method, url, ...rest) {
                note('x', url);
                try { if (MPD_URL.test(String(url))) marked.set(this, {}); } catch { /* 無視 */ }
                if (!SKIP.includes('hls') && typeof url === 'string') url = fixHlsUrl(url);
                return super.open(method, url, ...rest);
            }
            get response() { return pruned(this, super.response); }
            get responseText() { return pruned(this, super.responseText); }
            get responseXML() { return pruned(this, super.responseXML); }
        }
        window.XMLHttpRequest = XMLHttpRequest;
        ownXhr = XMLHttpRequest;
    }

    /** ページの通信の記録から、配信リストを数える（包みを通らなかったもの＝動画の部品が自分で取りに行ったものも入る） */
    function watchResources() {
        if (typeof PerformanceObserver !== 'function') return;
        const obs = new PerformanceObserver((list) => { for (const e of list.getEntries()) note('r', e.name); });
        obs.observe({ type: 'resource', buffered: true });
    }

    /** 記録用: いまも自分の包みが入っているか（後から別のものに置き換えられていないか） */
    function snapshot() {
        const out = JSON.parse(JSON.stringify(stats));
        out.hooked = (ownFetch ? (window.fetch === ownFetch ? 'f' : 'F') : '-') + (ownXhr ? (window.XMLHttpRequest === ownXhr ? 'x' : 'X') : '-');
        return out;
    }

    /** 包む。**一度だけ**。 */
    function install() {
        if (globalThis.__wpPruneAds) return false;
        globalThis.__wpPruneAds = true;
        // 本物の Amazon で実際に何を消したかを、テスト（e2e-userscript-real）から読むため。数だけで中身は持たない
        try { Object.defineProperty(globalThis, '__wpPruneStats', { value: snapshot }); } catch { /* 無視 */ }
        try { stats.at = String(document.readyState).slice(0, 12); } catch { /* 無視 */ }
        try { watchResources(); } catch { /* 無視 */ }
        wrapJsonParse();
        // fetch と XHR の包みは ②（.mpd）と ③（HLS のアドレス）で共用。片方だけ外しても、もう片方は中で見分けて動く
        if (!SKIP.includes('mpd') || !SKIP.includes('hls')) {
            try { wrapFetch(); } catch { stats.errors++; }
            try { wrapXhr(); } catch { stats.errors++; }
        }
        if (!SKIP.includes('hls')) { try { wrapMediaSrc(); } catch { stats.errors++; } }
        return true;
    }

    return { install, prune, pruneMpdText, fixHlsUrl, stats: snapshot };
})();
