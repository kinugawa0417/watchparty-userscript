// KINUGAWA Party Theater 1.3.1（配布用）
/**
 * offscreen document 側。socket.io の接続をここで保持する。
 * background からのコマンドを受け、サーバーからのイベントを background へ返す。
 */
(() => {
    const WP = globalThis.WP;

    // サーバーから受け取って background へ流すイベント
    const RELAY = [
        'connect',
        'disconnect',
        'connect_error',
        'update-participants',
        'update-host',
        'update-video-state',
        'sync-video',
        'change-video',
        'video-stopped',
        'video-meta',
        'receive-message',
        'chat-history',
        'action-rejected',
        'voice-state'
    ];

    let socket = null;

    chrome.runtime.onMessage.addListener((msg) => {
        if (!msg || msg.channel !== WP.CONN_CMD) return;

        if (msg.cmd === 'connect') {
            connect(msg.serverUrl);
        } else if (msg.cmd === 'emit') {
            socket?.emit(msg.event, msg.payload);
        } else if (msg.cmd === 'disconnect') {
            voiceStop(false);
            socket?.close();
            socket = null;
        } else if (msg.cmd === 'voice-start') {
            voiceStart();
        } else if (msg.cmd === 'voice-stop') {
            voiceStop(true);
        } else if (msg.cmd === 'voice-mute') {
            voiceMute(msg.muted === true);
        } else if (msg.cmd === 'voice-republish') {
            // つなぎ直してルームに入り直した。副音声中だったら流し直す（サーバーは切れた時点で止めている）
            if (voice.wanted) publish();
        }
    });

    // --- ホストの副音声（声）---------------------------------------------------
    /*
     * マイクの声を Cloudflare Realtime（WebRTC の中継）へ送る（2026-09-30）。
     * つなぎ方の書類（SDP）の受け渡しだけ同期サーバー（voice-publish）に頼み、声は Cloudflare へ直接送る。
     * 自宅の回線から出ていくのは1本だけ（聞く人が増えても増えない）。
     * マイクはここ（画面に出ない文書）で持つ。ポップアップは閉じると消えるので持てない。
     * 許可の確認はここでは出せないので、初めてのときは background が mic.html を開いて許可を取る。
     */
    const voice = { wanted: false, muted: false, stream: null, pc: null };

    function report(state, error) {
        chrome.runtime.sendMessage({
            channel: WP.CONN_EVT,
            event: 'voice-local',
            payload: { state, muted: voice.muted, error: error || null }
        }).catch(() => {});
    }

    async function voiceStart() {
        voice.wanted = true;
        if (!voice.stream) {
            try {
                voice.stream = await navigator.mediaDevices.getUserMedia({
                    // エコー消しは付けるが、映画の音はこれでは消えない。ホストはヘッドホンで使う（ポップアップに書いてある）
                    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
                });
            } catch (e) {
                voice.wanted = false;
                report('error', e && (e.name === 'NotAllowedError' || e.name === 'SecurityError') ? 'need-permission' : 'no-mic');
                return;
            }
        }
        await publish();
    }

    function closePc() {
        if (!voice.pc) return;
        voice.pc.onconnectionstatechange = null;
        voice.pc.close();
        voice.pc = null;
    }

    /** 返事つきで送る。返事が来なければ null */
    function ask(event, payload) {
        return new Promise((resolve) => {
            if (!socket || !socket.connected) return resolve(null);
            socket.timeout(20000).emit(event, payload, (err, res) => resolve(err ? null : res));
        });
    }

    async function publish() {
        if (!voice.wanted || !voice.stream) return;
        closePc();
        const pc = new RTCPeerConnection({
            iceServers: [{ urls: 'stun:stun.cloudflare.com:3478' }],
            bundlePolicy: 'max-bundle'
        });
        voice.pc = pc;
        const track = voice.stream.getAudioTracks()[0];
        track.enabled = !voice.muted;
        const tr = pc.addTransceiver(track, { direction: 'sendonly' });
        report('connecting');
        try {
            await pc.setLocalDescription(await pc.createOffer());
            const res = await ask('voice-publish', { offer: { type: 'offer', sdp: pc.localDescription.sdp }, mid: tr.mid });
            if (voice.pc !== pc) return;     // 待っている間に止めた・流し直した
            if (!res || res.error || !res.answer) {
                closePc();
                voice.wanted = false;
                report('error', (res && res.error) || 'timeout');
                return;
            }
            pc.onconnectionstatechange = () => {
                if (voice.pc !== pc) return;
                if (pc.connectionState === 'connected') {
                    socket?.emit('voice-live');
                    report('on');
                } else if (pc.connectionState === 'failed') {
                    // 回線が切り替わったなど。流し直す（ルームにいれば）
                    report('connecting');
                    setTimeout(() => { if (voice.pc === pc && voice.wanted) publish(); }, 3000);
                }
            };
            await pc.setRemoteDescription(res.answer);
        } catch (e) {
            if (voice.pc !== pc) return;
            console.warn('[wp/voice] publish failed', e);
            closePc();
            voice.wanted = false;
            report('error', 'failed');
        }
    }

    function voiceStop(tellServer) {
        const was = voice.wanted || voice.pc || voice.stream;
        voice.wanted = false;
        closePc();
        // マイクを離す（ブラウザの「マイク使用中」の印も消える）
        if (voice.stream) voice.stream.getTracks().forEach(t => t.stop());
        voice.stream = null;
        voice.muted = false;
        if (tellServer) socket?.emit('voice-stop');
        if (was) report('off');
    }

    function voiceMute(muted) {
        voice.muted = muted;
        const track = voice.stream && voice.stream.getAudioTracks()[0];
        if (track) track.enabled = !muted;
        report(voice.pc && voice.pc.connectionState === 'connected' ? 'on' : voice.wanted ? 'connecting' : 'off');
    }

    function connect(serverUrl) {
        if (socket) socket.close();

        // polling を挟まず websocket 直行。CORS プリフライトを避けられる。
        socket = globalThis.io(serverUrl, {
            transports: ['websocket'],
            reconnection: true,
            reconnectionDelay: 1000
        });

        for (const event of RELAY) {
            socket.on(event, (payload) => {
                // connect は引数を持たないので、自分の socket id を載せて返す。
                // 参加者一覧の中から「自分」を特定するのに必要。
                const body = event === 'connect'
                    ? { id: socket.id }
                    : serializable(payload);

                chrome.runtime.sendMessage({
                    channel: WP.CONN_EVT,
                    event,
                    payload: body
                }).catch(() => {});
            });
        }

        console.log('[wp/offscreen] connecting to', serverUrl);
    }

    /** Error 等はそのまま送れないので落とす */
    function serializable(v) {
        if (v instanceof Error) return { message: v.message };
        return v;
    }
})();
