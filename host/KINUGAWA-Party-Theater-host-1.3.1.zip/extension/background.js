// KINUGAWA Party Theater 1.3.1（配布用）
/**
 * 中央のルーター。
 *
 * ここ自体は socket を持たない（Chromium では service worker が
 * 30秒で止まるため）。接続は connection 層に委ね、状態の管理と
 * popup / content script への配信だけを担当する。
 *
 * service worker は随時停止・再起動されるので、セッション状態は
 * chrome.storage.session に保存して復帰できるようにしている。
 */

// Chromium: service worker（クラシック）なので importScripts で読み込む。
// Firefox: manifest の background.scripts で先に読み込まれるため何もしない。
if (typeof importScripts === 'function') {
    importScripts(
        'protocol.js',
        'connection/chromium.js',
        'connection/firefox.js',
        'connection/index.js'
    );
}

const WP = globalThis.WP;
// manifest.json の content_scripts の matches と必ず揃えること。
// ここに無いサイトは、タブを探す対象からも、ゲストを飛ばす対象からも外れる
const SITE_MATCHES = [
    'https://www.amazon.co.jp/*',
    'https://www.primevideo.com/*',
    'https://www.netflix.com/*',
    'https://www.youtube.com/*'
];
// ホストから届いたアドレスのうち、ゲストのブラウザで開いてよいもの。
// サーバーでも確かめているが、サーバーが乗っ取られても偽サイトへ飛ばされないよう、ここでも確かめる
const FOLLOWABLE_URL =
    /^https:\/\/(www\.amazon\.co\.jp|www\.primevideo\.com|www\.netflix\.com|www\.youtube\.com)\//;

let conn = null;
let session = blankSession();

// service worker が再起動した直後は storage から復元し終わるまで待つ。
// 復元は起動時の1回だけ。以降はメモリ上の session が正で、storage は再起動に備えた控え。
const sessionReady = loadSession();

// サーバーイベントとメッセージは届いた順に1つずつ処理する。
// 並行して session を読み書きすると、後の処理が先の更新を上書きしてしまうため。
let queue = Promise.resolve();
function enqueue(fn) {
    const run = queue.then(() => sessionReady).then(fn);
    queue = run.catch(e => console.error('[wp] handler failed', e));
    return run;
}

function blankSession() {
    return {
        connected: false,
        roomId: null,
        username: null,
        isHost: false,
        socketId: null,        // 参加者一覧から自分を特定するのに使う
        participants: [],
        serverUrl: WP.DEFAULT_SERVER,
        // いま開いている作品
        service: null,
        contentId: null,
        url: null,
        /*
         * ゲストに送ってある作品と、ホストの作品が変わったのにまだ送っていないか（2026-09-14）。
         * 作品が変わったらしいとき（アドレス・動画の長さ）は自動で送らず「保留」にし、ホストが
         * 「今の作品をゲストに送る」を押したときだけ送る。保留の間は再生位置も送らない
         * （ゲストが前の作品のまま、新しい作品の時刻に合わせてしまう不具合があった）。
         */
        sharedContentId: null,
        plan: null,         // Prime の広告の入る位置（ホストが読んだもの。video-meta でゲストへ）
        titlePending: false,
        /*
         * 上映中か（2026-10-14 ユーザー要望）。**最初は OFF**。ホストが「上映をはじめる」を押すまで、
         * 作品も再生位置もゲストへ送らない（ゲストは待合室で待つ。ホストは先に作品を開いて頭出しなどができる）。
         * 「上映を終了」で OFF に戻り、ゲストは待合室へ戻る。
         */
        airing: false,
        // いま開いている作品の名前と、ゲストに送ってある作品の名前（ホストのパネルに出すだけ。サーバーへは送らない）
        title: '',
        sharedTitle: '',
        sharedService: null,
        roomVideo: false,   // ルームに作品が出ているか（ゲストのとき。ホストを引き継いだら上映中として続ける）
        // このルームのチャット（ページを開き直しても続きが見えるように覚えておく）
        chat: [],
        // ホストの副音声（2026-09-30）。state: off / connecting / on / error。error はポップアップに出す理由
        voice: blankVoice()
    };
}

function blankVoice() {
    return { state: 'off', muted: false, error: null };
}

const CHAT_KEEP = 100;

/*
 * 最後に作ったルーム（2026-09-14）。session はブラウザを閉じると消えるので、ホストがブラウザを開き直すと
 * ルームに戻れなかった。ルームコードとなまえだけを storage.local に残し、「前のルームに戻る」で同じルームに入り直す。
 * 自分で「退出」したら消す。古すぎるものは出さない。
 */
const LAST_ROOM_KEEP_MS = 24 * 60 * 60 * 1000;
let lastRoom = null;

async function loadSession() {
    const stored = await chrome.storage.session.get('session');
    if (stored.session) session = { ...blankSession(), ...stored.session };
    const local = await chrome.storage.local.get('lastRoom');
    const r = local.lastRoom;
    // 6文字で作っていた頃のルームにも戻れるように、幅を持たせる（2026-09-16 に 8 文字へ）
    lastRoom = r && /^[A-Z0-9]{4,12}$/.test(r.roomId) && Date.now() - r.at < LAST_ROOM_KEEP_MS ? r : null;
}

async function rememberRoom() {
    lastRoom = { roomId: session.roomId, username: session.username, at: Date.now() };
    await chrome.storage.local.set({ lastRoom });
}

async function forgetRoom() {
    lastRoom = null;
    await chrome.storage.local.remove('lastRoom');
}

async function saveSession() {
    await chrome.storage.session.set({ session });
}

function publicSession() {
    return {
        connected: session.connected,
        roomId: session.roomId,
        isHost: session.isHost,
        participants: session.participants,
        socketId: session.socketId,       // 参加者一覧で「自分」を見分ける
        serverUrl: session.serverUrl,
        contentId: session.contentId,     // ホストが作品を共有できているかの表示用
        titlePending: session.titlePending,
        airing: session.airing,
        sharedTitle: session.sharedTitle,
        sharedService: session.sharedService,
        voice: session.voice,
        // 「前のルームに戻る」用。ルームに入っていないときだけ
        lastRoom: !session.roomId && lastRoom ? { roomId: lastRoom.roomId, username: lastRoom.username } : null
    };
}

/** 対象サイトのタブ全部へ配信する */
/**
 * スマホのアプリを開くための内部 ID（Prime の GTI）を、同伴ページへ届ける。
 *
 * change-video に混ぜないのは、change-video を同じ作品で送り直すと
 * サーバー側の再生位置が 0 に戻るため。サーバーは change-video で内部 ID を消し、
 * video-meta で入れ直すので、必ず change-video のあとに送る（同じ接続なので順番は保たれる）。
 */
/** 今の作品をゲストに送る（ホストのみ）。保留を解く */
function sendTitle() {
    if (!session.isHost || !session.connected || !session.contentId) return false;
    ensureConnection().emit('change-video', {
        contentId: session.contentId,
        service: session.service,
        url: session.url
    });
    shareVideoMeta();
    session.sharedContentId = session.contentId;
    session.sharedTitle = session.title || '';
    session.sharedService = session.service;
    session.titlePending = false;
    return true;
}

/** 上映をはじめる（ホストのみ）。今の作品を送る。まだ作品を開いていなければ、開いたときに送る */
function startAiring() {
    if (!session.roomId) return false;
    session.airing = true;
    session.titlePending = false;
    sendTitle();
    return true;
}

/** 上映を終了する（ホストのみ）。ゲストは待合室へ戻る。次に「上映をはじめる」を押すまで何も送らない */
function stopAiring() {
    session.airing = false;
    session.sharedContentId = null;
    session.sharedTitle = '';
    session.sharedService = null;
    session.titlePending = false;
    if (session.isHost && session.connected) ensureConnection().emit('stop-video');
    return true;
}

/** 作品が変わったらしい（ホストのみ）。自動では送らず保留にし、ホストに知らせる */
function holdTitle() {
    if (!session.isHost || !session.connected || !session.airing) return;
    if (!session.sharedContentId) { sendTitle(); return; }   // まだ何も送っていないなら、最初の作品はそのまま送る
    if (session.titlePending) return;
    session.titlePending = true;
    ensureConnection().emit('title-hold');
}

function shareVideoMeta() {
    if (!session.isHost || !session.connected || (!session.appId && !session.plan)) return;
    ensureConnection().emit('video-meta', { contentId: session.contentId, appId: session.appId, plan: session.plan });
}

/** 広告の入る位置（content/prime-plan.js）を形だけ確かめる。駄目なら null */
function cleanPlan(p) {
    if (!p || typeof p !== 'object') return null;
    const fullMs = Number(p.fullMs);
    if (!Number.isFinite(fullMs) || fullMs < 300000 || fullMs > 86400000 || !Array.isArray(p.breaks)) return null;
    const breaks = p.breaks.map(Number).filter(ms => Number.isFinite(ms) && ms >= 0 && ms <= fullMs).slice(0, 40);
    return { fullMs, breaks };
}

/**
 * チャットの別ウィンドウ。
 * service worker は止まると変数が消えるので、窓の番号は storage.session に置く。
 * 窓が閉じられていれば update が失敗するので、そのときは作り直す。
 */
async function openChatWindow() {
    const { chatWindowId } = await chrome.storage.session.get('chatWindowId');
    if (chatWindowId) {
        try {
            await chrome.windows.update(chatWindowId, { focused: true, drawAttention: true });
            return;
        } catch { /* もう閉じられている。下で作り直す */ }
    }
    const win = await chrome.windows.create({
        url: chrome.runtime.getURL('chat.html'),
        type: 'popup',
        width: 380,
        height: 620
    });
    await chrome.storage.session.set({ chatWindowId: win.id });
}

chrome.windows?.onRemoved.addListener(async (id) => {
    const { chatWindowId } = await chrome.storage.session.get('chatWindowId');
    if (chatWindowId === id) await chrome.storage.session.remove('chatWindowId');
});

async function broadcast(msg) {
    const tabs = await chrome.tabs.query({ url: SITE_MATCHES });
    for (const tab of tabs) {
        chrome.tabs.sendMessage(tab.id, msg).catch(() => {});
    }
}

async function pushSession() {
    await saveSession();
    const msg = { type: 'SESSION', payload: publicSession() };
    await broadcast(msg);
    // popup はタブではないので tabs.sendMessage では届かない。開いていなければ reject されるので握る
    chrome.runtime.sendMessage(msg).catch(() => {});
}

// --- 接続 ---------------------------------------------------------------

function ensureConnection() {
    if (conn) return conn;
    conn = globalThis.WPConn.create();
    conn.onEvent((event, payload) => enqueue(() => handleServerEvent(event, payload)));
    return conn;
}

async function handleServerEvent(event, payload) {
    switch (event) {
        case 'connect':
            session.connected = true;
            session.socketId = (payload && payload.id) || null;
            // 接続が確立してから join する
            ensureConnection().emit('join-room', {
                roomId: session.roomId,
                username: session.username,
                isHost: session.isHost
            });
            // 上映中で、ホストが既に作品ページを開いていれば共有する（保留中なら、つなぎ直しても保留のまま）
            if (session.isHost && session.airing && session.contentId) {
                if (session.titlePending) ensureConnection().emit('title-hold');
                else sendTitle();
            }
            // 副音声中に切れてつなぎ直した。サーバーは切れた時点で副音声を止めているので流し直す
            if (session.isHost && session.voice.state !== 'off') voiceCommand('republish');
            await pushSession();
            break;

        // offscreen（マイクを持っている側）からの副音声の状態
        case 'voice-local': {
            const p = payload || {};
            session.voice = {
                state: ['off', 'connecting', 'on', 'error'].includes(p.state) ? p.state : 'off',
                muted: p.muted === true,
                error: typeof p.error === 'string' ? p.error : null
            };
            // 初めてでマイクの許可がまだ。画面に出ない文書からは許可の確認を出せないので、許可を取るページを開く
            if (p.error === 'need-permission') {
                chrome.tabs.create({ url: chrome.runtime.getURL('mic.html') }).catch(() => {});
            }
            await pushSession();
            break;
        }

        case 'disconnect':
            session.connected = false;
            await pushSession();
            break;

        case 'update-participants': {
            session.participants = payload || [];
            // ホストかどうかはサーバーの判断が正。自分の socket id で引く。
            const wasHost = session.isHost;
            session.isHost = session.participants.some(
                u => u.id === session.socketId && u.isHost
            );
            // ホストを引き継いだ。ルームに作品が出ていれば、上映中として続ける
            if (!wasHost && session.isHost && session.roomVideo) session.airing = true;
            stopVoiceIfGuest();
            await pushSession();
            break;
        }

        case 'update-host':
            if (payload && payload.newHostId) {
                const wasHost = session.isHost;
                session.isHost = payload.newHostId === session.socketId;
                if (!wasHost && session.isHost && session.roomVideo) session.airing = true;
                const me = session.participants.find(u => u.id === session.socketId);
                if (me) me.isHost = session.isHost;
            }
            stopVoiceIfGuest();
            await pushSession();
            break;

        case 'sync-video':
            await broadcast({ type: 'APPLY', payload });
            break;

        case 'video-meta':
            // ホストが読んだ Prime の広告の入る位置。ゲストの自分が同じ作品を開いていれば、ページへ渡す
            if (!session.isHost && payload && payload.contentId === session.contentId) {
                const plan = cleanPlan(payload.plan);
                if (plan) await broadcast({ type: 'PLAN', payload: plan });
            }
            break;

        // ホストが上映を終了した。ゲストの再生タブは、合わせるのをやめて止まる
        case 'video-stopped':
            session.roomVideo = false;
            if (!session.isHost) await broadcast({ type: 'STOP' });
            await pushSession();
            break;

        case 'update-video-state':
            session.roomVideo = Boolean(payload && payload.contentId);
            // ホストとして入ったルームに、もう作品が出ている（ブラウザを開き直して「前のルームに戻る」など）→ 上映中として続ける
            if (session.isHost && session.roomVideo && !session.airing) {
                session.airing = true;
                session.sharedContentId = payload.contentId;
                session.sharedService = typeof payload.service === 'string' ? payload.service : null;
                session.sharedTitle = payload.contentId === session.contentId ? (session.title || '') : '';
                await pushSession();
            }
            if (!session.isHost && payload && payload.contentId === session.contentId) {
                const plan = cleanPlan(payload.plan);
                if (plan) await broadcast({ type: 'PLAN', payload: plan });
            }
            // ホストが作品を選び直している間（保留中）は、前の作品の位置に合わせない
            if (payload && payload.hold) break;
            if (payload && payload.contentId) {
                // 別の作品へ移動する場合、ここで APPLY しても遷移前のページに届くだけ。
                // 遷移先でプレイヤーが準備できた時点（PLAYER_READY）で改めて取りに行く。
                if (await followContent(payload)) break;
                // ホストがまだ再生していない（先頭で停止）ときも「止まって待つ」を伝える
                await broadcast({
                    type: 'APPLY',
                    payload: {
                        type: payload.isPlaying ? 'play' : 'pause',
                        currentTime: payload.currentTime,
                        timestamp: payload.lastUpdate
                    }
                });
            }
            break;

        case 'change-video':
            if (!session.isHost) session.roomVideo = true;
            await followContent(payload);
            break;

        case 'receive-message': {
            if (!payload || typeof payload.content !== 'string') break;
            const msg = {
                type: payload.type === 'system' ? 'system' : 'user',
                senderId: payload.senderId || null,
                username: payload.username || null,
                isHost: payload.isHost === true,   // サーバーが判定したホストの発言（👑 を付ける）
                color: payload.color || null,
                content: payload.content,
                timestamp: payload.timestamp || null
            };
            session.chat = [...session.chat, msg].slice(-CHAT_KEEP);
            await saveSession();
            await broadcast({ type: 'CHAT', payload: msg });
            // ポップアウトしたチャット窓（chat.html）はタブの一覧に入らないので別に送る。
            // 開いていなければ reject されるだけなので握る
            chrome.runtime.sendMessage({ type: 'CHAT', payload: msg }).catch(() => {});
            break;
        }

        case 'chat-history': {
            // 入る前の発言（2026-09-14 ユーザー要望）。もう持っている発言は足さない
            if (!Array.isArray(payload)) break;
            const key = (m) => [m.timestamp, m.username, m.content].join('');
            const have = new Set(session.chat.map(key));
            const add = payload.slice(-CHAT_KEEP).filter(p => p && p.type === 'user' && typeof p.content === 'string')
                .map(p => ({ type: 'user', senderId: p.senderId || null, username: p.username || null, isHost: p.isHost === true,
                    color: p.color || null, content: p.content, timestamp: p.timestamp || null }))
                .filter(m => !have.has(key(m)));
            if (!add.length) break;
            session.chat = [...add, ...session.chat].slice(-CHAT_KEEP);
            await saveSession();
            for (const msg of add) {
                await broadcast({ type: 'CHAT', payload: msg });
                chrome.runtime.sendMessage({ type: 'CHAT', payload: msg }).catch(() => {});
            }
            break;
        }

        case 'action-rejected':
            console.warn('[wp] rejected by server:', payload);
            break;
    }
}

/**
 * ホストが選んだ作品へ追従する。
 * 既に同じ作品を開いていれば何もしない。別の作品なら対象タブを遷移させる。
 * @returns {Promise<boolean>} 遷移させたら true
 */
async function followContent(payload) {
    if (!payload || !payload.contentId) return false;
    if (payload.contentId === session.contentId) return false;
    if (session.isHost) return false;        // ホスト自身は動かさない
    if (typeof payload.url !== 'string' || !FOLLOWABLE_URL.test(payload.url)) return false;

    const tabs = await chrome.tabs.query({ url: SITE_MATCHES });
    if (tabs.length === 0) {
        // 対象サイトを開いていなければ新しいタブで開く
        await chrome.tabs.create({ url: payload.url });
        return true;
    }

    // 見ているタブを優先する
    const target = tabs.find(t => t.active) || tabs[0];
    await chrome.tabs.update(target.id, { url: payload.url, active: true });
    return true;
}

// --- ルームへの出入り -------------------------------------------------------

async function enterRoom(msg) {
    resetRoomState();
    if (msg.type === 'JOIN_ROOM') {
        session.roomId = String(msg.roomId || '').trim().toUpperCase();
        session.username = msg.username;
        session.isHost = false;
        await saveSession();
        await ensureConnection().connect(session.serverUrl);
        return publicSession();
    }
    // RESUME_ROOM … ブラウザを開き直したホストが、前に作ったルームへ同じコードで戻る（ゲストは送り直し不要）
    const resume = msg.type === 'RESUME_ROOM' && lastRoom;
    // ホストがコードを決めたならそれを使う（形がおかしければ自動。2026-09-21 ユーザー要望）
    session.roomId = resume ? lastRoom.roomId : (cleanRoomId(msg.roomId) || generateRoomCode());
    session.username = resume ? lastRoom.username : msg.username;
    await rememberRoom();
    session.isHost = true;      // 最終的な判定はサーバーが返す
    // 覚えている作品は古いかもしれない（前のルームの作品を配って事故になった）。
    // いま開いているページから読み取り直す。届いた時点で PAGE_INFO が共有する
    session.service = null;
    session.contentId = null;
    session.url = null;
    await saveSession();
    await requestPageInfo();
    await ensureConnection().connect(session.serverUrl);
    return publicSession();
}

async function leaveRoom() {
    if (conn) conn.disconnect();
    const server = session.serverUrl;
    session = blankSession();
    session.serverUrl = server;
    await pushSession();
}

// 「休む」にしたらルームから抜ける。「前のルームに戻る」は残す（また「使う」にしたとき同じコードで戻れる）
chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.paused || changes.paused.newValue !== true) return;
    enqueue(async () => { if (session.roomId) await leaveRoom(); });
});

// --- メッセージ受付 -------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    // 接続層からのイベントはそちらのリスナーが拾うので無視する
    if (msg.channel) return;

    enqueue(() => handleMessage(msg, sender)).then(sendResponse, () => sendResponse(null));
    return true;   // 非同期応答
});

async function handleMessage(msg, sender) {
    switch (msg.type) {
        case 'GET_SESSION':
            return publicSession();

        case 'CREATE_ROOM':
        case 'RESUME_ROOM':
        case 'JOIN_ROOM':
            if (await WP.isPaused(chrome)) return publicSession();
            return enterRoom(msg);

        case 'LEAVE':
            await forgetRoom();
            await leaveRoom();
            return publicSession();

        case 'GET_CHAT':
            return session.chat;

        // チャットを別ウィンドウに出す（動画に重ねたくない・別のモニターに置きたいとき）。
        // すでに開いていれば、新しく作らずその窓を前に出す
        case 'OPEN_CHAT_WINDOW':
            await openChatWindow();
            return { ok: true };

        case 'SEND_CHAT': {
            const text = typeof msg.text === 'string' ? msg.text.trim().slice(0, 500) : '';
            if (text && session.connected) ensureConnection().emit('send-message', { message: text });
            return { ok: true };
        }

        // ホストの副音声（ポップアップの 🎙 と、マイクの許可を取るページ mic.html から）
        case 'VOICE_START':
            if (session.isHost && session.connected) {
                session.voice = { ...blankVoice(), state: 'connecting' };
                await voiceCommand('start');
                await pushSession();
            }
            return publicSession();

        case 'VOICE_STOP':
            await voiceCommand('stop');
            session.voice = blankVoice();
            await pushSession();
            return publicSession();

        case 'VOICE_MUTE':
            if (session.voice.state !== 'off') await voiceCommand('mute', { muted: msg.muted === true });
            return publicSession();

        case 'TRANSFER_HOST': {
            // 権限の確認はサーバーが行う。ここでは無駄な送信をしないだけ
            if (session.isHost && session.connected && msg.targetId) {
                ensureConnection().emit('transfer-host', { targetId: msg.targetId });
            }
            return publicSession();
        }

        case 'SET_SERVER': {
            session.serverUrl = msg.serverUrl || WP.DEFAULT_SERVER;
            await saveSession();
            return publicSession();
        }

        case 'PAGE_INFO': {
            const changed = msg.payload.contentId !== session.contentId;
            session.service = msg.payload.service;
            session.contentId = msg.payload.contentId;
            session.url = msg.payload.url;
            // 作品の名前（ページの題）。題はあとから入ることがあるので、同じ作品でも新しいものに置き換える
            const pageTitle = typeof msg.payload.title === 'string' ? msg.payload.title.slice(0, 60) : '';
            const titleFilled = Boolean(pageTitle) && pageTitle !== session.title;
            if (pageTitle || changed) session.title = pageTitle;
            // 送ってある作品の名前が、あとから分かった（パネルの「上映中：」に出す）
            if (titleFilled && session.airing && session.contentId === session.sharedContentId && session.sharedTitle !== pageTitle) {
                session.sharedTitle = pageTitle;
                if (!changed) await pushSession();
            }
            if (changed) { session.appId = null; session.plan = null; }   // 別の作品。前の作品の内部 ID・広告の位置は使わない
            if (changed) await pushSession();
            else await saveSession();

            /*
             * ホストが別の作品へ移ったら、自動では送らず「保留」にしてホストに知らせる（2026-09-14）。
             * 最初の作品だけはそのまま送る。送ってある作品に戻ってきたら、保留を解いて送り直す。
             */
            if (changed && session.isHost && session.connected && session.contentId && session.airing) {
                // 送ってあるドラマのページ（シーズン）で話の再生が始まった → その話をそのまま送る（ゲストは話を選べないので）。
                // 話から次の話へ移ったときは、今までどおり保留してホストに確かめる
                const firstEpisode = typeof msg.payload.pageContentId === 'string' &&
                    msg.payload.pageContentId === session.sharedContentId;
                if (session.contentId === session.sharedContentId || firstEpisode) sendTitle();
                else holdTitle();
                await pushSession();
            }
            return publicSession();
        }

        // 同じページのまま作品が変わったらしい（Prime の次の話の自動再生など。bridge.js が動画の長さで気づく）
        case 'TITLE_CHANGED': {
            if (session.isHost && session.connected) {
                holdTitle();
                await pushSession();
            }
            return publicSession();
        }

        // ホストが「今の作品をゲストに送る」を押した
        case 'SEND_TITLE': {
            if (session.airing && sendTitle()) await pushSession();
            return publicSession();
        }

        // 上映の ON/OFF（ホストが押す。2026-10-14）
        case 'AIR_START': {
            if (startAiring()) await pushSession();
            return publicSession();
        }
        case 'AIR_STOP': {
            if (stopAiring()) await pushSession();
            return publicSession();
        }

        // スマホのアプリを開くための内部 ID（Prime の GTI）。作品情報とは別便で届く
        case 'VIDEO_META': {
            const p = msg.payload || {};
            // 届くまでの間に別の作品へ移っていたら捨てる
            // 広告の入る位置（Prime）もこの別便で届く（2026-09-14）
            const plan = cleanPlan(p.plan);
            if ((!p.appId && !plan) || p.contentId !== session.contentId) return { ok: false };
            if (p.appId) session.appId = p.appId;
            if (plan) session.plan = plan;
            await saveSession();
            shareVideoMeta();
            return { ok: true };
        }

        case 'PLAYER_READY': {
            // ゲストのプレイヤーが準備できたら、ホストの現在位置を取りに行く
            if (!session.isHost && session.connected) {
                ensureConnection().emit('request-sync');
            }
            return { ok: true };
        }

        case 'DIAG': {
            // 開発用の記録。サーバーのログに残して、見分け方が合っているか後で確かめる
            if (session.connected) {
                ensureConnection().emit('diag', {
                    ...msg.payload,
                    role: session.isHost ? 'host' : 'guest',
                    username: session.username
                });
            }
            return { ok: true };
        }

        case 'PLAYER_EVENT': {
            // ゲストの操作はサーバー側でも弾かれるが、無駄な送信をしない
            // 作品が変わって保留中は送らない（ゲストが前の作品のまま、新しい作品の時刻に合わせてしまうため）
            // 上映していない間も送らない（ゲストは待合室。ホストは先に作品を開いて準備できる）
            if (session.isHost && session.connected && session.airing && !session.titlePending) {
                ensureConnection().emit('sync-video', msg.payload);
            }
            return { ok: true };
        }
    }
}

/** 副音声の命令を offscreen へ渡す（Firefox の接続には副音声が無い） */
async function voiceCommand(cmd, extra) {
    const c = ensureConnection();
    if (typeof c.voice === 'function') await c.voice(cmd, extra);
}

/** ホストでなくなったら副音声を止める（サーバーも止めている） */
function stopVoiceIfGuest() {
    if (session.isHost || session.voice.state === 'off') return;
    voiceCommand('stop');
    session.voice = blankVoice();
}

/** 対象サイトのタブに、開いている作品を知らせ直すよう頼む。見ているタブがあればそれだけに */
async function requestPageInfo() {
    const tabs = await chrome.tabs.query({ url: SITE_MATCHES });
    const active = tabs.filter(t => t.active);
    for (const tab of (active.length ? active : tabs)) {
        chrome.tabs.sendMessage(tab.id, { type: 'REQUEST_INFO' }).catch(() => {});
    }
}

/** サーバー設定と「いま開いている作品」は残し、ルーム関連だけ初期化する */
function resetRoomState() {
    session.connected = false;
    session.roomId = null;
    session.username = null;
    session.isHost = false;
    session.socketId = null;
    session.participants = [];
    session.chat = [];
    session.sharedContentId = null;
    session.titlePending = false;
    session.airing = false;
    session.sharedTitle = '';
    session.sharedService = null;
    session.roomVideo = false;
    if (session.voice.state !== 'off') voiceCommand('stop');
    session.voice = blankVoice();
}

/*
 * ルームのコード。招待リンクに入るので、友達が打つことはない（2026-09-16 に 6 → 8 文字）。
 * 短いと、つなぎ直しながら総当たりで部屋を探し当てられる恐れがある（入ってもチャットと再生位置が見えるだけだが、
 * 覗き見は防ぎたい）。サーバー・招待ページ・スクリプトは 4〜12 文字を受け付けるので、友達側の入れ直しは要らない。
 */
/**
 * ホストが打ったルームコードを整える（2026-09-21）。小文字は大文字に直す。
 * サーバーが受け付けるのは英数字の4〜12文字なので、それに合わなければ null（＝自動で作る）。
 */
function cleanRoomId(v) {
    if (typeof v !== 'string') return null;
    const s = v.trim().toUpperCase();
    return /^[A-Z0-9]{4,12}$/.test(s) ? s : null;
}

function generateRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // 紛らわしい I,O,0,1 は除く
    /*
     * **Math.random は使わない**（2026-09-20）。あれは速さのための乱数で、出力をいくつか集めると
     * 次に出る値が読める作りになっている。部屋コードは「当てられないこと」が前提なので、
     * ブラウザの暗号用の乱数から作る。文字が32種で 256 の約数なので、余りを取っても偏らない。
     */
    const bytes = crypto.getRandomValues(new Uint8Array(8));
    let code = '';
    for (const b of bytes) code += chars.charAt(b % chars.length);
    return code;
}

// 拡張機能を読み込み直すと、開いているページの content script は切り離され
// 二度と通信できなくなる。開発版（ストア経由でない）なら対象タブを読み込み直す。
// ストア版で視聴中のタブを勝手に再読み込みはしない（ui.js が再読み込みを促す）。
chrome.runtime.onInstalled.addListener(async () => {
    if (chrome.runtime.getManifest().update_url) return;
    const tabs = await chrome.tabs.query({ url: SITE_MATCHES });
    for (const tab of tabs) chrome.tabs.reload(tab.id).catch(() => {});
});

// service worker は30秒ほどで止まり、offscreen からのイベントで起こされる。
// 起きた直後にイベントの受け口が無いと取りこぼすので、起動時に必ず用意しておく。
ensureConnection();
