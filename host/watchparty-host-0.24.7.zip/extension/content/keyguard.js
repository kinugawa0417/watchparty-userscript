// Watch Party 0.24.7（配布用）
/**
 * チャット欄に入力している間のキー操作を、ページ（プレイヤー）に渡さない。
 *
 * Prime も Netflix もスペースで一時停止、矢印で送る、F で全画面、などのキーを受け取る。
 * 何もしないと、チャットで空白を打つたびに動画が止まる。
 *
 * 入力欄で止めるだけでは足りない。ページが window や document で「捕捉（capture）」の
 * 段階に受け取っていると、入力欄に届く前に反応してしまう。そこで document_start
 * （ページのスクリプトより先）に window の捕捉段階で受け取り、チャット欄からのキーなら
 * そこで打ち切る。打ち切っても文字の入力そのもの（既定の動作）は妨げない。
 */
(() => {
    if (window.top !== window) return;
    // chat.js / ui.js と同じ値。どちらにも人が文字を打つ入力欄がある
    const OUR_HOSTS = new Set(['wp-chat-host', 'wp-overlay-host']);

    function fromOurs(e) {
        for (const node of e.composedPath()) {
            if (node && OUR_HOSTS.has(node.id)) return true;
        }
        return false;
    }

    for (const type of ['keydown', 'keyup', 'keypress']) {
        window.addEventListener(type, (e) => {
            if (fromOurs(e)) e.stopImmediatePropagation();
        }, true);
    }
})();
