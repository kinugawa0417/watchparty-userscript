// Watch Party 0.24.7（配布用）
/**
 * 各レイヤー間で共有する定数。
 *
 * background / popup / offscreen / ISOLATED world の content script（ui.js）から使う。
 * いずれもクラシックスクリプトなので globalThis へ載せる形にしている。
 *
 * ※ MAIN world の bridge.js では読み込まない。Chrome は複数の content_scripts
 *   エントリに同じファイルがあると1回しか注入しないため、MAIN 側に入れると
 *   ui.js 側で WP が未定義になる（これで ui.js が全メッセージを捨てていた）。
 *   bridge.js は自分で必要な定数を持っている。
 */
globalThis.WP = Object.freeze({
    // background <-> connection layer
    CONN_CMD: 'wp:conn:cmd',
    CONN_EVT: 'wp:conn:evt',

    // popup / content <-> background
    MSG: 'wp:msg',

    // MAIN world <-> ISOLATED world（window.postMessage の識別子）
    // bridge.js にも同じ値を書いてある。変えるときは両方変えること。
    SRC_BRIDGE: 'wp-bridge',
    SRC_UI: 'wp-ui',

    // 公開している同期サーバー（Fly.io 東京。server/fly.toml）。
    // 手元で試すときはポップアップの「同期サーバー」に http://localhost:3000 を入れる
    DEFAULT_SERVER: 'https://wp-sync-w4kqv7.fly.dev',

    /**
     * 友達（スマホ）の画面。インストール不要の普通のページ（tools/build-page.js）を Cloudflare Pages に置いた、
     * **版ごとのアドレス**（中身をあとから差し替えられない）。同期サーバーは画面を配らない
     * （乗っ取られても偽の画面を出せないようにするため。2026-09-14）。
     * tools/publish-page.js が公開して、ここを書き換える。手で書き換えないこと。
     */
    HUB_URL: 'https://cc8b1c0f.watchparty-hub.pages.dev/',

    /**
     * Prime 用の固定版スクリプトのインストール先（Prime を見る人だけが入れる。案内は友達の画面に出る）。
     * **GitHub のコミット番号で固定したリンク**なので、あとから中身を差し替えられない。
     * tools/publish-userscript.js が公開して、ここを書き換える。手で書き換えないこと。
     */
    USERSCRIPT_URL: 'https://raw.githubusercontent.com/kinugawa0417/watchparty-userscript/c0e175933d27b62d71c63cc30418fdb8bea9fbfc/watchparty.user.js',
    // 上のスクリプトの版と公開日。友達の画面が、入っているスクリプトの版と比べて「更新されました（日付）」を出す
    USERSCRIPT_VERSION: '0.24.7',
    USERSCRIPT_DATE: '2026-09-16',

    /**
     * 友達（スマホ）へ送る招待の文面。ポップアップとページ上のパネルの両方から使う。
     *
     * openExternalBrowser=1 は LINE 専用の指定で、**LINE の中のブラウザではなく Safari で開かせる**
     * （LINE の中からだと Netflix アプリが起動しない）。LINE 以外では無視される。
     * #wp=ルームコード は画面が読んで、コードを入力済みの状態で開く。
     * 接続先は画面に組み込んだ公開サーバーで固定なので、serverUrl は使わない（引数は互換のため残す）。
     * Prime の準備（スクリプトのインストール）は、Prime のときだけ画面が案内するので、ここには書かない。
     */
    inviteText(serverUrl, roomId) {
        return 'いっしょに見よう！\n' +
            '下のリンクを開いて、なまえを入れると参加できます。\n' +
            globalThis.WP.inviteUrl(roomId);
    },

    /**
     * 参加者のずれの表示（2026-09-14）。再生タブ（スクリプト）がホストと比べて知らせてくる（サーバーの sync-report）。
     * 5秒未満なら出さない。止まったままなら「止まっています」
     */
    driftLabel(p) {
        if (!p || typeof p !== 'object') return '';
        if (p.stalled === true) return '⚠ 再生が止まっています';
        const d = typeof p.drift === 'number' && Number.isFinite(p.drift) ? p.drift : null;
        if (d === null || Math.abs(d) < 5) return '';
        const a = Math.round(Math.abs(d));
        const len = a >= 60 ? `${Math.floor(a / 60)}分${a % 60 ? (a % 60) + '秒' : ''}` : `${a}秒`;
        return `⚠ ${len}${d > 0 ? '先' : '遅れ'}`;
    },

    /** 招待のリンクだけ（「URLだけコピー」用。2026-09-14） */
    inviteUrl(roomId) {
        return `${globalThis.WP.HUB_URL}?openExternalBrowser=1#wp=${roomId}`;
    },

    /**
     * スマホのような狭い画面かどうか（chat.js と ui.js が表示を切り替えるのに使う）。
     *
     * CSS のメディアクエリだけでは足りない。ページが固定幅の viewport を宣言していると、
     * スマホで見ていても「幅 1000px の画面」として描かれるため（Amazon のパソコン向け
     * ページが実際にそうで、テストでは 1001px になった）。
     * そこで「指で触る画面 かつ 端末の画面そのものが小さい」も狭い画面として扱う。
     *
     * 判定した結果は、表示を出す側が host 要素の data-compact 属性に書く。
     * CSS はその属性を見る（:host([data-compact])）ので、決め方はここ1か所で済む。
     */
    isCompact() {
        const mm = globalThis.matchMedia;
        if (typeof mm !== 'function') return false;
        // 幅700px以下 … スマホ縦 / 高さ560px以下 … スマホ横・小さいウィンドウ
        if (mm('(max-width: 700px), (max-height: 560px)').matches) return true;
        const screen = globalThis.screen;
        if (!screen || !mm('(pointer: coarse)').matches) return false;
        return Math.min(screen.width, screen.height) <= 700;
    }
});
