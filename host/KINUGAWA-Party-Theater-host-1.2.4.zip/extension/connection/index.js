// KINUGAWA Party Theater 1.2.4（配布用）
/**
 * 接続保持層の入り口。
 *
 * 上位（background.js）からは connect / emit / onEvent / disconnect の
 * 4つしか見えない。offscreen document を使うか、その場に socket を持つかは
 * ここで吸収する。Android 対応で増えるのはこの下だけで済む。
 */
(() => {
    globalThis.WPConn = globalThis.WPConn || {};

    globalThis.WPConn.create = function create() {
        const hasOffscreen = typeof chrome !== 'undefined' && Boolean(chrome.offscreen);
        const Impl = hasOffscreen ? globalThis.WPConn.Chromium : globalThis.WPConn.Firefox;
        if (!Impl) throw new Error('no connection implementation available');
        console.log('[wp] connection impl:', hasOffscreen ? 'chromium/offscreen' : 'firefox/eventpage');
        return new Impl();
    };
})();
