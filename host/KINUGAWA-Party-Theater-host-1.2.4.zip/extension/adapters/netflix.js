// KINUGAWA Party Theater 1.2.4（配布用）
// Watch Party adapters/netflix.js（2026-09-16 Defender の誤検知で消されたため、同じ中身で戻したもの）
/**
 * Netflix アダプタ。
 *
 * Prime と違い、<video> に currentTime を代入しても効かない。
 * Netflix は自前の再生状態を持っていて、代入した値をすぐ書き戻してしまう。
 * そのためページ内部の API を使う（MAIN world で動いているので触れる）:
 *
 *   netflix.appContext.state.playerApp.getAPI().videoPlayer
 *     .getAllPlayerSessionIds()            … 動いているプレイヤーの一覧
 *     .getVideoPlayerBySessionId(id)       … 個々のプレイヤー
 *
 * プレイヤーの時間は**ミリ秒**。このアダプタが外に見せる時間は秒なので、
 * 出入りのたびに直している（ここを間違えると1000倍ずれる）。
 *
 * 一覧には作品ページのプレビュー再生なども混ざる。本編は `watch-` で始まる
 * セッションなので、それだけを採る（Prime の「長さで選ぶ」に当たる部分）。
 */
(() => {
    const Base = globalThis.WPAdapters.Base;

    // /watch/81234567 と /title/81234567。ロケール付き（/jp-en/ など）もある
    const NETFLIX_ID = /netflix\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:watch|title)\/(\d{4,12})(?=[/?#]|$)/;

    // 本編のプレイヤーのセッション ID の目印。プレビュー再生と区別する
    const WATCH_SESSION = /^watch-/;

    const RESCAN_MS = 1000;

    /*
     * シークの検出。
     * Netflix のプレイヤーは API で動かすので、人がシークバーを動かしたときに
     * <video> の seeked が出ないことがある（MSE のバッファを差し替えるため）。
     * 時計の進みと再生位置の進みを 250ms ごとに比べ、食い違ったらシークとみなす。
     * 逆に、読み込み待ちで止まった場合は位置が「進まない」だけなので誤検出しない。
     */
    const WATCH_MS = 250;
    const JUMP_SEC = 2.0;
    // seeked と時間の飛びの両方で気づくことがある。近い時刻のものは1回にまとめる
    const SEEK_DEDUPE_MS = 1000;

    /*
     * 再生・停止の押し直し。
     * シークの直後など、プレイヤーが play() / pause() を取りこぼすことがある。
     * Prime ほど癖は強くないので、短い間だけ確かめ直す。
     */
    const ENFORCE_MS = 2000;
    const ENFORCE_TICK_MS = 250;

    /*
     * 「まだ見ていますか？」（interrupter）。
     * 一定時間操作が無いと Netflix は再生を止めて確認を出す。ホストが止まると全員が止まるので、
     * ホストのときだけ自動で「続けて見る」を押す（ユーザーの判断。ゲストは自分で押す）。
     *
     * ダイアログには「一覧へ戻る」も並んでいる。押し間違えると視聴会が終わってしまうので、
     * 「進む側」だと確信できるものだけを押す。
     */
    const INTERRUPT_SCOPE = '[data-uia*="interrupt" i], .interrupter, .interrupter-actions';
    // role="dialog" は他の用途でも使われるので、それだけでは信じない。文面で確かめる
    const STILL_WATCHING = /まだ見ていますか|まだ視聴していますか|still\s*watching/i;
    const INTERRUPT_GO = /continue|play|still.?watch/i;         // data-uia が進む側を名乗っている
    const INTERRUPT_BACK = /back|browse|exit|cancel|戻|一覧|終了/i;   // これは絶対に押さない
    const INTERRUPT_TEXT =
        /^(続けて(見る|再生|視聴)(する)?|はい[、,]?\s*まだ見ています|まだ見ています|continue\s*watching|continue|yes,?\s*i'?m\s*still\s*watching)$/i;
    // 押したあと、画面が変わるまでの間に何度も押さない
    const INTERRUPT_COOLDOWN_MS = 10_000;

    /*
     * 広告（広告つきプラン）。2026-09-12 に実機で確かめた:
     *   - player.getAdManager().getPresentingAdBreak() が、広告中だけ広告枠を返す
     *   - 広告中は canSeek() が false（シークを受け付けない）
     *   - getCurrentTime() は広告の時間も含んで進む（Prime と同じ）
     *   - 広告枠の locationMs は「広告を除いた本編の時間」での位置で、広告が流れても変わらない
     * 詳しくは _watchAds() の説明。
     */
    const AD_WATCH_MS = 250;

    // プレイヤーの入れ物。Netflix のクラス名は難読化されるが、この辺りは比較的長く使われている
    const PLAYER_SCOPE = '.watch-video, [data-uia="video-canvas"], .VideoContainer';
    const PLAYER_VIDEO = PLAYER_SCOPE.split(', ').map(s => `${s} video`).join(', ');

    class NetflixAdapter extends Base {
        static get service() { return 'netflix'; }

        static match(url) {
            return /^https:\/\/www\.netflix\.com\//.test(url);
        }

        constructor() {
            super();
            this._player = null;
            this._sessionId = null;
            this._video = null;
            this._detach = null;
            this._rescanTimer = null;
            this._watchTimer = null;
            this._enforceTimer = null;
            this._want = null;          // 'play' | 'pause' | null
            this._wantUntil = 0;
            this._lastSeekAt = 0;
            this._lastTime = null;      // 飛びの検出用（秒）
            this._lastWallMs = 0;
            this._lastPaused = null;    // 再生/停止の変化を1回だけ知らせるため
            this._lastDismissAt = 0;
            this._adOpen = null;        // いま流れている広告枠
            this._adTimer = null;
            // 生の位置と本編の時間の対応。広告が明けるたびに増える（_watchAds）
            this._anchors = [{ content: 0, raw: 0 }];
        }

        async ready() {
            await Base.waitFor(() => this._pickPlayer(), { timeoutMs: Infinity });
            this._watchForReplacement();
            this._watchJumps();
            this._watchAds();
            return this;
        }

        // --- プレイヤーの取得 ---------------------------------------------------

        /** ページ内部の videoPlayer。まだ読み込まれていなければ null */
        _videoPlayerApi() {
            const app = globalThis.netflix?.appContext?.state?.playerApp;
            const api = app?.getAPI?.();
            return api?.videoPlayer || null;
        }

        /**
         * 本編のプレイヤーを掴む。掴めていれば true。
         * エピソードが変わるとセッションごと作り直されるので、定期的に見直す。
         */
        _pickPlayer() {
            const vp = this._videoPlayerApi();
            if (!vp) return false;

            let ids = [];
            try { ids = vp.getAllPlayerSessionIds() || []; } catch { return false; }
            const id = ids.find(s => WATCH_SESSION.test(String(s)));
            if (!id) return false;

            if (id === this._sessionId && this._player) {
                this._bindVideo();
                return true;
            }

            let player;
            try { player = vp.getVideoPlayerBySessionId(id); } catch { return false; }
            // 長さが決まるまでは操作しても効かない
            if (!player || !(Number(player.getDuration?.()) > 0)) return false;

            this._sessionId = id;
            this._player = player;
            this._lastTime = null;
            this._lastPaused = null;
            // 別の話数になったら時間の数え方も始め直し
            this._adOpen = null;
            this._anchors = [{ content: 0, raw: 0 }];
            this._bindVideo();
            console.log('[wp] netflix: player', id, this.getDuration());
            return true;
        }

        /**
         * イベントを取るための <video>。
         * 再生の操作は API で行うが、人が押した再生・停止に気づくには要素のイベントが早い。
         */
        _pickVideo() {
            const inPlayer = document.querySelector(PLAYER_VIDEO);
            if (inPlayer) return inPlayer;
            const all = Array.from(document.querySelectorAll('video')).filter(v => v.isConnected);
            if (all.length === 0) return null;
            // 画面に出ている中で最も大きいもの（プレビューの小窓を避ける）
            return all.reduce((a, b) =>
                b.getBoundingClientRect().width > a.getBoundingClientRect().width ? b : a);
        }

        _bindVideo() {
            const video = this._pickVideo();
            if (!video || this._video === video) return;
            if (this._detach) this._detach();
            this._video = video;

            const onPlay = () => {
                if (this._activeWant() === 'pause') return this._reconcile();
                this._emitPlayback(false);
            };
            const onPause = () => {
                if (video.seeking) return;   // シークに伴う停止はプレイヤーの都合
                if (this._activeWant() === 'play') return this._reconcile();
                this._emitPlayback(true);
            };
            const onSeeked = () => this._emitSeek();

            video.addEventListener('play', onPlay);
            video.addEventListener('pause', onPause);
            video.addEventListener('seeked', onSeeked);
            this._detach = () => {
                video.removeEventListener('play', onPlay);
                video.removeEventListener('pause', onPause);
                video.removeEventListener('seeked', onSeeked);
            };
        }

        _watchForReplacement() {
            if (this._rescanTimer) return;
            this._rescanTimer = setInterval(() => this._pickPlayer(), RESCAN_MS);
        }

        // --- 状態の変化の検出 ----------------------------------------------------

        /**
         * 再生／停止が変わったことを1回だけ知らせる。
         * 要素のイベントからも、下の見張り（_watchJumps）からも呼ばれるので、
         * 同じ変化を二度送らないようここでまとめる。
         */
        _emitPlayback(paused) {
            if (this._lastPaused === paused) return;
            this._lastPaused = paused;
            this._emit(paused ? 'pause' : 'play');
        }

        _emitSeek() {
            const now = Date.now();
            if (now - this._lastSeekAt < SEEK_DEDUPE_MS) return;
            this._lastSeekAt = now;
            // 飛んだ先を次の基準にする（同じ飛びを二度数えない）
            this._lastTime = this.getCurrentTime();
            this._lastWallMs = now;
            this._emit('seek');
        }

        /**
         * 時計の進みと再生位置の進みを比べ、食い違ったらシークとみなす。
         * あわせて再生／停止も見張る。Netflix のクラス名は難読化されていて変わるので、
         * <video> を見失ってイベントが来なくなっても、ここだけで気づけるようにしておく。
         */
        _watchJumps() {
            if (this._watchTimer) return;
            this._watchTimer = setInterval(() => {
                if (!this._player) return;
                // 広告の間は本編が止まって見える（時計だけ進む）。ここで見ると必ず食い違うので見ない。
                // 広告の出入りは _watchAds が別に見ている
                if (this._adOpen) { this._lastTime = null; return; }

                // 自分で合わせ込んでいる最中の変化は人の操作ではないので数えない
                if (!this._activeWant()) {
                    const paused = this.isPaused();
                    if (this._lastPaused === null) this._lastPaused = paused;
                    else this._emitPlayback(paused);
                }

                const t = this.getCurrentTime();
                const wall = Date.now();
                if (this._lastTime === null) {
                    this._lastTime = t;
                    this._lastWallMs = wall;
                    return;
                }
                const moved = t - this._lastTime;
                const elapsed = (wall - this._lastWallMs) / 1000;
                this._lastTime = t;
                this._lastWallMs = wall;
                // 再生していれば moved ≒ elapsed、止まっていれば moved ≒ 0。
                // どちらからも大きく外れたら、位置が飛んだということ
                const expected = this.isPaused() ? 0 : elapsed;
                if (Math.abs(moved - expected) > JUMP_SEC) this._emitSeek();
            }, WATCH_MS);
        }

        // --- 再生の状態 ---------------------------------------------------------

        /** プレイヤーが持っている生の再生位置（秒）。広告の時間も含んでいる */
        _rawTime() {
            const ms = this._player?.getCurrentTime?.();
            if (Number.isFinite(ms)) return ms / 1000;
            return this._video ? this._video.currentTime : 0;
        }

        /**
         * プレイヤーが持っている本編だけの位置（秒）。無ければ null。
         * 本物の Netflix（広告つきプラン）で確認（2026-09-15）: 冒頭の広告 31 秒が流れたあと、
         * getCurrentTime は 56 秒、getSegmentTime は 25 秒だった。広告の無い人では両方同じ。
         */
        _segmentTime() {
            try {
                const ms = this._player?.getSegmentTime?.();
                if (!Number.isFinite(ms) || ms < 0) return null;
                const sec = ms / 1000;
                // 生の位置（広告込み）より先になることはない。おかしな値は使わない
                return sec <= this._rawTime() + 1 ? sec : null;
            } catch { return null; }
        }

        /** 外に見せるのは「広告を除いた本編の時間」 */
        getCurrentTime() {
            // 広告中は本編が進んでいない。その広告枠の位置で止まって見える
            if (this._adOpen && Number.isFinite(this._adOpen.contentMs)) return this._adOpen.contentMs / 1000;
            const seg = this._segmentTime();
            if (seg !== null) return seg;
            return this._toContent(this._rawTime());
        }

        getDuration() {
            const ms = this._player?.getDuration?.();
            return Number.isFinite(ms) ? ms / 1000 : NaN;
        }

        isPaused() {
            const p = this._player;
            if (p) {
                if (typeof p.isPaused === 'function') return Boolean(p.isPaused());
                if (typeof p.isPlaying === 'function') return !p.isPlaying();
            }
            return this._video ? this._video.paused : true;
        }

        isPlayerOpen() {
            return Boolean(this._player);
        }

        /**
         * Prime は再生を始めると同じ作品の URL を書き換えるので無視する必要があったが、
         * Netflix の URL が変わるのは別の話数へ進んだときで、これは本当の作品の切り替え。
         * ゲストにも移ってもらう必要があるので無視しない。
         */
        ignoreUrlChange() { return false; }

        play() {
            if (!this._player) return;
            this._request('play');
            this._playNow();
        }

        pause() {
            if (!this._player) return;
            this._request('pause');
            this._player.pause?.();
        }

        _playNow() {
            try { this._player?.play?.(); } catch (e) { console.warn('[wp] play failed', e); }
        }

        /** 本編の時間で指定する（広告の分は中で足し戻す） */
        seek(seconds) {
            if (!this._player) return;
            // 広告中はプレイヤーがシークを受け付けない（canSeek() が false）
            if (this.isInAd()) return;

            /*
             * 本編だけの位置が読めるなら、「いまの生の位置 ＋ 本編での差」へ動かす。
             * 間の広告の長さが分からなくても、動いた先で読み直した差を次の合わせで詰めるので、2回目で合う
             * （広告枠の長さの一覧は、自動操作では 0 のままで当てにならなかった）
             */
            const seg = this._segmentTime();
            let raw = seg !== null
                ? Math.max(0, this._rawTime() + (Math.max(0, seconds) - seg))
                : this._toRaw(Math.max(0, seconds));
            const duration = this.getDuration();   // 生の長さ（広告込み）
            if (Number.isFinite(duration) && duration > 0) raw = Math.min(raw, duration);

            // 自分で動かした分は「人が飛ばした」と数えない。動かす前に印をつける
            // （プレイヤーによっては seek() の中で同期的に seeked が飛んでくる）
            this._lastSeekAt = Date.now();
            this._lastTime = Math.max(0, seconds);
            this._lastWallMs = this._lastSeekAt;
            // プレイヤーはミリ秒で受け取る
            this._player.seek?.(Math.round(raw * 1000));
        }

        releaseControl() {
            this._want = null;
            clearInterval(this._enforceTimer);
        }

        _activeWant() {
            if (this._want && Date.now() > this._wantUntil) this._want = null;
            return this._want;
        }

        _request(state) {
            this._want = state;
            this._wantUntil = Date.now() + ENFORCE_MS;
            clearInterval(this._enforceTimer);
            this._enforceTimer = setInterval(() => {
                if (!this._activeWant()) return clearInterval(this._enforceTimer);
                this._reconcile();
            }, ENFORCE_TICK_MS);
        }

        _reconcile() {
            const want = this._activeWant();
            if (!this._player || !want) return;
            if (this._video?.seeking) return;
            if (this.isInAd()) return;   // 広告中は触らない（止めると広告も止まる）
            if (want === 'play' && this.isPaused()) this._playNow();
            else if (want === 'pause' && !this.isPaused()) this._player.pause?.();
        }

        // --- 「まだ見ていますか？」 ------------------------------------------------

        /**
         * 「まだ見ていますか？」のダイアログを探す。
         * 見当違いの所を押さないよう、Netflix がそれと名乗っているものか、
         * 文面がそう読めるものだけを対象にする。
         */
        _interruptScope() {
            const named = document.querySelector(INTERRUPT_SCOPE);
            if (named) return named;
            for (const el of document.querySelectorAll('[role="dialog"]')) {
                if (STILL_WATCHING.test(el.textContent)) return el;
            }
            return null;
        }

        dismissInterruption() {
            if (Date.now() - this._lastDismissAt < INTERRUPT_COOLDOWN_MS) return false;
            const scope = this._interruptScope();
            if (!scope) return false;

            const buttons = Array.from(scope.querySelectorAll('button, [role="button"], a'))
                .filter(el => {
                    const r = el.getBoundingClientRect();
                    if (r.width < 10 || r.height < 10) return false;
                    const name = `${el.getAttribute('data-uia') || ''} ${el.getAttribute('aria-label') || ''}`;
                    return !INTERRUPT_BACK.test(name) && !INTERRUPT_BACK.test(el.textContent);
                });

            const btn = buttons.find(el => INTERRUPT_GO.test(el.getAttribute('data-uia') || ''))
                || buttons.find(el => INTERRUPT_TEXT.test(el.textContent.trim()));
            if (!btn) return false;

            this._lastDismissAt = Date.now();
            btn.click();
            this._reportDiag('interrupt-dismissed', {
                button: btn.getAttribute('data-uia') || btn.textContent.trim().slice(0, 30)
            });
            return true;
        }

        // --- 広告 ---------------------------------------------------------------

        _adManager() {
            try { return this._player?.getAdManager?.() || null; } catch { return null; }
        }

        /** いま流れている広告枠。広告中でなければ null */
        _presentingBreak() {
            const am = this._adManager();
            if (!am) return null;
            try { return am.getPresentingAdBreak() || null; } catch { return null; }
        }

        /**
         * 広告中か。
         * プレイヤー自身が「いまこの広告枠を出している」と教えてくれるので、
         * 画面の文字を読んで当てにいく必要がない（Prime はそれが無くて苦労した）。
         */
        isInAd() { return this._presentingBreak() !== null; }

        /**
         * 広告枠の本編上の位置（ミリ秒）。
         * 流れている枠そのものに locationMs があればそれを、無ければ番号（viewableAdBreakIndex / index）で一覧から引く。
         * 以前は index だけで引いていて、名前が違うと目印が足されず、生の位置（広告込み）をそのまま本編の時間として
         * 送っていた疑いがある（2026-09-14 ユーザー報告: Netflix でゲストが数分先へずれた）
         */
        _breakContentMs(brk) {
            if (brk && Number.isFinite(brk.locationMs)) return brk.locationMs;
            const am = this._adManager();
            if (!am || !brk) return null;
            const index = Number.isFinite(brk.viewableAdBreakIndex) ? brk.viewableAdBreakIndex : brk.index;
            try {
                const hit = (am.getAds() || []).find(a => a.viewableAdBreakIndex === index);
                return hit && Number.isFinite(hit.locationMs) ? hit.locationMs : null;
            } catch { return null; }
        }

        /**
         * 流し終わった広告枠の { 本編上の位置（秒）, 長さ（秒） }。
         * 枠の duration（{ ticks, timescale }）に、実際に流れた広告の長さが入る（本物の Netflix で形を確認。
         * 自動操作の Edge では広告が流れず 0 だったので、長さが入っているものだけ使う）
         */
        _playedBreaks() {
            const am = this._adManager();
            if (!am) return [];
            let list = [];
            try { list = am.getAds() || []; } catch { return []; }
            const sec = (d) => (d && Number.isFinite(d.ticks) && Number.isFinite(d.timescale) && d.timescale > 0 ? d.ticks / d.timescale : 0);
            return list
                .filter(b => b && (b.hasCompletedPlayback || b.hasPlayed) && Number.isFinite(b.locationMs))
                .map(b => ({ at: b.locationMs / 1000, len: sec(b.duration) || sec(b.normalizedAdsDuration) }))
                .filter(b => b.len > 0.5 && b.len < 600)
                .sort((a, b) => a.at - b.at);
        }

        /**
         * 広告の出入りを見張り、明けるたびに「生の位置」と「本編の位置」の対応（目印）を足す。
         *
         * 実機で確かめたこと（2026-09-12）:
         *   - getCurrentTime() は広告の時間も含んで進む（Prime と同じ）
         *   - 広告枠の locationMs は**本編の時間**での位置で、広告が流れても変わらない
         *     （実測: 広告枠 1273605ms + 広告 19922ms ≒ 広告明けの 1294100ms）
         * つまり広告が明けた瞬間の本編の位置は locationMs そのもの。そこを目印にすれば、
         * Prime のように広告の長さを測って足し込む必要がなく、誤差も積み重ならない。
         */
        _watchAds() {
            if (this._adTimer) return;
            this._adTimer = setInterval(() => {
                if (!this._player) return;
                const brk = this._presentingBreak();

                // 広告の出入りの記録は bridge.js が別に書いている（ここで書くと二重になる）
                if (brk && !this._adOpen) {
                    this._adOpen = {
                        index: Number.isFinite(brk.viewableAdBreakIndex) ? brk.viewableAdBreakIndex : brk.index,
                        contentMs: this._breakContentMs(brk),
                        rawStart: this._rawTime()
                    };
                } else if (!brk && this._adOpen) {
                    const raw = this._rawTime();
                    const open = this._adOpen;
                    this._adOpen = null;
                    if (Number.isFinite(open.contentMs)) {
                        this._addAnchor(open.contentMs / 1000, raw);
                    }
                }
            }, AD_WATCH_MS);
        }

        /**
         * 目印（生の位置 ↔ 本編の位置）を1つ足す。
         * 同じ広告枠をもう一度通ったら、新しいほうで置き換える。
         */
        _addAnchor(contentSec, rawSec) {
            this._anchors = this._anchors.filter(a => Math.abs(a.content - contentSec) > 0.5);
            this._anchors.push({ content: contentSec, raw: rawSec });
            this._anchors.sort((a, b) => a.content - b.content);
        }

        /** 生の位置 → 本編の時間 */
        _toContent(raw) {
            // 広告中は本編が進んでいない。その広告枠の位置で止まって見える
            if (this._adOpen && Number.isFinite(this._adOpen.contentMs)) {
                return this._adOpen.contentMs / 1000;
            }
            // 流し終わった枠の長さが分かれば、それを引く（目印が足されなかったときも正しく出せる）
            const played = this._playedBreaks();
            if (played.length) {
                let offset = 0;
                for (const b of played) { if (b.at <= raw - offset - b.len + 0.5) offset += b.len; }
                return Math.max(0, raw - offset);
            }
            let best = this._anchors[0];
            for (const a of this._anchors) { if (a.raw <= raw + 0.001) best = a; }
            return Math.max(0, best.content + (raw - best.raw));
        }

        /** 本編の時間 → 生の位置 */
        _toRaw(content) {
            const played = this._playedBreaks();
            if (played.length) {
                return Math.max(0, content + played.filter(b => b.at <= content + 0.001).reduce((sum, b) => sum + b.len, 0));
            }
            let best = this._anchors[0];
            for (const a of this._anchors) { if (a.content <= content + 0.001) best = a; }
            return Math.max(0, best.raw + (content - best.content));
        }

        describeForDiag() {
            const am = this._adManager();
            let ads = null, hasAds = null, canSeek = null;
            if (am) {
                try { hasAds = am.hasAds(); } catch { /* 取れない */ }
                try { canSeek = am.canSeek(); } catch { /* 取れない */ }
                try {
                    /*
                     * 広告枠に入っている数と真偽を全部出す（2026-09-14）。ホストもゲストも数分ずれた報告があり、
                     * 生の位置にまだ流れていない広告も含まれている（Prime と同じ）のではと疑っている。
                     * 枠の長さがどの名前で入っているか、自動操作の Edge では広告が出ないので実際の記録で確かめる
                     */
                    ads = (am.getAds() || []).slice(0, 20).map(a => {
                        const o = { i: a.viewableAdBreakIndex, atSec: Math.round(a.locationMs / 100) / 10, played: Boolean(a.hasCompletedPlayback) };
                        for (const k of Object.keys(a || {}).slice(0, 30)) {
                            const v = a[k];
                            if (typeof v === 'number' && Number.isFinite(v)) o[k] = Math.round(v);
                            else if (typeof v === 'boolean') o[k] = v;
                            else if (v && typeof v === 'object' && Number.isFinite(v.ticks)) o[k] = Math.round(v.ticks / (v.timescale || 1) * 10) / 10;
                            else if (Array.isArray(v)) o[k + '#'] = v.length;
                        }
                        return o;
                    });
                } catch { /* 取れない */ }
            }
            let sessions = [];
            try { sessions = (this._videoPlayerApi()?.getAllPlayerSessionIds() || []).map(String); } catch { /* 未読み込み */ }
            const raw = this._rawTime();
            const v = this._video;
            let segmentTime = null;
            try { const ms = this._player?.getSegmentTime?.(); segmentTime = Number.isFinite(ms) ? Math.round(ms / 100) / 10 : null; } catch { /* 無い */ }
            let presenting = null;
            try {
                const b = this._presentingBreak();
                if (b) {
                    presenting = {};
                    for (const k of Object.keys(b).slice(0, 30)) {
                        const x = b[k];
                        if (typeof x === 'number' || typeof x === 'boolean') presenting[k] = x;
                        else if (x && typeof x === 'object' && Number.isFinite(x.ticks)) presenting[k] = Math.round(x.ticks / (x.timescale || 1) * 10) / 10;
                    }
                }
            } catch { /* 取れない */ }
            return {
                // 調査用: getSegmentTime（本編だけの位置かもしれない）、流れている枠の中身、流し終わった枠の長さ
                segmentTime, presenting, played: this._playedBreaks(),
                videoTime: v ? Math.round(v.currentTime * 10) / 10 : null,
                videoDuration: v && Number.isFinite(v.duration) ? Math.round(v.duration) : null,
                sessionId: this._sessionId,
                sessions,
                rawTime: Math.round(raw * 10) / 10,
                contentTime: Math.round(this._toContent(raw) * 10) / 10,
                duration: Math.round(this.getDuration()),
                paused: this.isPaused(),
                inAd: this.isInAd(),
                hasAds,
                canSeek,
                ads,
                anchors: this._anchors.map(a => ({
                    content: Math.round(a.content * 10) / 10,
                    raw: Math.round(a.raw * 10) / 10
                }))
            };
        }

        // --- 作品 ---------------------------------------------------------------

        getContentId(url = location.href) {
            const m = url.match(NETFLIX_ID);
            return m ? m[1] : null;
        }

        buildUrl(contentId) {
            if (!contentId) return null;
            // /watch/ を開くと、ログイン済みならそのまま再生が始まる。
            // 未ログインならログイン画面を経由し、済ませるとこの URL へ戻る
            return `https://www.netflix.com/watch/${contentId}`;
        }
    }

    globalThis.WPAdapters.list.push(NetflixAdapter);
})();
