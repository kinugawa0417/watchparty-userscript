// KINUGAWA Party Theater 1.3.2（配布用）
/**
 * マイクの許可を取るページ（mic.html）。許可が取れたら副音声を始めてもらい、このタブを閉じる。
 * 許可はこの拡張機能のアドレスに付くので、offscreen（同じ拡張機能）でもマイクが使えるようになる。
 */
(() => {
    const $ = (id) => document.getElementById(id);

    async function ask() {
        $('retry').hidden = true;
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            // 許可を取るだけ。実際にマイクを使うのは offscreen なので、ここではすぐ離す
            stream.getTracks().forEach(t => t.stop());
            $('msg').textContent = '許可しました。副音声を始めます。このタブは閉じます。';
            await chrome.runtime.sendMessage({ type: 'VOICE_START' }).catch(() => {});
            setTimeout(() => window.close(), 1200);
        } catch (e) {
            $('msg').textContent = e && e.name === 'NotFoundError'
                ? 'マイクが見つかりません。マイク（またはヘッドセット）をつないでから、もう一度押してください。'
                : 'マイクが許可されませんでした。アドレスバー左の設定ボタンからマイクを「許可」にして、もう一度押してください。';
            $('retry').hidden = false;
        }
    }

    $('retry').addEventListener('click', ask);
    ask();
})();
