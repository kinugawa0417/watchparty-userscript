// KINUGAWA Party Theater 1.0.3（配布用）
/**
 * MAIN world 側のスクリプト。
 *
 * ページと同じ実行文脈で動くため、サービスのプレイヤーへ直接触れる。
 * 拡張機能 API は使えないので、ISOLATED world の ui.js とは
 * window.postMessage 経由でやり取りする。
 *
 * 役割は2つあり、準備できる時期が違うので分けて扱う。
 *   1. 作品の特定（URL から分かる。ページを開いた瞬間に送る）
 *   2. プレイヤーの操作（<video> が現れるまで待つ。再生ボタンを押すまで現れないこともある）
 */
(() => {
    // protocol.js はここでは読み込めない（理由は protocol.js の冒頭）ので、必要な定数を自前で持つ。
    const WP = Object.freeze({
        // window.postMessage の識別子。protocol.js と同じ値でなければならない
        SRC_BRIDGE: 'wp-bridge',
        SRC_UI: 'wp-ui',

        // リモート適用中に自分のイベントを送り返さないための保護時間
        ECHO_GUARD_MS: 700,

        // これ以上ズレていたらシークして合わせる（秒）
        SEEK_THRESHOLD_SEC: 1.0,

        // ホストが再生中に現在位置を送る間隔。途中参加やズレの補正に使う
        HEARTBEAT_MS: 5000,

        // 定期補正でシークするズレの下限（秒）。小さいとシークのたびに読み込みが挟まる
        DRIFT_THRESHOLD_SEC: 2.0,

        // 一時停止時、この秒数以内の遅れなら再生を続けて追いつく。それ以上はシークで合わせる
        FOLLOW_MAX_GAP_SEC: 3.0,

        // 追いつき待ちの期限。遅れは最大 FOLLOW_MAX_GAP_SEC 秒なので、本来は数秒で終わる。
        // これを過ぎても届かないなら、再生が止まっている（読み込み・サービス側の制限など）。
        // 待ち続けると定期補正が捨てられ続け、ゲストがずれたまま固まる（2026-09-12 の不具合）
        FOLLOW_TIMEOUT_MS: 5000,

        // プレイヤーが開いた直後は「止まって待つ」を後回しにする。冒頭の広告は開いた直後に
        // 始まるが、広告の表示が出るまで少しかかる。その間に止めると広告ごと止まってしまう。
        // 自分の動画がこれだけ進むか、広告が見つかるか、最長時間が過ぎるまで待つ
        STARTUP_PLAY_MS: 3000,
        STARTUP_MAX_MS: 15000,

        // サービス側の確認ダイアログ（Netflix の「まだ見ていますか？」）を見に行く間隔
        INTERRUPT_CHECK_MS: 2000
    });
    const isTop = window.top === window;

    let adapter = null;
    let bound = false;           // プレイヤーを掴めたか
    let applying = false;        // リモート適用中フラグ（自分のイベントを送り返さないため）
    let applyTimer = null;
    let targetPauseTime = null;  // 追従停止の目標位置
    let followTimer = null;
    let selfAd = false;          // 自分が広告を見ているか
    let hostAd = false;          // ホストが広告を見ているか（ホストの定期通知で知る）
    let hostPaused = false;      // ホストが止まっているか（表示用）
    let startup = false;         // プレイヤーが開いた直後か（STARTUP_*）
    let deferredStop = false;    // 開いた直後に「止まって待つ」を後回しにしたか
    let isHost = false;          // ui.js から教わる（このスクリプトは拡張機能の状態を直接見られない）
    let lastTickDropReport = 0;  // 調査用（follow から抜けられない件）。記録の間引きに使う
    /*
     * ゲストの動画が止まったまま動かないときの立て直し（2026-09-14 PC の Chrome）。
     * ホストは再生中なのに、ゲストの動画が読み込み中のくるくるのまま1分以上動かなかった。
     * ホストが一時停止→再生すると直った（ゲストが「止める→位置を合わせて再生」をやり直したため）。
     * 同じことを自動でやる: 一定時間（20秒。読み込みを待つ間は数えない）動かなければ、いったん止めてホストの今の位置を取り直す
     */
    const STUCK_MS = 20000;
    const KICK_GAP_MS = 20000;
    let lastApplyAt = 0;
    let lastTickTime = 0;
    let zeroTickOnce = false;
    let stuck = { lastT: null, movedAt: 0, kickAt: 0, kicks: 0, failed: 0 };
    /*
     * 続けて立て直せなかったら、それ以上は自動でやらない（2026-09-15 実機の記録）。
     * 立て直し（止める→位置を取り直して再生）は読み込みを最初からやり直させるので、繰り返すと余計に落ち着かなかった
     */
    const KICK_MAX_FAILED = 2;
    /*
     * ホストの再生中に追いつくとき（2026-09-15 ユーザー報告: PC の Chrome で、ホストが再生中だとゲストがくるくる回ったまま。
     * ホストが止まっていれば再生が始まって合う）。
     * 動いているホストの位置へ飛ぶと、読み込んでいる間にホストが先へ進み、次の知らせでまた飛ぶ…を繰り返して読み込みが終わらなかった。
     * そこで、読み込みにかかる時間ぶん先へ飛び、動き出すまで（最長 SETTLE_MS）は飛び直さずに待つ。
     * 先へ飛ぶ量は、実際に動き出すまでにかかった時間から覚え直す（はじめは 3 秒）
     */
    const SETTLE_MS = 20000;
    let settle = null;          // { at: 飛んだ時刻, started: 動き出したか }
    let loadLeadSec = 3;
    let rawLast = null;         // 生の再生位置の見張り（本編の時間の換算に左右されない）
    let rawMovedAt = 0;

    /**
     * 飛んだ先で読み込み中か。20 秒たっても、まだ読み込み中（seeking・データが足りない）なら最長 60 秒まで待つ
     * （途中で飛び直すと、読み込みが最初からになる）
     */
    function settlePending(now) {
        if (!settle || settle.started) return false;
        if (now - settle.at < SETTLE_MS) return true;
        const v = adapter._video;
        return Boolean(v) && !mediaLoaded(v) && now - settle.at < 60000;
    }

    /** 読み込みが済んでいるか（シーク中でなく、データがある）。中身を持たない <video>（テストの偽物）は済んでいる扱い */
    function mediaLoaded(v) {
        if (!v) return true;
        const hasMedia = Boolean(v.currentSrc || v.srcObject);
        return !v.seeking && (v.readyState >= 3 || !hasMedia);
    }

    /** ホストの位置（本編の時間）へ追いつく。ホストが再生中のときだけ使う */
    function catchUp(target, threshold) {
        const now = Date.now();
        if (settlePending(now)) {
            // 飛んだ先で読み込み中。飛び直さず、再生の指示だけ出して待つ
            if (adapter.isPaused()) adapter.play();
            return;
        }
        const diff = target - adapter.getCurrentTime();
        /*
         * 先へ飛んで動き出したあと、ホストより少し先にいる分（読み込みが見込みより早かった分）は、その秒数だけ止まって待つ。
         * しきい値（2秒）より小さい先行は飛び直しでは直らず、残っていた（2026-09-16 テスト: ホストの広告で止まる場面が 1.8 秒ずれた）
         */
        if (settle && settle.started && settle.lead > 0 && !settle.trimmed && diff < -0.4 && diff > -(settle.lead + 2)) {
            settle.trimmed = true;
            adapter.pause();
            const waitMs = Math.round(-diff * 1000);
            setTimeout(() => { if (!hostPaused && !hostAd) withEchoGuard(() => adapter.play()); }, waitMs);
            return;
        }
        if (Math.abs(diff) > threshold) {
            // 大きく離れている・まだ流れていないときは読み込みが要るので、その分だけ先へ
            const smooth = !adapter.isPaused() && now - rawMovedAt < 2000;
            const lead = Math.abs(diff) > 8 || !smooth ? loadLeadSec : 0;
            adapter.seek(target + lead);
            settle = { at: now, started: false, lead, target };
            post('DIAG', { event: 'catch-up', url: location.href, target: Math.round(target), lead, diff: Math.round(diff) });
        }
        if (adapter.isPaused()) adapter.play();
    }

    function post(type, payload) {
        window.postMessage({ source: WP.SRC_BRIDGE, type, payload }, location.origin);
    }

    /** リモート操作を適用する間だけイベント送出を止める */
    function withEchoGuard(fn) {
        applying = true;
        clearTimeout(applyTimer);
        try { fn(); } finally {
            applyTimer = setTimeout(() => { applying = false; }, WP.ECHO_GUARD_MS);
        }
    }

    function stopFollowing() {
        targetPauseTime = null;
        clearInterval(followTimer);
    }

    /**
     * ホストが止めた位置まで自分は再生を続けてから止まる。
     * 通信遅延で自分のほうが手前にいる場合、その場で止めると位置がズレるため。
     *
     * **必ず期限を設けること**（2026-09-12 の不具合）。追いつく前にゲストの再生が止まると
     * 目標に永遠に届かず、その間 `tick`（定期補正）が全部捨てられてゲストがずれたまま固まる。
     * 再生が止まる場面は珍しくない（読み込み、Netflix の同時視聴の制限など。
     * 実機テストで「ホスト再生中にゲストが30秒間に3回止まる」を観測している）。
     * 再現は `tools/repro-follow-stuck.js`。
     *
     * 様子は diag.log に残している（follow-start / follow-wait / follow-done / follow-timeout）。
     */
    function followUntil(time) {
        targetPauseTime = time;
        clearInterval(followTimer);

        const startedAt = Date.now();
        const startT = adapter.getCurrentTime();
        let deadline = startedAt + WP.FOLLOW_TIMEOUT_MS;
        let lastReport = 0;
        post('DIAG', {
            event: 'follow-start', url: location.href,
            target: time, now: startT, gap: time - startT,
            paused: adapter.isPaused(), inAd: adapter.isInAd()
        });

        followTimer = setInterval(() => {
            if (targetPauseTime === null) return clearInterval(followTimer);
            const elapsed = Date.now() - startedAt;
            const t = adapter.getCurrentTime();

            // 追いつけていない間の様子を1秒ごとに残す（再生位置が進んでいるかが要点）
            if (elapsed - lastReport >= 1000) {
                lastReport = elapsed;
                post('DIAG', {
                    event: 'follow-wait', url: location.href,
                    target: targetPauseTime, now: t, startT, elapsedMs: elapsed,
                    advanced: t - startT, paused: adapter.isPaused(), inAd: adapter.isInAd()
                });
            }

            // 広告中は本編が進まない。止めると広告ごと止まるので、待つ時間にも数えない
            if (adapter.isInAd()) {
                deadline = Date.now() + WP.FOLLOW_TIMEOUT_MS;
                return;
            }

            if (t >= targetPauseTime) {
                withEchoGuard(() => adapter.pause());
                post('DIAG', {
                    event: 'follow-done', url: location.href,
                    target: targetPauseTime, now: t, elapsedMs: elapsed
                });
                stopFollowing();
                return;
            }

            // 期限切れ。再生が止まっていて追いつけない。
            // ここで諦めないと、以降の定期補正が捨てられ続けてずれたまま固まる
            if (Date.now() > deadline) {
                const target = targetPauseTime;
                post('DIAG', {
                    event: 'follow-timeout', url: location.href,
                    target, now: t, startT, elapsedMs: elapsed,
                    advanced: t - startT, paused: adapter.isPaused()
                });
                stopFollowing();
                withEchoGuard(() => {
                    adapter.seek(target);
                    adapter.pause();
                });
            }
        }, 100);
    }

    function apply({ type, currentTime, timestamp, paused, ad } = {}) {
        if (!bound) return;
        if (typeof currentTime !== 'number' || !Number.isFinite(currentTime)) return;
        // 直前の定期通知の位置（0 秒の知らせを1回だけ見送るため）
        if (type !== 'tick' || currentTime >= 5) { lastTickTime = currentTime; zeroTickOnce = false; }
        lastApplyAt = Date.now();

        // ホストが広告中かは定期通知で分かる。広告中のホストは操作を送らないので、
        // 操作が届いたなら広告は終わっている
        setHostState({
            hostAd: type === 'tick' ? Boolean(ad) : false,
            hostPaused: type === 'pause' || (type === 'tick' ? Boolean(paused) : hostPaused && type !== 'play')
        });

        // 自分が広告中なら何もしない。本編を動かすと広告が止まってしまう。
        // 広告が終わった時点でホストの位置を取り直す（watchAds）
        if (adapter.isInAd()) return;

        // 開いた直後は「止まって待つ」を後回しにする（冒頭の広告を止めないため）
        const stops = type === 'pause' || (type === 'tick' && (paused || ad));
        if (startup) {
            if (stops) { deferredStop = true; return; }
            endStartup();   // ホストが再生中と分かったので、待つ理由がない
        }

        // 送信からの経過時間を足して、いま居るべき位置を求める
        const lag = timestamp ? Math.max(0, (Date.now() - timestamp) / 1000) : 0;

        if (type === 'play') {
            stopFollowing();
            const target = currentTime + lag;
            withEchoGuard(() => catchUp(target, WP.SEEK_THRESHOLD_SEC));
        } else if (type === 'pause') {
            const gap = currentTime - adapter.getCurrentTime();
            if (gap > 0.2 && gap <= WP.FOLLOW_MAX_GAP_SEC && !adapter.isPaused()) {
                followUntil(currentTime);   // 少し手前 → 追いついてから止める
            } else {
                stopFollowing();
                withEchoGuard(() => {
                    adapter.seek(currentTime);
                    adapter.pause();
                });
            }
        } else if (type === 'seek') {
            stopFollowing();
            withEchoGuard(() => {
                // サービスによってはシーク後に勝手に再生を再開する（Prime がそう）。止まっていたなら止め直す
                const wasPaused = adapter.isPaused();
                adapter.seek(currentTime);
                // ホストが再生中のときだけ、読み込みを待つ（止まっているホストに合わせるときは追いかけにならない）
                if (!hostPaused) settle = { at: Date.now(), started: false, lead: 0 };
                if (wasPaused) adapter.pause();
            });
        } else if (type === 'tick' && currentTime < 5 && lastTickTime >= 30 && !zeroTickOnce) {
            zeroTickOnce = true;
            return;
        } else if (type === 'tick') {
            // ホストの状態の定期通知。大きくズレていれば合わせる。
            if (targetPauseTime !== null) {
                // 追いつき待ちの間は補正しない。ここを通り続けているなら、
                // 追いつき待ちから抜けられていない（調査中・2026-09-12）
                if (Date.now() - lastTickDropReport >= 3000) {
                    lastTickDropReport = Date.now();
                    post('DIAG', {
                        event: 'tick-dropped', url: location.href,
                        target: targetPauseTime, now: adapter.getCurrentTime(),
                        hostTime: currentTime, hostPaused: Boolean(paused), hostAd: Boolean(ad),
                        paused: adapter.isPaused(), inAd: adapter.isInAd()
                    });
                }
                return;
            }
            if (paused || ad) {
                // ホストは止まっている、または広告中（本編は進まない）→ 同じ位置で止まって待つ
                withEchoGuard(() => {
                    // 止まって待つときは細かく合わせる（飛んでも再生中の読み込みにならない。追いつくときに少し先へ飛んだ分が残らないように）
                    const drifted = Math.abs(adapter.getCurrentTime() - currentTime) > WP.SEEK_THRESHOLD_SEC;
                    if (drifted) adapter.seek(currentTime);
                    // シーク後の自動再開に備え、シークしたときは止まっていても止め直す
                    if (drifted || !adapter.isPaused()) adapter.pause();
                });
                return;
            }
            const target = currentTime + lag;
            withEchoGuard(() => catchUp(target, WP.DRIFT_THRESHOLD_SEC));
        }
    }

    window.addEventListener('message', (ev) => {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.source !== WP.SRC_UI) return;

        if (data.type === 'APPLY') {
            apply(data.payload);
        } else if (data.type === 'ROLE') {
            const becameHost = !isHost && Boolean(data.payload && data.payload.isHost);
            isHost = Boolean(data.payload && data.payload.isHost);
            if (becameHost) usePlan();   // ホストになったら、読めていた広告の位置をゲストへ送る
            if (becameHost && adapter) {
                // ゲストとして止めた直後だと、ホストとして押した再生が「勝手な再開」とみなされ
                // 止め直されてしまう（テストで発生）。合わせ込みの途中の状態を全部やめる
                adapter.releaseControl();
                stopFollowing();
                startup = false;
                deferredStop = false;
            }
        } else if (data.type === 'REQUEST_INFO') {
            sendInfo();
        } else if (data.type === 'PLAN') {
            // ホストが読んだ広告の入る位置（同じ作品と確かめてから届く）。自分で読めたものがあればそちらを使う
            if (adapter && typeof adapter.setAdPlan === 'function') {
                adapter.setAdPlan(data.payload, false);
                postStatus();
            }
        }
    });

    /*
     * このページ自身で読んだ広告の入る位置（content/prime-plan.js）。ホストなら別便でゲストへも送る
     * （スマホのスクリプトは読み込みが遅く、自分では読み逃すことがあるため）。
     */
    let ownPlan = null;
    let ownPlanAt = 0;
    let ownPlanUrl = '';
    window.addEventListener('message', (ev) => {
        if (ev.source !== window || !ev.data || ev.data.source !== 'wp-plan') return;
        ownPlan = ev.data.plan;
        ownPlanAt = Date.now();
        ownPlanUrl = location.href;
        checkEpisode(ev.data.titleId);
        usePlan();
    });
    function usePlan() {
        if (!ownPlan || !adapter || typeof adapter.setAdPlan !== 'function') return;
        const pageId = adapter.getContentId(location.href);
        // 読んだあとに別の作品へ移っていたら使わない（Prime は再生を始めると同じ作品のまま URL を書き換えるので、少しの間は許す）
        if (pageId !== adapter.getContentId(ownPlanUrl) && Date.now() - ownPlanAt > 20000) return;
        adapter.setAdPlan(ownPlan, true);
        postStatus();
        const contentId = pageInfo().contentId;
        if (isTop && isHost && contentId) post('META', { contentId, plan: ownPlan });
    }

    /*
     * ドラマの話（2026-09-14 ユーザー報告: ドラマだとゲストが別の話を再生した）。
     * Prime のドラマはシーズンのページのまま中で話を再生するので、ページのアドレス（シーズン）を送ると、
     * ゲストは自分の「続きを観る」の話を再生してしまう。
     * プレイヤーが取りに行った再生情報の titleId（いま再生している話の GTI）が、ページ自身の GTI と違えば
     * 「このページの中の話」とみなし、その GTI を作品として送る（amazon.co.jp/gp/video/detail/GTI/?autoplay=1 で
     * その話が再生されることを本物の Prime で確認）。映画はページの GTI と同じなので今までどおりページの ID を送る。
     */
    const GTI_RE = /^amzn1\.dv\.gti\.[0-9a-f-]{36}$/;
    let episode = null;   // { gti, page: シーズンのページの ID }
    let episodeTimer = null;
    const EPISODE_PRELOAD_WAIT_MS = 6000;
    function checkEpisode(titleId) {
        if (!adapter || adapter.constructor.service !== 'prime' || !isTop) return;
        if (typeof titleId !== 'string' || !GTI_RE.test(titleId)) return;
        clearInterval(episodeTimer);
        /*
         * その話が入っているページ。再生を始めると Amazon はアドレスを別の ID（0J… など）に書き換えるので、
         * いまのアドレスではなく、最後に送ったページの作品 ID を使う（2026-09-15 本物の Prime: 映画を再生してからルームを作ると、
         * 書き換わった ID を「別のページ」とみなし、映画を「作品が変わりました」の保留にして、ゲストが合わせられなかった）
         */
        const page = lastPageContentId || adapter.getContentId(location.href);
        let tries = 0;
        /*
         * プレイヤーが画面に出てから決める。作品ページを開いただけでも、Amazon は「続きを観る」の話を
         * 見えない所に用意して再生情報を取りに行く（本物の Prime で確認）。それを再生中の話と取り違えないため。
         * 用意されていた話は、プレイヤーが出てからしばらく新しい再生情報が来なかったとき（そのまま「続きを観る」を
         * 押したとき）だけ使う。別の話を押すと、プレイヤーが出たあとにその話の再生情報が届く（ここが呼び直される）
         */
        const openAtReceipt = Boolean(bound && adapter.isPlayerOpen());
        let openSince = openAtReceipt ? Date.now() - EPISODE_PRELOAD_WAIT_MS : 0;
        const decide = () => {
            if (!bound || !adapter.isPlayerOpen()) { openSince = 0; return; }
            if (!openSince) openSince = Date.now();
            if (Date.now() - openSince < EPISODE_PRELOAD_WAIT_MS) return;
            let pageGti = null;
            try { pageGti = adapter.getAppId(); } catch { /* ページの作りが変わった */ }
            // 再生を始めるとページの埋め込み情報が読めなくなることがある。先に読めていたページの GTI を使う
            pageGti = pageGti || pageAppId;
            if (!pageGti && ++tries < 10) return;
            clearInterval(episodeTimer);
            // ページの GTI が分からないままなら、話とはみなさない（映画を話と取り違えて保留にするより安全）
            const next = pageGti && titleId !== pageGti && titleId !== page ? { gti: titleId, page } : null;
            const changed = (next && next.gti) !== (episode && episode.gti);
            episode = next;
            if (changed) {
                post('DIAG', { event: 'episode', url: location.href, gti: titleId, pageGti, page });
                sendInfo();
            }
        };
        episodeTimer = setInterval(decide, 1000);
        decide();
    }

    /** いま再生している話（このページの中の話）。別の作品のページへ移っていたら null */
    function currentEpisode() {
        if (!episode || !adapter) return null;
        const page = adapter.getContentId(location.href);
        if (page === episode.page || page === episode.gti || (bound && adapter.isPlayerOpen())) return episode;
        episode = null;
        return null;
    }

    function pageInfo() {
        const ep = currentEpisode();
        if (ep) {
            return {
                service: adapter.constructor.service,
                contentId: ep.gti,
                url: adapter.buildUrl(ep.gti),
                // その話が入っているページ（シーズン）。そのページを送ってあれば、最初の話は確かめずに送る（background）
                pageContentId: ep.page
            };
        }
        const contentId = adapter.getContentId(location.href);
        return {
            service: adapter.constructor.service,
            contentId,
            // 参加者を飛ばす先。サービス側の余計なパラメータを除いた形にする
            url: (contentId && adapter.buildUrl(contentId)) || location.href
        };
    }

    /** 作品情報を送る。最上位フレームだけ（広告などの iframe が上書きしないように） */
    /** 最後に送ったページの作品 ID（話ではなくページそのもの）と、そのページの GTI */
    let lastPageContentId = null;
    let pageAppId = null;

    function sendInfo() {
        if (!adapter || !isTop) return;
        const info = pageInfo();
        if (!info.pageContentId && info.contentId && info.contentId !== lastPageContentId) {
            lastPageContentId = info.contentId;
            pageAppId = null;
        }
        post('INFO', info);
        lookForAppId(info.contentId);
    }

    /**
     * スマホのアプリを開くための内部 ID（Prime の GTI）を探して、見つかったら別便で送る。
     *
     * INFO（作品情報）に混ぜないのは、作品情報を送り直すとサーバー側の再生位置が 0 に戻るため
     * （同じ作品の change-video は位置を初期化する）。ページの埋め込み情報は読み込みの途中で
     * 入ることがあるので、しばらく探し続ける。
     */
    let appIdTimer = null;
    function lookForAppId(contentId) {
        clearInterval(appIdTimer);
        if (!contentId || typeof adapter.getAppId !== 'function') return;
        // スマホのスクリプトでは探さない（使うのはホストの PC だけ。ページの大きな埋め込みデータを毎秒読むので重い）
        if (typeof __WP_USERSCRIPT__ !== 'undefined') return;
        let tries = 0;
        const probe = () => {
            // 探している間に別の作品へ移っていたらやめる
            if (adapter.getContentId(location.href) !== contentId) return clearInterval(appIdTimer);
            let appId = null;
            try { appId = adapter.getAppId(); } catch { /* ページの作りが変わった */ }
            if (appId) {
                clearInterval(appIdTimer);
                if (contentId === lastPageContentId) pageAppId = appId;
                post('META', { contentId, appId });
            } else if (++tries >= 20) {
                clearInterval(appIdTimer);
            }
        };
        appIdTimer = setInterval(probe, 1000);
        probe();
    }

    /**
     * SPA 遷移では content script が再実行されないので、URL の変化を自前で見張る。
     * ただしサービスによっては、URL が変わっても作品は変わっていない。Prime は再生を始めると
     * 同じ作品の URL を別形式（ASIN → GTI）に書き換える。これを切り替えと取ると、
     * ゲストのページを開き直させてしまい、広告の入り方が変わって位置がずれる（実機で発生）。
     * どちらなのかはアダプタが決める（Netflix の URL 変化は本当に別の話数）。
     */
    function watchUrl() {
        let last = location.href;
        setInterval(() => {
            if (location.href === last) return;
            last = location.href;
            if (bound && adapter.ignoreUrlChange()) return;
            sendInfo();
        }, 500);
    }

    /**
     * ホストの再生位置と再生/停止を定期的に知らせる（ゲスト側で送っても background が捨てる）。
     * 停止中も送る。Amazon は作品ページを開いた時点で本編を「続きの位置で停止」の状態で
     * 用意しており、この初期状態ではイベントが一切出ないため、送らないとゲストが知る手段がない。
     */
    /*
     * 一瞬だけ 0 秒を読んだときは送らない（2026-09-16 iPhone 実機: ゲストが一瞬最初に戻る巻き戻しが頻発し、すぐ合った）。
     * Amazon は再生中に <video> を差し替えたり読み込み直したりし、その間は位置が 0 に読める。
     * それを送るとゲストが冒頭へ飛び、次の知らせ（5秒後）で戻っていた。
     * 20 秒以上先を見ていたのに急に 1.5 秒未満になったら、6 秒続くまで（本当に最初へ戻したのでなければ）送らない
     */
    let lastGoodT = 0;
    let zeroSince = 0;
    function bogusZero(t) {
        const now = Date.now();
        if (!Number.isFinite(t) || t >= 1.5) { if (Number.isFinite(t)) lastGoodT = t; zeroSince = 0; return false; }
        if (lastGoodT < 20) return false;
        if (!zeroSince) {
            zeroSince = now;
            // 記録: 何が 0 に読めたのか（2026-09-16 実機: ホストがただ流しているだけで、約1分ごとにゲストが冒頭へ戻された）
            const v = adapter._video;
            post('DIAG', {
                event: 'zero-read', t, lastGoodT, raw: v ? Math.round(v.currentTime * 10) / 10 : null,
                rs: v ? v.readyState : null, dur: v ? Math.round(v.duration) : null, paused: v ? v.paused : null,
                seeking: v ? v.seeking : null, videos: document.querySelectorAll('video').length,
                plan: typeof adapter.planSummary === 'function' ? adapter.planSummary() : null
            });
        }
        if (now - zeroSince < 6000) return true;
        lastGoodT = t;
        zeroSince = 0;
        return false;
    }

    function beat() {
        if (!bound || applying) return;
        const t = adapter.getCurrentTime();
        if (bogusZero(t)) return;
        post('PLAYER_EVENT', {
            type: 'tick',
            currentTime: t,
            paused: adapter.isPaused(),
            // 広告中は本編が止まっているので、ゲストは止まって待つことになる。表示用に伝える
            ad: adapter.isInAd(),
            timestamp: Date.now()
        });
        // 広告の入る位置の換算（画面の時間表示で確かめた目印）は黙って変わるので、定期的にも知らせる（記録用）
        if (typeof adapter.planSummary === 'function' && adapter.planSummary()) postStatus();
    }

    function startHeartbeat() {
        beat();   // プレイヤーを掴んだ時点の状態をすぐ知らせる
        setInterval(beat, WP.HEARTBEAT_MS);
    }

    function postStatus() {
        const v = adapter && adapter._video;
        let t = null;
        try { t = adapter ? adapter.getCurrentTime() : null; } catch { /* 未準備 */ }
        post('STATUS', {
            selfAd, hostAd, hostPaused,
            // ずれの見張り（2026-09-14）: 自分の本編の位置と止まっているか。友達の画面（スクリプト）がホストの位置と比べる
            t: Number.isFinite(t) ? Math.round(t * 10) / 10 : null,
            paused: adapter ? adapter.isPaused() : null,
            nf: adapter && adapter.constructor.service === 'netflix' && bound ? adapter.describeForDiag() : null,
            plan: adapter && typeof adapter.planSummary === 'function' ? adapter.planSummary() : null,
            // 記録用: 動画の読み込みの状態と、立て直しの回数（止まったまま動かない件の調査）
            diag: v ? {
                rs: v.readyState, seeking: v.seeking, ns: v.networkState, err: v.error ? v.error.code : 0,
                ahead: (() => {
                    try {
                        for (let i = 0; i < v.buffered.length; i++) {
                            if (v.buffered.start(i) <= v.currentTime && v.currentTime <= v.buffered.end(i)) return Math.round((v.buffered.end(i) - v.currentTime) * 10) / 10;
                        }
                    } catch { /* 無視 */ }
                    return 0;
                })(),
                startup, follow: targetPauseTime !== null, kicks: stuck.kicks, gaveUp: stuck.failed >= KICK_MAX_FAILED
            } : null
        });
    }

    function watchStuck() {
        setInterval(() => {
            if (!bound || isHost) return;
            const now = Date.now();
            const t = adapter.getCurrentTime();
            const v = adapter._video;
            const raw = v ? v.currentTime : t;
            /*
             * 動き出したか。飛んだこと自体でも位置は変わるので、それは数えない（2026-09-15 実機の記録: 飛んだ直後に
             * 「動き出した」とみなして待つのをやめ、読み込み中に5秒ごとに飛び直していた）。
             * 読み込み中でなく（seeking でない・データがある）、前回から普通の速さ（1秒に 0.3〜2 秒）で進んだときだけ
             */
            const step = rawLast === null ? 0 : raw - rawLast;
            const loaded = mediaLoaded(v);
            const advancing = rawLast !== null && loaded && !adapter.isPaused() && step > 0.3 && step < 2;
            if (advancing && settle && !settle.started) {
                settle.started = true;
                // 動き出した瞬間に、ホストより先にいる分（見込みより早く読めた分）だけ止まって待つ
                if (settle.lead > 0 && Number.isFinite(settle.target) && !hostPaused && !hostAd) {
                    const ahead = t - (settle.target + (now - settle.at) / 1000);
                    if (ahead > 0.3 && ahead < settle.lead + 2) {
                        settle.trimmed = true;
                        withEchoGuard(() => adapter.pause());
                        setTimeout(() => { if (!hostPaused && !hostAd) withEchoGuard(() => adapter.play()); }, Math.round(ahead * 1000));
                    }
                }
                // 飛んでから動き出すまでの時間 → 次に先へ飛ぶ量（1〜10秒。少しずつ覚え直す）
                const took = (now - settle.at) / 1000;
                loadLeadSec = Math.max(1, Math.min(10, loadLeadSec * 0.5 + (took + 0.5) * 0.5));
            }
            if (advancing) rawMovedAt = now;
            rawLast = raw;
            if (stuck.lastT === null || Math.abs(t - stuck.lastT) > 0.2) {
                // 立て直しのあと 10 秒以上ちゃんと進んだら、失敗の数を戻す
                if (stuck.failed && now - stuck.kickAt > 10000 && !adapter.isPaused()) stuck.failed = 0;
                stuck.lastT = t;
                stuck.movedAt = now;
            }
            // ホストが再生中（最近ホストの知らせが届いている）で、こちらは広告でも開いた直後でも追いつき待ちでもない
            const shouldPlay = now - lastApplyAt < 12000 && !hostPaused && !hostAd && !selfAd && !startup && targetPauseTime === null;
            if (!shouldPlay || adapter.isInAd()) { stuck.movedAt = now; return; }
            // 飛んだ先で読み込み中の間は待つ（立て直すと読み込みが最初からになる）
            if (settlePending(now)) return;
            if (now - Math.max(stuck.movedAt, rawMovedAt) < STUCK_MS || now - stuck.kickAt < KICK_GAP_MS) return;
            if (stuck.failed >= KICK_MAX_FAILED) return;
            stuck.kickAt = now;
            stuck.kicks++;
            stuck.failed++;
            post('DIAG', { event: 'stuck-kick', url: location.href, t, kicks: stuck.kicks });
            settle = null;
            withEchoGuard(() => adapter.pause());
            postStatus();
            // 少し待ってからホストの今の位置を取り直す（届いたら位置を合わせて再生する）
            setTimeout(() => post('READY', pageInfo()), 600);
        }, 1000);
        // ずれの見張りと記録のために、ときどき状態を送り直す
        setInterval(() => { if (bound && !isHost) postStatus(); }, 5000);
        // Netflix のホストの広告の様子を記録に残す（数分ずれた件の調査。2026-09-14）
        setInterval(() => {
            if (bound && isHost && adapter.constructor.service === 'netflix') post('DIAG', { event: 'nf-state', ...adapter.describeForDiag() });
        }, 30000);
    }

    function setHostState(next) {
        if (next.hostAd === hostAd && next.hostPaused === hostPaused) return;
        hostAd = next.hostAd;
        hostPaused = next.hostPaused;
        postStatus();
    }

    /** プレイヤーが開いた直後の猶予（STARTUP_*）を始める */
    function beginStartup() {
        startup = true;
        deferredStop = false;
        const began = Date.now();
        let played = 0;
        let last = began;
        const timer = setInterval(() => {
            if (!startup) return clearInterval(timer);
            const now = Date.now();
            if (!adapter.isPaused()) played += now - last;
            last = now;
            if (adapter.isInAd() || played >= WP.STARTUP_PLAY_MS || now - began >= WP.STARTUP_MAX_MS) {
                endStartup();
            }
        }, 250);
    }

    function endStartup() {
        if (!startup) return;
        startup = false;
        // 後回しにした「止まって待つ」をやり直す。広告中なら広告明けに watchAds がやる
        if (deferredStop && !adapter.isInAd()) post('READY', pageInfo());
        deferredStop = false;
    }

    /**
     * 自分の広告の始まりと終わりを見張る。
     * 終わったらホストの今の位置を取り直す（広告中はホストからの操作を無視しているため）。
     * 広告の見分け方はまだ実際の広告で確かめきれていないので、出入りのたびに様子を記録して送る。
     */
    /*
     * 同じページのまま作品が変わったらしいことに気づく（ホストのみ・2026-09-14）。
     * Prime はドラマの次の話へ自動で進んでもアドレスが変わらないことがあり、今までは気づけず、
     * ゲストが前の話のまま新しい話の時刻に合わせてしまった。次のどちらかで「変わった」とする:
     *   - 動画の長さが30秒以上変わった（別の話は長さが違う）
     *   - 最後の90秒あたりから、いきなり最初の30秒に戻った（長さがたまたま同じ話でも拾う）
     * Netflix / YouTube は次の話でアドレスが変わるので、ここでは Prime だけを見る（Netflix は広告で長さが揺れる）。
     * 気づいたら background が「保留」にし、ホストが「今の作品をゲストに送る」を押すまで再生位置を送らない。
     */
    function watchTitle() {
        let lastDur = NaN;
        let lastT = NaN;
        setInterval(() => {
            if (!bound || !isHost || adapter.constructor.service !== 'prime' || adapter.isInAd()) return;
            const dur = adapter.getDuration();
            const t = adapter.getCurrentTime();
            if (!Number.isFinite(dur) || dur <= 0 || !Number.isFinite(t)) return;
            /*
             * 長さの変化では判定しない（2026-09-14 実機）: Prime は広告の差し込みやページの移動で長さが変わり、
             * 作品を送った直後に「作品が変わった」と誤判定してゲストを待たせ続けた。
             * 次の話の自動再生は「終わり近くから冒頭へ戻った」で見る。別の作品のページへの移動はアドレスの変化で分かる
             */
            const restarted = Number.isFinite(lastT) && Number.isFinite(lastDur) && lastDur > 300 &&
                lastT > lastDur - 90 && t < 30;
            if (restarted) {
                post('DIAG', { event: 'title-changed', url: location.href, lastDur, dur, lastT, t });
                post('TITLE_CHANGED', pageInfo());
            }
            lastDur = dur;
            lastT = t;
        }, 2000);
    }

    function watchAds() {
        setInterval(() => {
            const now = adapter.isInAd();
            // ゲストの広告は最後まで流す。広告が始まる直前に「ホストに合わせて止まる」が
            // 当たると広告ごと止まり、広告中はこちらから手を出さないので止まったままになる（実機で発生）
            if (now && !isHost && adapter.isPaused()) adapter.play();
            if (now === selfAd) return;
            selfAd = now;
            postStatus();
            post('DIAG', { event: now ? 'ad-start' : 'ad-end', url: location.href, ...adapter.describeForDiag() });
            // ホストなら、広告の出入りをすぐ知らせる（ゲストが待ち始める／再生を再開する）。
            // 広告中も <video> は止まらないので、play/pause のイベントは出ない
            beat();
            if (!now) post('READY', pageInfo());   // ゲストなら、background がホストの位置を取りに行く
        }, 500);
    }

    /**
     * サービス側の確認ダイアログ（Netflix の「まだ見ていますか？」）を進める。
     * ホストが止まると全員が止まるので、ホストのときだけ。ゲストの画面は本人が押す
     * （ユーザーの判断。見ていない人の再生まで勝手に続けない）。
     */
    function watchInterruptions() {
        setInterval(() => {
            if (!bound || !isHost) return;
            try { adapter.dismissInterruption(); } catch (e) { console.warn('[wp] dismiss failed', e); }
        }, WP.INTERRUPT_CHECK_MS);
    }

    async function start() {
        adapter = globalThis.WPAdapters.resolve(location.href);
        if (!adapter) return;
        // 先に動いていた content/prime-plan.js が読めた分を取りに行く
        window.postMessage({ source: 'wp-plan-req' }, location.origin);

        // 作品の特定はプレイヤーを待たずに済ませる
        sendInfo();
        if (isTop) watchUrl();

        // 再生ボタンを押すまでプレイヤーが現れないことがあるので、期限なしで待つ
        await adapter.ready();
        bound = true;
        beginStartup();

        adapter.onStateChange((evt) => {
            if (applying) return;   // リモート適用によるイベントは送り返さない
            // 広告中の操作（シークバーを動かす等）は送らない。送るとゲストの広告が止まる。
            // 広告明けに本編が動き出したときの play で、ゲストはその位置に合わせられる
            if (adapter.isInAd()) return;
            if (bogusZero(evt.currentTime)) return;   // 読み込み直しの一瞬の 0 秒を「巻き戻し」として送らない
            post('PLAYER_EVENT', { ...evt, timestamp: Date.now() });
        });
        // アダプタが自分で見つけた「記録しておきたいこと」（Netflix の広告の手がかりなど）
        adapter.onDiag((payload) => post('DIAG', { url: location.href, ...payload }));

        startHeartbeat();
        watchAds();
        watchStuck();
        watchTitle();
        watchInterruptions();

        post('READY', pageInfo());
        console.log('[wp] bridge ready:', adapter.constructor.service);
    }

    start().catch(e => console.warn('[wp] bridge failed:', e));
})();
