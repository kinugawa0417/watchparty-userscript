// KINUGAWA Party Theater 1.0.3（配布用）
/**
 * Prime Video アダプタ。
 *
 * Prime のプレイヤーは HTML5 <video> なので、要素を直接掴んで currentTime を読み書きできる
 * （Netflix はこれが効かないため内部 API が要る）。
 *
 * 面倒な点は3つ。
 *   1. 要素の特定。作品ページでは予告編が自動再生され、SPA 遷移で要素ごと差し替わり、
 *      本編の長さは読み込みが進んでから確定するので、定期的に選び直す。
 *   2. プレイヤーが <video> の外に自前の状態を持っていて、直接の操作と食い違う（下の ENFORCE）。
 *   3. 広告が本編と同じ <video> に差し込まれる（下の「広告と本編の時間」）。
 *
 * このアダプタが外に見せる時間（getCurrentTime / seek）は、広告を除いた「本編の時間」。
 */
(() => {
    const Base = globalThis.WPAdapters.Base;

    // amazon.co.jp の作品 ID。ASIN（B で始まる10桁）のほか、再生を始めると
    // 26桁前後の別形式（GTI）の URL に書き換えられる。途中で切らないよう区切りまで取る
    // GTI（amzn1.dv.gti.…）でも開ける。ドラマの話を指定して開くのに使う（2026-09-14）
    const AMAZON_ID = /\/(?:dp|gp\/video\/detail)\/([A-Z0-9]{10}|[A-Z0-9]{20,40}|amzn1\.dv\.gti\.[0-9a-f-]{36})(?=[/?#]|$)/;
    const PRIMEVIDEO_ID = /primevideo\.com\/(?:region\/[a-z]{2}\/)?detail\/([A-Za-z0-9.]+)/;

    // これより短い動画は予告編とみなして掴まない（秒）。
    // 予告編は長くても数分。これを掴むとホストの予告編の再生が参加者に配られてしまう。
    const MIN_MAIN_DURATION_SEC = 300;

    const RESCAN_MS = 1000;

    /*
     * 実機で確認した挙動:
     *   - シーク中は自分で一時停止し、終わると（seeked）自分の状態に従って再生を再開する。
     *     → 「シーク → 一時停止」は、この再開で一時停止が打ち消される
     *   - シーク中に play() されると、それを捨てて一時停止し、終わっても再開しない。
     *     → 「シーク → 再生」は止まったままになる
     * そこで play() / pause() は「こうなってほしい」という希望として持ち、シークが終わるのを
     * 待って実際の状態を合わせ直す。一定時間たったら希望は捨てる（人が操作したときに邪魔しない）。
     */
    const ENFORCE_MS = 5000;
    const ENFORCE_TICK_MS = 250;

    /*
     * 広告と本編の時間（実機の記録で確認）:
     *   広告は本編と同じ <video> で流れ、その間も currentTime は進む。
     *   例: 冒頭に64秒の広告 → currentTime 0〜64 が広告、64 から本編の 0:00 が始まる。
     *   広告の長さ・回数は人によって違うので、currentTime のままでは合わせられない。
     *
     *   画面の経過時間表示は操作ボタンが出ている間しか DOM に無いので使えない。
     *   代わりに「広告 1:04」のカウントダウンが出ている間に進んだ時間を自分で測って記録し、
     *   本編の時間 = currentTime − それまでの広告の合計 として扱う。
     *   ページを読み込み直すと <video> の時間は本編の時間から始め直しになる（広告の記録も捨てる）。
     */
    // 「広告 1:04」（PC）。間に「(1/2)」「・」などが挟まっても拾う。英語表示の「Ad 0:15」も。
    // 間に文字（「広告付きで視聴」など）が入るものは広告のカウントダウンとみなさない
    // 「広告の終了後に、引き続きビデオが再生されます」… 広告の位置を飛び越えてシークしたときに流れる広告の表示
    // （残り時間が文の前に付く。2026-09-14 PC の Chrome で、これを見落として広告中に位置合わせを繰り返し、読み込みが終わらなくなった）
    const AD_COUNTDOWN = /(?:広告|\bAds?\b)[\s・·:：|()（）]*(?:\d+\s*(?:\/|of)\s*\d+[\s・·:：|()（）]*)?\d{1,2}:\d{2}|広告の終了後に/;
    const AD_LABEL = /広告|^\s*Ads?\b/;
    const AD_TRACK_MS = 250;
    // 1回の計測でこれ以上進んだら、広告の再生ではなくシークによる移動とみなす（秒）
    const AD_JUMP_SEC = 1.5;
    // これより短い「広告」は誤検知として捨てる（秒）
    const AD_MIN_SEC = 1.0;

    class PrimeAdapter extends Base {
        static get service() { return 'prime'; }

        static match(url) {
            return /^https:\/\/(www\.amazon\.co\.jp|www\.primevideo\.com)\//.test(url);
        }

        constructor() {
            super();
            this._video = null;
            this._detach = null;
            this._rescanTimer = null;
            this._want = null;          // 'play' | 'pause' | null
            this._wantUntil = 0;
            this._enforceTimer = null;
            this._ads = [];             // 終わった広告 { elemStart, elemEnd, len, contentPos }
            this._adOpen = null;        // 流れている広告 { elemStart, len, contentPos, lastElem }
            this._adEl = null;          // 見つけたカウントダウン表示（毎回ページを探すと重いので覚える）
            this._adTimer = null;
            this._anchors = [];         // 画面の時間表示で確かめた { content: 本編の秒, offset: そこまでの広告の合計 }
            this._clock = null;
            this._clockTick = 0;
        }

        async ready() {
            const video = await Base.waitFor(() => this._pickVideo(), { timeoutMs: Infinity });
            this._bind(video);
            this._watchForReplacement();
            this._trackAds();
            return this;
        }

        /**
         * 本編の <video> を選ぶ。
         * 予告編を掴まないよう、一定以上の長さのうち最も長いものを採用する。
         */
        _pickVideo() {
            const usable = Array.from(document.querySelectorAll('video')).filter(v =>
                v.isConnected &&
                Number.isFinite(v.duration) &&
                v.duration >= MIN_MAIN_DURATION_SEC
            );
            if (usable.length === 0) return null;
            if (usable.length === 1) return usable[0];

            /*
             * 本編の長さの <video> が複数あるとき（2026-09-16 実機: ホストがただ流しているだけで、ゲストが何度も冒頭へ戻された）。
             * Amazon は見えない所に同じ作品の <video> を用意していることがあり、長さだけで選ぶと、1秒ごとの選び直しで
             * 見えない方（位置 0）に乗り換え、その 0 秒をゲストへ送っていた。
             * 画面に出ていて、読み込みが済んで再生中のものを選ぶ。今掴んでいるものがそうなら乗り換えない
             */
            const score = (v) => {
                const r = v.getBoundingClientRect();
                return (r.width >= 50 && r.height >= 50 ? 4 : 0) + (!v.paused ? 2 : 0) + (v.readyState >= 2 ? 1 : 0);
            };
            const cur = this._video && usable.includes(this._video) ? this._video : null;
            let best = cur;
            for (const v of usable) {
                if (!best || score(v) > score(best) || (score(v) === score(best) && v !== cur && v.duration > best.duration)) best = v;
            }
            return best;
        }

        _bind(video) {
            if (this._video === video) return;
            if (this._detach) this._detach();

            this._video = video;
            // 別の <video> になったら時間の数え方も始め直し（プランは作品ごとなので、ここでは消さない）
            this._ads = [];
            this._adOpen = null;

            const onPlay = () => {
                // 止めてほしいのに始まった＝プレイヤーのシーク後の自動再開。止め直す
                if (this._activeWant() === 'pause') return this._reconcile();
                this._emit('play');
            };
            const onPause = () => {
                // シーク中の一時停止はプレイヤーが勝手に行うもの。人の操作ではないので知らせない
                // （知らせるとホストがシークするたびに全員が一瞬止まる）
                if (video.seeking) return;
                if (this._activeWant() === 'play') return this._reconcile();
                this._emit('pause');
            };
            const onSeeked = () => {
                this._reconcile();
                this._emit('seek');
            };

            video.addEventListener('play', onPlay);
            video.addEventListener('pause', onPause);
            video.addEventListener('seeked', onSeeked);

            this._detach = () => {
                video.removeEventListener('play', onPlay);
                video.removeEventListener('pause', onPause);
                video.removeEventListener('seeked', onSeeked);
            };

            console.log('[wp] prime: bound to video', video.duration);
        }

        /**
         * SPA 遷移で <video> が差し替わったら繋ぎ直す。
         * 要素の追加だけでなく長さの確定でも選び直す必要があり、DOM の変化では
         * 拾えないので定期的に見る（Amazon のページは DOM 変化が多く、
         * MutationObserver だと毎回全 video を走査することになり重い）。
         */
        _watchForReplacement() {
            if (this._rescanTimer) return;
            this._rescanTimer = setInterval(() => {
                const next = this._pickVideo();
                if (next && next !== this._video) this._bind(next);
            }, RESCAN_MS);
        }

        // --- 広告 -------------------------------------------------------------

        /** 広告のカウントダウン表示（「広告 1:04」）を探す。見つからなければ null */
        _adCountdown() {
            const visible = (el) => el.getBoundingClientRect().width > 0;
            const read = (el) => {
                const m = el.textContent.match(AD_COUNTDOWN);
                return m && visible(el) ? m[0].replace(/\s+/g, ' ') : null;
            };

            if (this._adEl && this._adEl.isConnected) {
                const hit = read(this._adEl);
                if (hit) return hit;
            }
            this._adEl = null;

            // 「広告」を含む短い文字を探し、そこから少し上がって残り時間と一緒になる要素を取る。
            // クラス名は難読化されていて変わるので使わない。
            // PC では「広告」だけの文字だったが、iPhone（スマホ用の画面）では見落としていた（2026-09-14）。
            // 「広告 · 0:15」「広告 (1/2)」のように一つにまとまっていても拾えるよう、含むかで見る
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            while (walker.nextNode()) {
                const s = walker.currentNode.textContent;
                if (s.length > 30 || !AD_LABEL.test(s)) continue;
                let el = walker.currentNode.parentElement;
                for (let i = 0; i < 5 && el; i++, el = el.parentElement) {
                    if (el.textContent.length > 60) break;
                    const hit = read(el);
                    if (hit) { this._adEl = el; return hit; }
                }
            }
            return null;
        }

        isInAd() {
            const main = this._video;
            if (!main) return false;
            // プレイヤーが開いていないなら広告ではない
            if (!this.isPlayerOpen()) return false;
            return this._adCountdown() !== null;
        }

        isPlayerOpen() {
            return Boolean(this._video) && this._video.getBoundingClientRect().width >= 50;
        }

        /** 広告の始まりと終わりを見張り、広告に使われた時間を記録する */
        _trackAds() {
            if (this._adTimer) return;
            this._adTimer = setInterval(() => {
                const v = this._video;
                if (!v) return;
                const elem = v.currentTime;
                const inAd = this.isInAd();
                if (this._plan && ++this._clockTick % 4 === 0) this._readClock();   // 1秒ごと

                if (inAd && !this._adOpen) {
                    this._adOpen = { elemStart: elem, len: 0, contentPos: this._toContent(elem), lastElem: elem };
                } else if (inAd && this._adOpen) {
                    const step = elem - this._adOpen.lastElem;
                    // 普通に流れた分だけ数える。シークによる移動は広告の長さに入れない
                    if (step > 0 && step < AD_JUMP_SEC) this._adOpen.len += step;
                    this._adOpen.lastElem = elem;
                } else if (!inAd && this._adOpen) {
                    const ad = { ...this._adOpen, elemEnd: elem };
                    delete ad.lastElem;
                    this._adOpen = null;
                    // 同じ所の広告をもう一度通った（巻き戻して見直した等）なら二重に数えない
                    const dup = this._ads.some(a => Math.abs(a.elemStart - ad.elemStart) < 2);
                    if (ad.len >= AD_MIN_SEC && !dup) {
                        this._ads.push(ad);
                        this._ads.sort((a, b) => a.elemStart - b.elemStart);
                    }
                }
            }, AD_TRACK_MS);
        }

        /*
         * 広告の入る位置（content/prime-plan.js が再生情報から読んだもの。2026-09-14）。
         * Prime は広告を最初から <video> に差し込んでおくので、まだ流れていない広告も <video> の時間に入っている。
         * 位置が分かっていれば、広告の合計（<video> の長さ − 本編の長さ）を枠に割り振って換算できる。
         *   - 流れた広告は実際に測った長さを使う（_ads）
         *   - まだ流れていない枠には、残りを等分する（枠が1つなら正確）
         * own … このページ自身で読んだもの（ホストから届いたものより優先する）
         */
        setAdPlan(plan, own = false) {
            if (!plan || typeof plan !== 'object') return;
            const fullMs = Number(plan.fullMs);
            if (!Number.isFinite(fullMs) || fullMs < 300000 || !Array.isArray(plan.breaks)) return;
            if (this._plan && this._plan.own && !own && Math.abs(this._plan.fullSec - fullMs / 1000) < 1) return;
            const breaks = plan.breaks.map(Number).filter(ms => Number.isFinite(ms) && ms >= 0 && ms <= fullMs)
                .sort((a, b) => a - b).slice(0, 40).map(ms => ms / 1000);
            // 別の作品のプランになったら、画面の時間表示で確かめた目印も捨てる
            if (!this._plan || Math.abs(this._plan.fullSec - fullMs / 1000) >= 1) {
                this._anchors = [];
                this._clock = null;
                this._clockPrev = null;
            }
            this._plan = { fullSec: fullMs / 1000, breaks, own };
        }

        /*
         * 画面の時間表示で答え合わせする（2026-09-14 iPhone 実機）。
         * 等分だけでは外れた: 枠は冒頭・33分・103分、広告の合計 47 秒を 15.7 秒ずつ割り振ったが、
         * 実際は冒頭に広告が無く（動画の 18.8 秒で画面は「0:00:19」）、ゲストが 16 秒先へずれた。
         * 操作ボタンが出ている間は「経過 0:00:19」「残り 2:07:47」が見え、足すと本編の長さになる。
         * これで本物の本編の時間を読み、「その位置までの広告の合計 = <video> の時間 − 本編の時間」を目印（_anchors）に残す。
         */
        _readClock() {
            const plan = this._plan, v = this._video;
            if (!plan || !v || v.seeking || v.paused || this.isInAd()) return;
            const parse = (s) => {
                const m = /^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})$/.exec(s);
                return m ? (Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3])) : null;
            };
            const visible = (n) => n.parentElement && n.parentElement.getBoundingClientRect().width > 0;
            let pair = null;
            // 前回見つけた表示がまだあればそれを読む（毎回ページ全体を探すと重い）
            if (this._clock && this._clock.every(n => n.isConnected && visible(n))) {
                pair = this._clock;
            } else {
                if (Date.now() - (this._clockScanAt || 0) < 3000) return;
                this._clockScanAt = Date.now();
                const found = [];
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                while (walker.nextNode() && found.length < 8) {
                    if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(walker.currentNode.textContent.trim()) && visible(walker.currentNode)) {
                        found.push(walker.currentNode);
                    }
                }
                for (let i = 0; i + 1 < found.length && !pair; i++) {
                    const a = parse(found[i].textContent.trim()), b = parse(found[i + 1].textContent.trim());
                    if (a !== null && b !== null && Math.abs(a + b - plan.fullSec) <= 3) pair = [found[i], found[i + 1]];
                }
                this._clock = pair;
            }
            if (!pair) return;
            const content = parse(pair[0].textContent.trim());
            const rest = parse(pair[1].textContent.trim());
            if (content === null || rest === null || Math.abs(content + rest - plan.fullSec) > 3) return;
            // 表示が遅れて古いことがある（実機で 6 秒遅れの表示を見た）。続けて読んで、動画と同じだけ進んでいるときだけ使う
            const prev = this._clockPrev;
            this._clockPrev = { content, elem: v.currentTime, at: Date.now() };
            if (!prev || Date.now() - prev.at > 2500 || content === prev.content ||
                Math.abs((content - prev.content) - (v.currentTime - prev.elem)) > 1.2) return;
            // 表示は秒の切り捨てなので、半秒足した所を本編の時間とみなす
            const offset = v.currentTime - (content + 0.5);
            const total = v.duration - plan.fullSec;
            if (offset < -2 || offset > total + 2) return;
            this._anchors = (this._anchors || []).filter(a => Math.abs(a.content - content) > 30);
            this._anchors.push({ content, offset: Math.max(0, Math.min(total, offset)) });
            this._anchors.sort((a, b) => a.content - b.content);
            if (this._anchors.length > 20) this._anchors.shift();
        }

        /** 枠ごとの広告の長さ（秒）。使えないときは null */
        _planLens() {
            const plan = this._plan, v = this._video;
            if (!plan || !v || !Number.isFinite(v.duration)) return null;
            const total = v.duration - plan.fullSec;
            // 本編の長さと合わない（別の作品のプランなど）なら使わない
            if (total < -5 || total > 1800) return null;
            const n = plan.breaks.length;
            if (total < 1 || n === 0) return plan.breaks.map(() => 0);
            // 流れた広告は測った長さ
            const lens = plan.breaks.map(pos => {
                const ad = this._ads.find(a => Math.abs(a.contentPos - pos) < 5);
                return ad ? ad.len : null;
            });
            /*
             * 冒頭の枠は、実際に広告が流れたとき（上で測れたとき）以外は 0 秒とみなす（2026-09-14 iPhone 実機: 2回とも、
             * 枠はあるのに冒頭に広告は無く、広告の分は途中の枠に入っていた。冒頭に割り振ると最初からずれる）。
             * 画面の時間表示の目印があれば、下でそちらが優先される
             */
            const prerollDefault = plan.breaks[0] === 0 && !(this._adOpen && this._adOpen.contentPos < 5);
            /*
             * 目印ごとに、「その位置より前の枠の広告の合計」が分かっている。
             * 前の目印からこの目印までの間の、まだ長さの分からない枠に、足りない分を等分する
             */
            let done = 0;   // ここまでで決まった枠の数
            const sumTo = (k) => lens.slice(0, k).reduce((s, l) => s + (l || 0), 0);
            for (const a of this._anchors || []) {
                let k = done;
                while (k < n && plan.breaks[k] <= a.content) k++;
                if (k === done) continue;
                const unknown = [];
                for (let i = done; i < k; i++) if (lens[i] === null) unknown.push(i);
                const need = a.offset - sumTo(k);
                for (const i of unknown) lens[i] = Math.max(0, need / unknown.length);
                done = k;
            }
            if (prerollDefault && lens[0] === null) lens[0] = 0;
            // 残り（最後の目印より後）には、合計から決まった分を引いた残りを等分する
            const unknown = lens.map((l, i) => (l === null ? i : -1)).filter(i => i >= 0);
            const each = unknown.length ? Math.max(0, (total - sumTo(n)) / unknown.length) : 0;
            return lens.map(l => (l === null ? each : l));
        }

        /** <video> の時間 → 本編の時間 */
        _toContent(elem) {
            const lens = this._planLens();
            if (lens) {
                let off = 0;
                for (let i = 0; i < lens.length; i++) {
                    const start = this._plan.breaks[i] + off;
                    if (elem < start) return Math.max(0, elem - off);
                    if (elem < start + lens[i]) return this._plan.breaks[i];   // 広告の途中。本編は止まっている
                    off += lens[i];
                }
                return Math.max(0, elem - off);
            }
            let offset = 0;
            for (const ad of this._ads) {
                if (elem >= ad.elemEnd) offset += ad.len;
                else if (elem >= ad.elemStart) return ad.contentPos;   // 広告の途中。本編は止まっている
            }
            if (this._adOpen && elem >= this._adOpen.elemStart) return this._adOpen.contentPos;
            return Math.max(0, elem - offset);
        }

        /** 本編の時間 → <video> の時間（その位置より前の広告の分だけ後ろにずらす） */
        _toElem(content) {
            const lens = this._planLens();
            if (lens) {
                // その位置より前（同じ位置を含む）の枠の広告を足す。枠の位置ちょうどなら広告の後ろへ
                let off = 0;
                for (let i = 0; i < lens.length; i++) if (this._plan.breaks[i] <= content + 0.5) off += lens[i];
                return content + off;
            }
            let offset = 0;
            for (const ad of this._ads) {
                if (ad.contentPos <= content) offset += ad.len;
            }
            return content + offset;
        }

        /** 記録用の短いまとめ（本編の長さ・枠の位置・割り振った長さ） */
        planSummary() {
            if (!this._plan) return null;
            const lens = this._planLens();
            return {
                full: Math.round(this._plan.fullSec), own: this._plan.own,
                breaks: this._plan.breaks.map(s => Math.round(s)),
                anchors: (this._anchors || []).map(a => [Math.round(a.content), Math.round(a.offset * 10) / 10]),
                lens: lens ? lens.map(l => Math.round(l * 10) / 10) : null
            };
        }

        describeForDiag() {
            const main = this._video;
            return {
                countdown: this._adCountdown(),
                elemTime: main ? Math.round(main.currentTime * 10) / 10 : null,
                contentTime: main ? Math.round(this.getCurrentTime() * 10) / 10 : null,
                plan: this.planSummary(),
                ads: this._ads.map(a => ({
                    elemStart: Math.round(a.elemStart * 10) / 10,
                    len: Math.round(a.len * 10) / 10,
                    contentPos: Math.round(a.contentPos * 10) / 10
                })),
                videos: Array.from(document.querySelectorAll('video')).map(v => ({
                    main: v === main,
                    duration: Number.isFinite(v.duration) ? Math.round(v.duration) : String(v.duration),
                    t: Math.round(v.currentTime * 10) / 10,
                    paused: v.paused,
                    visible: v.getBoundingClientRect().width > 50
                }))
            };
        }

        // --- 再生の状態 -------------------------------------------------------

        getCurrentTime() {
            return this._video ? this._toContent(this._video.currentTime) : 0;
        }

        getDuration() {
            return this._video ? this._video.duration : NaN;
        }

        isPaused() {
            return this._video ? this._video.paused : true;
        }

        play() {
            if (!this._video) return;
            this._request('play');
            // シーク中でも一度は呼ぶ。止まったままのシークはこれをきっかけに進むため
            this._playNow();
        }

        pause() {
            if (!this._video) return;
            this._request('pause');
            this._video.pause();
        }

        _playNow() {
            // Prime は再生開始を Promise で返す。自動再生拒否は握り潰さず記録する。
            this._video?.play?.()?.catch(e => console.warn('[wp] play rejected', e));
        }

        releaseControl() {
            this._want = null;
            clearInterval(this._enforceTimer);
        }

        _activeWant() {
            if (this._want && Date.now() > this._wantUntil) this._want = null;
            return this._want;
        }

        _request(state) {
            this._want = state;
            this._wantUntil = Date.now() + ENFORCE_MS;
            // イベントだけに頼らず、しばらく定期的にも確かめる（再開しないまま黙ることがあるため）
            clearInterval(this._enforceTimer);
            this._enforceTimer = setInterval(() => {
                if (!this._activeWant()) return clearInterval(this._enforceTimer);
                this._reconcile();
            }, ENFORCE_TICK_MS);
        }

        /** 希望の状態と実際の状態が違えば合わせる。シーク中はプレイヤーが動かすので待つ */
        _reconcile() {
            const v = this._video;
            const want = this._activeWant();
            if (!v || !want || v.seeking) return;
            if (this.isInAd()) return;   // 広告中は触らない（止めると広告も止まる）
            if (want === 'play' && v.paused) this._playNow();
            else if (want === 'pause' && !v.paused) v.pause();
        }

        /** 本編の時間で指定する */
        seek(seconds) {
            if (!this._video) return;
            const duration = this._video.duration;
            let target = this._toElem(Math.max(0, seconds));
            if (Number.isFinite(duration) && duration > 0) {
                target = Math.min(target, duration);
            }
            this._video.currentTime = target;
        }

        // --- 作品 -------------------------------------------------------------

        getContentId(url = location.href) {
            const amazon = url.match(AMAZON_ID);
            if (amazon) return amazon[1];
            const pv = url.match(PRIMEVIDEO_ID);
            if (pv) return pv[1];
            return null;
        }

        /**
         * この作品本人の GTI（amzn1.dv.gti.<uuid>）。スマホの Prime Video アプリを開くのに使う。
         *
         * ASIN で開くとアプリは作品ページで止まり、時刻も無視された（2026-09-13 Android 実機）。
         * GTI はアプリが本来受け付ける作品 ID なので、こちらで開けば再生まで行くか試す。
         *
         * 作品ページには GTI が20個ほど埋め込まれている（おすすめ欄の他作品を含む）。
         * 本人のものは `"compactGTI":"…","gti":"amzn1.dv.gti.…"` のように **"gti" という名前**で入り、
         * おすすめ欄の他作品は **"titleID"** という名前で並ぶ（2026-09-13 実ページで確認）。
         * "gti" の名前のものだけを拾えば取り違えない。JSON が文字列の中にあるので \" の形も許す。
         */
        getAppId() {
            const re = /\\?"gti\\?"\s*:\s*\\?"(amzn1\.dv\.gti\.[0-9a-f-]{36})/;
            for (const s of document.scripts) {
                const text = s.textContent;
                if (!text || !text.includes('amzn1.dv.gti')) continue;
                const m = text.match(re);
                if (m) return m[1];
            }
            return null;
        }

        buildUrl(contentId) {
            if (!contentId) return null;
            // ASIN も GTI も amazon.co.jp の作品ページで開ける（GTI は実機の URL で確認）
            if (location.hostname === 'www.amazon.co.jp' || /^B[A-Z0-9]{9}$/.test(contentId)) {
                return `https://www.amazon.co.jp/gp/video/detail/${contentId}/?autoplay=1`;
            }
            return `https://www.primevideo.com/detail/${contentId}`;
        }
    }

    globalThis.WPAdapters.list.push(PrimeAdapter);
})();
