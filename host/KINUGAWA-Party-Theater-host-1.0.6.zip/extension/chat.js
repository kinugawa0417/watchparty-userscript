// KINUGAWA Party Theater 1.0.6（配布用）
/**
 * ポップアウトしたチャット窓（chat.html）。
 *
 * socket は background が持っているので、この窓は runtime メッセージで
 * 読み書きするだけ。閉じても接続も履歴も失われない。
 *
 * 名前も発言も他人が書いたものなので、必ず textContent で入れる（HTML として解釈しない）。
 */
(() => {
    const api = globalThis.browser;
    const $ = (id) => document.getElementById(id);
    const MAX_SHOWN = 100;

    let selfId = null;

    /** 絵文字だけの発言は大きく出す（動画に重ねるチャットと同じ扱い） */
    function isReaction(s) {
        return typeof s === 'string' && s.length <= 8 &&
            /^\p{Extended_Pictographic}[\p{Extended_Pictographic}‍️]*$/u.test(s);
    }

    /** サーバーから来た色は #RRGGBB だけ受け付ける（style に入れるため） */
    /** 表示する名前。ホストの発言（サーバーの判定）だけ 👑 を付け、名前に入った王冠の記号は消す（なりすまし防止） */
    function displayName(m) {
        const name = (typeof m.username === 'string' ? m.username : '').replace(/[👑♔♕♚♛🪅]/gu, '').slice(0, 20) || '？';
        return m.isHost === true ? '👑 ' + name : name;
    }

    function safeColor(c) {
        return typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c) ? c : '#cfd3ff';
    }

    /** 入退出などのお知らせは、チャットの流れに混ぜず、この1行を上書きして出す（2026-09-14 ユーザー要望）。文字は textContent でしか入れない */
    function showNotice(content, flash) {
        const el = $('notice');
        el.textContent = typeof content === 'string' ? content.slice(0, 200) : '';
        el.title = el.textContent;
        el.hidden = !el.textContent;
        el.classList.remove('fresh');
        if (flash) { void el.offsetWidth; el.classList.add('fresh'); }
    }

    function append(m, flash = true) {
        if (m.type === 'system') return showNotice(m.content, flash);
        const box = $('msgs');
        const nearEnd = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
        const row = document.createElement('div');
        row.className = 'msg' + (m.senderId === selfId ? ' me' : '') +
            (isReaction(m.content) ? ' big' : '');
        const name = document.createElement('span');
        name.className = 'name';
        name.textContent = displayName(m);
        name.style.color = safeColor(m.color);
        const body = document.createElement('span');
        body.className = 'body';
        body.textContent = m.content;
        row.append(name, body);
        box.appendChild(row);
        while (box.children.length > MAX_SHOWN) box.firstChild.remove();
        if (nearEnd || m.senderId === selfId) box.scrollTop = box.scrollHeight;
    }

    function add(m) {
        if (m.type !== 'system') $('msgs').querySelector('.empty')?.remove();
        append(m);
    }

    function setHistory(list) {
        const box = $('msgs');
        box.textContent = '';
        $('notice').hidden = true;
        for (const m of list || []) append(m, false);
        if (!box.children.length) {
            const e = document.createElement('div');
            e.className = 'empty';
            e.textContent = 'まだメッセージはありません';
            box.appendChild(e);
        }
        box.scrollTop = box.scrollHeight;
    }

    function renderSession(s) {
        if (!s) return;
        selfId = s.socketId || null;
        $('dot').classList.toggle('on', Boolean(s.connected));
        $('code').textContent = s.roomId || '未参加';
        $('count').textContent = s.roomId ? `${s.participants.length}人` : '';
        document.title = s.roomId ? `チャット ${s.roomId}` : 'KINUGAWA Party Theater チャット';
    }

    api.runtime.onMessage.addListener((msg) => {
        if (!msg || !msg.type) return;
        if (msg.type === 'CHAT') add(msg.payload);
        else if (msg.type === 'SESSION') renderSession(msg.payload);
    });

    $('form').addEventListener('submit', (e) => {
        e.preventDefault();
        const text = $('msg').value.trim();
        if (!text) return;
        api.runtime.sendMessage({ type: 'SEND_CHAT', text }).catch(() => {});
        $('msg').value = '';
    });

    // 起動時に今の状態と履歴をもらう
    api.runtime.sendMessage({ type: 'GET_SESSION' }).then(renderSession).catch(() => {});
    api.runtime.sendMessage({ type: 'GET_CHAT' }).then(setHistory).catch(() => {});

    $('msg').focus();
})();
