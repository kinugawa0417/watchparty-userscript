// Watch Party 0.24.10（配布用）
/**
 * 現在の URL を担当するアダプタを選ぶ。
 * adapters/*.js が globalThis.WPAdapters.list へ自己登録した順に評価する。
 */
(() => {
    globalThis.WPAdapters.resolve = function resolve(url = location.href) {
        const Adapter = globalThis.WPAdapters.list.find(A => A.match(url));
        return Adapter ? new Adapter() : null;
    };
})();
