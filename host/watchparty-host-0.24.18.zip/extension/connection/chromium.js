// Watch Party 0.24.18（配布用）
/**
 * Chromium 系の接続保持実装。
 *
 * service worker は約30秒のアイドルで停止させられるため、socket を直接
 * 持たせると視聴中に切れる。Chrome 116 以降は WebSocket の通信で
 * アイドルタイマーがリセットされる（socket.io の ping は25秒間隔）が、
 * 30秒との差が薄く2時間の視聴には心もとない。
 *
 * そこで offscreen document に socket を持たせる。こちらはライフサイクル
 * 制限を受けず、タブ遷移でも生き残る。service worker は中継に徹する。
 *
 * ※ chrome.offscreen は Chromium 専用 API。Firefox には存在しないため
 *   connection/firefox.js が別実装を持つ。
 */
(() => {
    const WP = globalThis.WP;

    class ChromiumConnection {
        constructor() {
            this._handler = null;

            chrome.runtime.onMessage.addListener((msg) => {
                if (!msg || msg.channel !== WP.CONN_EVT) return;
                if (this._handler) this._handler(msg.event, msg.payload);
            });
        }

        async _ensureDocument() {
            if (await chrome.offscreen.hasDocument()) return;
            await chrome.offscreen.createDocument({
                url: 'offscreen.html',
                reasons: ['WORKERS'],
                justification: '同期サーバーとの WebSocket 接続を視聴中ずっと維持するため'
            });
        }

        onEvent(cb) { this._handler = cb; }

        async connect(serverUrl) {
            await this._ensureDocument();
            this._post({ cmd: 'connect', serverUrl });
        }

        emit(event, payload) {
            this._post({ cmd: 'emit', event, payload });
        }

        disconnect() {
            this._post({ cmd: 'disconnect' });
        }

        _post(msg) {
            chrome.runtime.sendMessage({ channel: WP.CONN_CMD, ...msg }).catch(() => {});
        }
    }

    globalThis.WPConn = globalThis.WPConn || {};
    globalThis.WPConn.Chromium = ChromiumConnection;
})();
