// Watch Party 0.24.17（配布用）
/**
 * ISOLATED world 側のスクリプト。
 *
 * 拡張機能 API を使えるのはこちら。MAIN world の bridge.js と background の
 * 橋渡しをしつつ、ページ上に状態表示のオーバーレイを出す。
 *
 * ページ側の CSS に影響されない／与えないよう Shadow DOM に閉じ込める。
 */
(() => {
    const WP = globalThis.WP;
    const api = globalThis.browser;

    let session = { connected: false, roomId: null, isHost: false, participants: [] };
    let pageInfo = null;
    let shadow = null;
    let orphaned = false;        // 拡張機能の再読み込みで切り離された
    let adStatus = { selfAd: false, hostAd: false, hostPaused: false };
    let chat = null;             // チャット欄（最上位フレームだけ）
    let chatRoom = null;         // チャットの履歴を読み込んだルーム
    let dimTimer = null;         // 狭い画面で状態表示を薄くするまでの時計
    let panelOpen = true;        // 表示を開いているか（チャット欄と同じく畳める）
    let reserveTopForChat = () => {};   // パネルの下端をチャット欄に教える（mount で差し替える）

    // 狭い画面（スマホ）かどうか。判定は protocol.js に集めてある（chat.js と共通）
    const DIM_AFTER_MS = 6000;
    const isCompact = () => WP.isCompact();

    // --- bridge (MAIN) からの受信 -------------------------------------
    window.addEventListener('message', (ev) => {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.source !== WP.SRC_BRIDGE) return;

        if (data.type === 'INFO') {
            // 作品情報。bridge は最上位フレームでしか送らない
            pageInfo = data.payload;
            send({ type: 'PAGE_INFO', payload: data.payload });
            render();
        } else if (data.type === 'READY') {
            // プレイヤーを掴めた。プレイヤーが iframe 内でもここに来る
            send({ type: 'PLAYER_READY' });
        } else if (data.type === 'PLAYER_EVENT') {
            send({ type: 'PLAYER_EVENT', payload: data.payload });
        } else if (data.type === 'STATUS') {
            adStatus = data.payload;
            render();
        } else if (data.type === 'DIAG') {
            send({ type: 'DIAG', payload: data.payload });
        } else if (data.type === 'TITLE_CHANGED') {
            // 同じページのまま作品が変わったらしい（Prime の次の話など）。ホストなら background が保留にする
            send({ type: 'TITLE_CHANGED' });
        } else if (data.type === 'META') {
            // スマホのアプリを開くための内部 ID（Prime の GTI）。作品情報とは別便で届く
            send({ type: 'VIDEO_META', payload: data.payload });
        }
    });

    // --- background からの受信 ----------------------------------------
    api.runtime.onMessage.addListener((msg) => {
        if (!msg || !msg.type) return;
        if (msg.type === 'APPLY') {
            toBridge('APPLY', msg.payload);
        } else if (msg.type === 'REQUEST_INFO') {
            toBridge('REQUEST_INFO');
        } else if (msg.type === 'PLAN') {
            toBridge('PLAN', msg.payload);
        } else if (msg.type === 'SESSION') {
            session = msg.payload;
            toBridge('ROLE', { isHost: session.isHost });
            render();
        } else if (msg.type === 'CHAT') {
            if (chat && msg.payload) chat.add(msg.payload);
        }
    });

    /** 返事を受け取りたいときはこちら（ルームの作成・参加・退出など） */
    function ask(msg) {
        if (orphaned) return Promise.resolve(null);
        return api.runtime.sendMessage(msg).catch(() => { checkAlive(); return null; });
    }

    function send(msg) {
        if (orphaned) return;
        // background が寝ている瞬間に送ると reject されるが、実害はないので握る
        try {
            api.runtime.sendMessage(msg).catch(() => checkAlive());
        } catch {
            checkAlive();
        }
    }

    /**
     * 拡張機能が読み込み直される（開発時・ストアでの更新時）と、このスクリプトは
     * 切り離されて二度と通信できなくなる。表示だけが古いまま残って紛らわしいので、
     * 切り離されたことを検知して再読み込みを促す。切り離されると runtime.id が消える。
     */
    function checkAlive() {
        if (orphaned || globalThis.chrome?.runtime?.id) return;
        orphaned = true;
        render();
    }
    setInterval(checkAlive, 2000);

    function toBridge(type, payload) {
        window.postMessage({ source: WP.SRC_UI, type, payload }, location.origin);
    }

    // --- オーバーレイ ---------------------------------------------------
    function mount() {
        if (shadow) return;
        const host = document.createElement('div');
        host.id = 'wp-overlay-host';
        // 置き場所は下の :host で決める（画面の狭さで変わるため）
        document.documentElement.appendChild(host);

        placeHosts();

        shadow = host.attachShadow({ mode: 'open' });
        const style = document.createElement('style');
        style.textContent = `
            /* Prime のプレイヤー右上には音量・全画面などのボタンが並ぶ。隠さないようその下に置く */
            :host {
                position: fixed;
                top: 100px; right: 16px;
                z-index: 2147483647;
            }
            * { box-sizing: border-box; }

            /*
             * チャット欄と同じく、畳んだり開いたりできる入れ物。
             * ルームの作成・参加・退出もここでできるので、拡張機能のボタンを
             * 毎回押し直さなくてよい（ポップアップは他をクリックすると消えてしまう）。
             */
            .panel {
                width: 210px;
                background: rgba(20,20,24,.92);
                border: 1px solid rgba(255,255,255,.15);
                border-radius: 8px;
                box-shadow: 0 4px 16px rgba(0,0,0,.4);
                overflow: hidden;
            }
            .panel[hidden] { display: none; }
            .head {
                display: flex; align-items: center; gap: 6px;
                padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,.1);
                font: 600 12px/1.4 system-ui, sans-serif; color: #eee;
                user-select: none;
            }
            .head .title { flex: 1; }
            .icon-btn {
                all: unset; cursor: pointer; width: 22px; height: 22px; border-radius: 5px;
                display: grid; place-items: center; color: #d6d6de; font-size: 15px;
                touch-action: manipulation;
            }
            .chip {
                all: unset; cursor: pointer;
                display: flex; align-items: center; gap: 5px;
                padding: 5px 9px; border-radius: 999px;
                background: rgba(20,20,24,.92);
                border: 1px solid rgba(255,255,255,.15);
                box-shadow: 0 4px 16px rgba(0,0,0,.4);
                font: 600 11px/1.4 system-ui, sans-serif; color: #eee;
                touch-action: manipulation;
            }
            .chip[hidden] { display: none; }

            .acts { padding: 7px 8px; display: flex; flex-direction: column; gap: 5px; }
            .acts[hidden] { display: none; }
            .acts label { font: 400 10px/1.4 system-ui, sans-serif; color: #9a9aa2; }
            .acts input {
                all: unset; width: 100%; padding: 5px 7px; border-radius: 5px;
                background: rgba(255,255,255,.1); color: #fff;
                font: 400 12px/1.4 system-ui, sans-serif;
            }
            .acts input::placeholder { color: #7e7e8a; }
            .acts button.act {
                all: unset; cursor: pointer; text-align: center;
                padding: 6px 8px; border-radius: 5px;
                background: #3a6df0; color: #fff;
                font: 600 12px/1.4 system-ui, sans-serif;
                touch-action: manipulation;
            }
            .acts button.act.sub { background: #4a4a58; font-weight: 400; }
            /* 作品が変わってまだゲストに送っていないときの知らせ */
            .pending { background: #5a4214; border: 1px solid #a0781f; color: #fff; border-radius: 8px;
                       padding: 7px 9px; font-size: 12px; line-height: 1.5; }
            .acts button.act.send { background: #1f8a5a; font-weight: 700; }
            .people { display: flex; flex-direction: column; gap: 3px; }
            .people .who {
                display: flex; align-items: center; gap: 5px;
                font: 400 11px/1.4 system-ui, sans-serif; color: #ddd;
            }
            .people .nm { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .people button {
                all: unset; cursor: pointer; padding: 2px 6px; border-radius: 4px;
                background: #4a4a58; color: #fff; font-size: 10px;
                touch-action: manipulation;
            }
            .box {
                font: 12px/1.5 system-ui, sans-serif;
                color: #eee;
                padding: 7px 9px;
                user-select: none;
            }
            .row { display:flex; align-items:center; gap:6px; }
            .row + .row { margin-top: 3px; }
            .dot { width:7px; height:7px; border-radius:50%; background:#888; flex:none; }
            .dot.on { background:#3ddc84; }
            .code { font-weight:700; letter-spacing:.08em; }
            .muted { color:#9a9aa2; }
            .tag {
                font-size:10px; padding:1px 5px; border-radius:3px;
                background:#3a6df0; color:#fff;
            }
            /* ホストとずれている・止まっている人（2026-09-14） */
            .tag.drift { background:#b8860b; }

            /*
             * 狭い画面（スマホ）。パソコンと同じ右上だと、スマホのプレイヤーの
             * 上部（戻る・キャスト等）と重なりやすい。チャット欄と反対の左下へ置き、
             * 表示も1行にまとめる。
             *
             * さらに、変化が無いまま数秒たったら薄くして触れなくする（data-dim）。
             * プレイヤーの操作列がどこに出るか端末ごとに違うので、
             * 「どこに置いても邪魔にならない」側に倒している。状態が変わればまた濃くなる。
             */
            :host([data-compact]) {
                top: auto; right: auto;
                left: calc(8px + env(safe-area-inset-left, 0px));
                bottom: calc(8px + env(safe-area-inset-bottom, 0px));
            }
            :host([data-compact]) .panel { width: min(62vw, 260px); }
            :host([data-compact]) .box { font-size: 11px; padding: 5px 8px; }
            :host([data-compact]) .panel,
            :host([data-compact]) .chip { transition: opacity .5s; }
            /*
             * 薄くしている間は、触ってもここに当たらないようにする。
             * pointer-events は入れ物（host 要素）にも掛けないと、中身が透けていても
             * 入れ物が先に触られてしまい、下にあるプレイヤーのボタンが押せない。
             */
            :host([data-dim]) { pointer-events: none; }
            :host([data-compact][data-dim]) .panel,
            :host([data-compact][data-dim]) .chip { opacity: .28; }
            :host([data-compact]) .row + .row { margin-top: 2px; }
        `;
        shadow.appendChild(style);

        // ShadowRoot は Element ではないので insertAdjacentHTML は使えない。
        // template で組み立ててから足す（既にある <style> はそのまま残る）
        const tpl = document.createElement('template');
        tpl.innerHTML = `
            <div class="panel">
                <div class="head">
                    <span class="title">Watch Party</span>
                    <button class="icon-btn min" title="小さくする" aria-label="小さくする">－</button>
                </div>
                <div class="box"></div>
                <div class="acts"></div>
            </div>
            <button class="chip" hidden aria-label="Watch Party を開く">
                <span class="dot"></span><span class="chip-text">未接続</span>
            </button>`;
        shadow.appendChild(tpl.content);

        // 全画面ではこの表示もプレイヤーの中に入る。クリックが漏れると再生/停止が変わる
        for (const t of ['click', 'dblclick', 'mousedown', 'mouseup', 'pointerdown', 'pointerup',
                         'touchstart', 'touchend', 'touchmove', 'wheel', 'contextmenu']) {
            host.addEventListener(t, (e) => e.stopPropagation());
        }

        shadow.querySelector('.min').addEventListener('click', () => setPanelOpen(false));
        shadow.querySelector('.chip').addEventListener('click', () => setPanelOpen(true));

        /*
         * このパネルの下端を、チャット欄に教える（チャット欄はそこより上へ伸びない）。
         * パネルは参加者の数や開閉で背が変わるので、決め打ちではなく実際に測る。
         * 以前は決め打ちで、パネルがチャット欄の下に隠れて押せなくなった（2026-09-13）。
         */
        const reserve = () => {
            const chatHost = document.getElementById(globalThis.WPChat.HOST_ID);
            if (!chatHost) return;
            const r = host.getBoundingClientRect();
            const bottom = r.height > 0 ? Math.ceil(r.bottom) : 0;
            chatHost.style.setProperty('--wp-top-reserve', bottom + 'px');
        };
        new ResizeObserver(reserve).observe(host);
        globalThis.addEventListener('resize', reserve);
        document.addEventListener('fullscreenchange', () => setTimeout(reserve, 50));
        reserveTopForChat = reserve;

        // 畳んだ状態を覚える。スマホは場所を取るので既定で畳んでおく
        api.storage.local.get('panelOpen')
            .then(v => {
                if (v.panelOpen === false || (v.panelOpen === undefined && isCompact())) {
                    setPanelOpen(false, true);
                }
            })
            .catch(() => { if (isCompact()) setPanelOpen(false, true); });

        // 狭い画面かどうかを属性で持たせる（CSS がこれを見る）。向きを変えたら付け直す
        const follow = () => {
            if (isCompact()) {
                host.setAttribute('data-compact', '');
            } else {
                host.removeAttribute('data-compact');
                host.removeAttribute('data-dim');   // パソコンでは薄くしない
                clearTimeout(dimTimer);
            }
            render();
        };
        for (const ev of ['resize', 'orientationchange']) globalThis.addEventListener(ev, follow);
        globalThis.visualViewport?.addEventListener('resize', follow);
        follow();
    }

    /**
     * 表示の開閉。チャット欄と同じ作り。
     * @param {boolean} open
     * @param {boolean} [silent] 人の操作でない開閉（起動時など）は覚えない
     */
    function setPanelOpen(open, silent) {
        panelOpen = open;
        if (!shadow) return;
        shadow.querySelector('.panel').hidden = !open;
        shadow.querySelector('.chip').hidden = open;
        if (!silent) api.storage.local.set({ panelOpen: open }).catch(() => {});
    }

    /** 畳んでいるときの小さな表示。一目で状態が分かるだけでよい */
    function renderChip() {
        const chip = shadow.querySelector('.chip');
        chip.querySelector('.dot').className = 'dot' + (session.connected ? ' on' : '');
        chip.querySelector('.chip-text').textContent =
            orphaned ? 'F5' : session.roomId ? `${session.roomId} ${session.participants.length}人` : '未参加';
    }

    /**
     * ルームの操作。ページに置いておくと、拡張機能のボタンを毎回押さずに済む
     * （ポップアップは他をクリックすると消えてしまう）。
     */
    function renderActions() {
        const acts = shadow.querySelector('.acts');
        if (orphaned) { acts.hidden = true; return; }
        acts.hidden = false;

        // 入力中に作り直すと打てなくなるので、状態が変わったときだけ組み直す
        const shape = session.roomId
            ? `joined:${session.roomId}:${session.isHost}:${session.titlePending}:${Boolean(session.contentId)}:` +
              session.participants.map(p => p.id + p.isHost + WP.driftLabel(p)).join(',')
            : `home:${session.lastRoom ? session.lastRoom.roomId : ''}`;
        if (acts.dataset.shape === shape) return;
        acts.dataset.shape = shape;
        acts.textContent = '';

        if (!session.roomId) {
            const name = makeInput('ニックネーム', 'なまえ', 20);
            name.el.value = localStorage.getItem('wp:username') || '';
            const remember = () => {
                const n = name.el.value.trim();
                if (n) localStorage.setItem('wp:username', n);
                return n;
            };
            acts.append(
                name.label, name.el,
                makeButton('ルームを作る', async () => {
                    const n = remember();
                    if (!n) return name.el.focus();
                    session = await ask({ type: 'CREATE_ROOM', username: n }) || session;
                    render();
                })
            );
            // ブラウザを開き直したホストが、前に作ったルームへ同じコードで戻る（招待リンクの送り直しが要らない）
            if (session.lastRoom) {
                const resume = makeButton(`前のルーム（${session.lastRoom.roomId}）に戻る`, async () => {
                    session = await ask({ type: 'RESUME_ROOM' }) || session;
                    render();
                }, true);
                resume.dataset.role = 'resume';
                acts.appendChild(resume);
            }
            return;
        }

        const copyButton = (label, text, sub) => {
            const b = makeButton(label, async () => {
                try {
                    await navigator.clipboard.writeText(text());
                    b.textContent = 'コピーしました';
                    setTimeout(() => { b.textContent = label; }, 1500);
                } catch {
                    // ページの設定でクリップボードが使えないことがある。そのときは選べる形で出す
                    prompt('この文章をコピーして送ってください', text());
                }
            }, sub);
            return b;
        };
        const copy = copyButton('メッセージ付き招待URLをコピー', inviteText);
        copy.dataset.role = 'invite';
        const copyUrl = copyButton('URLだけコピー', () => WP.inviteUrl(session.roomId), true);
        copyUrl.dataset.role = 'invite-url';
        acts.append(copy, copyUrl);

        /*
         * 作品をゲストに送る（ホストのみ・2026-09-14）。作品が変わったらしいときは自動で送らず、
         * ここに知らせを出してホストに押してもらう。送るまでゲストへは再生位置も送らない。
         */
        if (session.isHost && session.contentId) {
            if (session.titlePending) {
                const note = document.createElement('div');
                note.className = 'pending';
                note.textContent = '⚠ 作品が変わりました。ゲストはまだ前の作品のままです（再生位置も送っていません）';
                acts.appendChild(note);
            }
            const send = makeButton('📤 今の作品をゲストに送る', async () => {
                session = await ask({ type: 'SEND_TITLE' }) || session;
                render();
            });
            if (session.titlePending) send.classList.add('send');
            else send.classList.add('sub');
            send.dataset.role = 'send-title';
            acts.appendChild(send);
        }

        if (session.participants.length) {
            const list = document.createElement('div');
            list.className = 'people';
            for (const p of session.participants) {
                const who = document.createElement('div');
                who.className = 'who';
                const nm = document.createElement('span');
                nm.className = 'nm';
                // 名前は他人が決めるので textContent で入れる
                nm.textContent = p.name + (p.id === session.socketId ? '（自分）' : '');
                who.appendChild(nm);
                if (p.isHost) {
                    const tag = document.createElement('span');
                    tag.className = 'tag';
                    tag.textContent = 'ホスト';
                    who.appendChild(tag);
                } else if (p.viewer) {
                    // スマホ（観覧専用）の人。プレイヤーを操作できないので、ホストは渡せない（サーバーも拒否する）
                    const tag = document.createElement('span');
                    tag.className = 'tag';
                    tag.textContent = 'スマホ';
                    who.appendChild(tag);
                }
                // ホストとずれている・止まっている人（再生タブが知らせてくる）
                const drift = WP.driftLabel(p);
                if (drift) {
                    const tag = document.createElement('span');
                    tag.className = 'tag drift';
                    tag.textContent = drift;
                    who.appendChild(tag);
                }
                list.appendChild(who);
            }
            acts.appendChild(list);
        }

        const leave = makeButton('退出', async () => {
            session = await ask({ type: 'LEAVE' }) || session;
            render();
        }, true);
        leave.dataset.role = 'leave';
        acts.appendChild(leave);
    }

    /** 友達（スマホ）へ送る文面。ポップアップのものと同じ */
    function inviteText() {
        return WP.inviteText(session.serverUrl, session.roomId);
    }

    function makeInput(labelText, placeholder, maxLength) {
        const label = document.createElement('label');
        label.textContent = labelText;
        const el = document.createElement('input');
        el.placeholder = placeholder;
        el.maxLength = maxLength;
        el.autocomplete = 'off';
        return { label, el };
    }

    function makeButton(text, onClick, sub) {
        const b = document.createElement('button');
        b.className = 'act' + (sub ? ' sub' : '');
        b.textContent = text;
        b.addEventListener('click', onClick);
        return b;
    }

    function render() {
        // プレイヤーが iframe の中にある場合に備えて全フレームへ注入しているが、
        // オーバーレイを出すのは最上位フレームだけでよい。
        if (window.top !== window) return;
        mount();
        const rows = [];

        renderChat();
        renderActions();
        renderChip();

        if (orphaned) {
            show(`<div class="row"><span class="dot"></span>
                <span>拡張機能が更新されました</span></div>
                <div class="row muted">このページを再読み込み（F5）してください</div>`);
            return;
        }

        const dot = `<span class="dot ${session.connected ? 'on' : ''}"></span>`;
        const hostTag = session.isHost ? '<span class="tag">ホスト</span>' : '';

        if (isCompact()) {
            // 狭い画面では場所を取らないよう1行にまとめる
            rows.push(session.roomId
                ? `<div class="row">${dot}
                    <span class="code">${escapeHtml(session.roomId)}</span>
                    <span class="muted">${session.participants.length}人</span>${hostTag}</div>`
                : `<div class="row">${dot}
                    <span class="muted">${session.connected ? '未参加' : '未接続'}</span></div>`);
        } else {
            rows.push(`<div class="row">
                ${dot}
                <span>${session.connected ? '接続済み' : '未接続'}</span>
                ${hostTag}
            </div>`);

            if (session.roomId) {
                rows.push(`<div class="row"><span class="muted">ルーム</span>
                    <span class="code">${escapeHtml(session.roomId)}</span></div>`);
                rows.push(`<div class="row muted">${session.participants.length} 人が視聴中</div>`);
            } else {
                rows.push('<div class="row muted">未参加</div>');
            }
        }

        if (session.roomId && adStatus.selfAd && !session.isHost) {
            rows.push('<div class="row muted">広告のあと、ホストに合わせます</div>');
        } else if (session.roomId && adStatus.hostAd && !session.isHost) {
            rows.push('<div class="row muted">ホストの広告が終わるまで待っています</div>');
        } else if (session.roomId && adStatus.hostPaused && !session.isHost) {
            // 止まっているのが自分のせいではないと分かるように（ホストが再生したと勘違いされた）
            rows.push('<div class="row muted">ホストの再生を待っています</div>');
        }

        if (pageInfo && !pageInfo.contentId) {
            rows.push(session.roomId && !session.isHost
                ? '<div class="row muted">ホストが作品を開くと自動で移動します</div>'
                : '<div class="row muted">作品ページで開いてください</div>');
        }

        show(rows.join(''));
    }

    /**
     * 状態表示を書き換える。
     * 狭い画面では、書き換わってから数秒で薄くして触れなくする（プレイヤーの操作の邪魔になるため）。
     * 中身が変わればまた濃くなるので、見せたい場面では必ず見える。
     */
    function show(html) {
        const box = shadow.querySelector('.box');
        if (box.innerHTML === html) return;
        box.innerHTML = html;
        clearTimeout(dimTimer);
        const host = shadow.host;
        host.removeAttribute('data-dim');
        if (isCompact()) {
            dimTimer = setTimeout(() => host.setAttribute('data-dim', ''), DIM_AFTER_MS);
        }
    }

    // --- チャット -------------------------------------------------------

    /** ルームに入っている間だけチャット欄を出す */
    function renderChat() {
        const inRoom = Boolean(session.roomId) && !orphaned;
        if (!inRoom) {
            if (chat) chat.setVisible(false);
            return;
        }
        if (!chat) {
            chat = new globalThis.WPChat({
                onSend: (text) => send({ type: 'SEND_CHAT', text }),
                onToggle: (open) => api.storage.local.set({ chatOpen: open }).catch(() => {}),
                onPopout: () => send({ type: 'OPEN_CHAT_WINDOW' })
            });
            chat.mount();
            placeHosts();
            // チャット欄ができた直後に、パネルの下端を教える（それより上へ伸ばさない）
            reserveTopForChat();
            // スマホでは開いたままだと画面の大半が隠れるので、既定は畳んでおく（💬 ボタン）。
            // 人が一度でも開閉していれば、その選択を優先する
            api.storage.local.get('chatOpen')
                .then(v => {
                    if (v.chatOpen === false || (v.chatOpen === undefined && chat.isCompact())) {
                        chat.setOpen(false, true);
                    }
                })
                .catch(() => { if (chat.isCompact()) chat.setOpen(false, true); });
        }
        chat.setVisible(true);
        chat.setSelf(session.socketId);
        chat.setParticipants(session.participants.length);
        // 別のルームに入り直したら、そのルームの履歴に入れ替える
        if (chatRoom !== session.roomId) {
            chatRoom = session.roomId;
            api.runtime.sendMessage({ type: 'GET_CHAT' })
                .then(list => chat.setHistory(list || []))
                .catch(() => {});
        }
    }

    /**
     * 表示の置き場所。全画面にすると、ブラウザは全画面にした要素の中身しか描かない。
     * そのままだと状態表示もチャット欄も消えるので、全画面の間はその要素の中へ移す。
     */
    function placeHosts() {
        // webkit… は iOS / 一部の Android のブラウザ。標準の名前が無いことがある
        const fs = document.fullscreenElement || document.webkitFullscreenElement;
        // <video> そのものが全画面なら中に入れられない（子要素は描かれない）。
        // スマホのプレイヤーはこの形になることがあり、そのときは重ねて出せない
        const target = fs && fs.tagName !== 'VIDEO' ? fs : document.documentElement;
        for (const id of ['wp-overlay-host', globalThis.WPChat.HOST_ID]) {
            const el = document.getElementById(id);
            if (el && el.parentNode !== target) target.appendChild(el);
        }
    }
    if (window.top === window) {
        for (const ev of ['fullscreenchange', 'webkitfullscreenchange']) {
            document.addEventListener(ev, placeHosts);
        }
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    // bridge.js（MAIN world）とこのスクリプトは読み込まれる順番もタイミングも決まっていない。
    // bridge が先に動くと、起動直後に送った作品情報をこちらが受け取り損ねるので、改めて頼む。
    // （こちらが先なら、この依頼は届かないが bridge の起動時の送信を受け取れる）
    toBridge('REQUEST_INFO');

    // 起動時に現在のセッションを取得
    api.runtime.sendMessage({ type: 'GET_SESSION' })
        .then(s => { if (s) { session = s; toBridge('ROLE', { isHost: s.isHost }); render(); } })
        .catch(() => render());
})();
