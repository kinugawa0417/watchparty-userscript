// KINUGAWA Party Theater 1.2.3（配布用）
// ホストの PC でも広告消し（prune-ads.js）を入れる（2026-09-25）。prime-plan.js の後に読み込むこと
WP_PRUNE.install();
