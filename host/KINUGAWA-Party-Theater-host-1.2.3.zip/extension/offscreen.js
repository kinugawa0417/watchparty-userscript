// KINUGAWA Party Theater 1.2.3（配布用）
/**
 * offscreen document 側。socket.io の接続をここで保持する。
 * background からのコマンドを受け、サーバーからのイベントを background へ返す。
 */
(() => {
    const WP = globalThis.WP;

    // サーバーから受け取って background へ流すイベント
    const RELAY = [
        'connect',
        'disconnect',
        'connect_error',
        'update-participants',
        'update-host',
        'update-video-state',
        'sync-video',
        'change-video',
        'video-meta',
        'receive-message',
        'chat-history',
        'action-rejected'
    ];

    let socket = null;

    chrome.runtime.onMessage.addListener((msg) => {
        if (!msg || msg.channel !== WP.CONN_CMD) return;

        if (msg.cmd === 'connect') {
            connect(msg.serverUrl);
        } else if (msg.cmd === 'emit') {
            socket?.emit(msg.event, msg.payload);
        } else if (msg.cmd === 'disconnect') {
            socket?.close();
            socket = null;
        }
    });

    function connect(serverUrl) {
        if (socket) socket.close();

        // polling を挟まず websocket 直行。CORS プリフライトを避けられる。
        socket = globalThis.io(serverUrl, {
            transports: ['websocket'],
            reconnection: true,
            reconnectionDelay: 1000
        });

        for (const event of RELAY) {
            socket.on(event, (payload) => {
                // connect は引数を持たないので、自分の socket id を載せて返す。
                // 参加者一覧の中から「自分」を特定するのに必要。
                const body = event === 'connect'
                    ? { id: socket.id }
                    : serializable(payload);

                chrome.runtime.sendMessage({
                    channel: WP.CONN_EVT,
                    event,
                    payload: body
                }).catch(() => {});
            });
        }

        console.log('[wp/offscreen] connecting to', serverUrl);
    }

    /** Error 等はそのまま送れないので落とす */
    function serializable(v) {
        if (v instanceof Error) return { message: v.message };
        return v;
    }
})();
