// KINUGAWA Party Theater 1.1.6（配布用）
/**
 * Firefox（PC / Android）の接続保持実装。
 *
 * Firefox に chrome.offscreen は無い。MV3 の background はイベントページ
 * 方式で、接続が生きている間は維持されるため socket をその場で持てる。
 *
 * socket.io クライアントは manifest の background.scripts で先に
 * 読み込まれている前提（globalThis.io）。
 *
 * ※ 手順5（Firefox / Android 対応）で実地検証する。それまでは未使用。
 */
(() => {
    class FirefoxConnection {
        constructor() {
            this._socket = null;
            this._handler = null;
        }

        onEvent(cb) { this._handler = cb; }

        async connect(serverUrl) {
            if (this._socket) this.disconnect();

            if (typeof globalThis.io !== 'function') {
                throw new Error('socket.io client is not loaded');
            }

            this._socket = globalThis.io(serverUrl, {
                transports: ['websocket'],
                reconnection: true
            });

            const relay = (event) => {
                this._socket.on(event, (payload) => {
                    // chromium.js 側と揃える（connect では socket id を返す）
                    const body = event === 'connect'
                        ? { id: this._socket.id }
                        : payload;
                    if (this._handler) this._handler(event, body);
                });
            };

            ['connect', 'disconnect', 'update-participants', 'update-host',
             'update-video-state', 'sync-video', 'change-video', 'video-meta',
             'receive-message', 'chat-history', 'action-rejected'].forEach(relay);
        }

        emit(event, payload) {
            this._socket?.emit(event, payload);
        }

        disconnect() {
            this._socket?.close();
            this._socket = null;
        }
    }

    globalThis.WPConn = globalThis.WPConn || {};
    globalThis.WPConn.Firefox = FirefoxConnection;
})();
