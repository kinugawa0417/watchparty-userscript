// KINUGAWA Party Theater 1.1.1（配布用）
/**
 * Prime の「広告の入る位置」を、プレイヤー自身が取りに行く再生情報から読む（2026-09-14）。
 *
 * ■ なぜ要るか（iPhone 実機の記録）
 * Prime は広告を本編と同じ <video> に最初から差し込んでおく（まだ流れていない広告も含む）。
 * 例: スパイダーマン 本編 7284 秒 → 広告つきの人の <video> は 7512.5 秒（広告 228 秒ぶん長い）。
 * 広告のカウントダウンを見て測る方式では、まだ通っていない広告を知りようがなく、
 * ホストが先へ移動するとゲストはその広告の長さぶん後ろにずれた。
 *
 * ■ 読むもの
 * プレイヤーが取りに行く GetVodPlaybackResources の返事（JSON）の
 *   vodPlaylistedPlaybackUrls.result.playbackUrls.fullTitleDurationMs … 本編の長さ（広告を含まない）
 *   〃 .intraTitlePlaylist … [Remote(広告), Main(0〜3793664ms), Remote(広告), Main(3793664〜6395000ms)] のような並び
 * Main の区切りは本編の時間なので、Remote（広告の枠）の位置が本編の時間で分かる。広告の長さはここには無いが、
 * 「<video> の長さ − 本編の長さ」で広告の合計が分かる（adapters/prime.js）。
 *
 * ■ 決まり
 * この返事以外は読まない・書き換えない。返事の中身も数（長さ・位置）しか取り出さない。
 * もう一つ、この通信のアドレスの titleId（いま再生している作品の GTI）も読む（2026-09-14）。
 * ドラマはシーズンのページのまま中で話が切り替わり、ページのアドレスからはどの話か分からないため
 * （本物の Prime で確認: 3話を押しても、アドレスはシーズンのページのまま。titleId は3話の GTI になる）。
 * ページより先に動く必要がある（document_start、ページと同じ文脈）。
 */
(() => {
    if (globalThis.__wpPrimePlan) return;
    const MIN_FULL_MS = 300 * 1000;          // これより短いのは予告編
    const MAX_FULL_MS = 24 * 3600 * 1000;
    const URL_RE = /\/playback\/prs\/GetVodPlaybackResources/;

    /** 返事の JSON から { fullMs, breaks: [本編の時間 ms] } を取り出す。読めなければ null */
    function parse(json) {
        const p = json && json.vodPlaylistedPlaybackUrls && json.vodPlaylistedPlaybackUrls.result &&
            json.vodPlaylistedPlaybackUrls.result.playbackUrls;
        if (!p || typeof p !== 'object') return null;
        const fullMs = Number(p.fullTitleDurationMs);
        if (!Number.isFinite(fullMs) || fullMs < MIN_FULL_MS || fullMs > MAX_FULL_MS) return null;
        const list = Array.isArray(p.intraTitlePlaylist) ? p.intraTitlePlaylist : [];
        const breaks = [];
        let cursor = 0;
        for (const e of list) {
            if (!e || typeof e !== 'object') continue;
            if (e.type === 'Main') {
                if (Number.isFinite(e.endMs)) cursor = e.endMs;
            } else if (e.type === 'Remote') {
                if (!breaks.includes(cursor)) breaks.push(cursor);
            }
        }
        return { fullMs, breaks: breaks.filter(ms => ms >= 0 && ms <= fullMs).sort((a, b) => a - b).slice(0, 40) };
    }

    const GTI_RE = /^amzn1\.dv\.gti\.[0-9a-f-]{36}$/;
    /** 通信のアドレスから、再生する作品の GTI を取り出す。無ければ null */
    function titleIdOf(url) {
        try {
            const id = new URL(String(url), location.href).searchParams.get('titleId');
            return id && GTI_RE.test(id) ? id : null;
        } catch { return null; }
    }

    let last = null;
    let lastTitleId = null;
    const post = () => window.postMessage({ source: 'wp-plan', plan: last, titleId: lastTitleId }, location.origin);
    // 本編の長さのある返事だけを使う（予告編は parse が捨てる）ので、titleId も本編のものになる
    const handleText = (text, url) => {
        try {
            const plan = parse(JSON.parse(text));
            if (plan) { last = plan; lastTitleId = titleIdOf(url); post(); }
        } catch { /* JSON でない */ }
    };

    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
        window.fetch = function (input) {
            const res = Reflect.apply(origFetch, globalThis, arguments);
            try {
                const url = typeof input === 'string' ? input : input && input.url;
                if (URL_RE.test(String(url || ''))) {
                    res.then(r => r.clone().text()).then(text => handleText(text, url)).catch(() => {});
                }
            } catch { /* 読めなくてもページの通信は邪魔しない */ }
            return res;
        };
    }

    const XHR = globalThis.XMLHttpRequest && XMLHttpRequest.prototype;
    if (XHR) {
        const open = XHR.open;
        XHR.open = function (method, url) {
            try {
                if (URL_RE.test(String(url || ''))) {
                    this.addEventListener('load', () => {
                        try {
                            if (this.responseType === '' || this.responseType === 'text') handleText(this.responseText, url);
                            else if (this.responseType === 'json') handleText(JSON.stringify(this.response), url);
                        } catch { /* 無視 */ }
                    });
                }
            } catch { /* 無視 */ }
            return Reflect.apply(open, this, arguments);
        };
    }

    // あとから動き出した bridge.js が、読めた分を取りに来る
    window.addEventListener('message', (ev) => {
        if (ev.source === window && ev.data && ev.data.source === 'wp-plan-req' && last) post();
    });

    Object.defineProperty(globalThis, '__wpPrimePlan', { value: { parse, titleIdOf }, configurable: false });
})();
