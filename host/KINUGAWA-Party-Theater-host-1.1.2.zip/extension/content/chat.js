// KINUGAWA Party Theater 1.1.2（配布用）
/**
 * チャット欄（ISOLATED world）。ui.js が組み立てて使う。
 *
 * 映画を見ながら使うので、動画の右下に半透明で重ねる。畳むと小さなボタンになり、
 * 畳んでいる間に届いたメッセージは数秒だけ浮かべて見せる。
 *
 * ページの CSS に影響されない／与えないよう Shadow DOM に閉じ込める。
 * 名前もメッセージも他人が書いたものなので、必ず textContent で入れる（HTML として解釈しない）。
 *
 * キー入力とクリックがプレイヤーに届かないようにしている:
 *   - キー: Prime はスペースで一時停止・矢印で送る。入力中の空白で動画が止まるので、
 *           keyguard.js（document_start）が window で先回りして止める
 *   - クリック: 全画面ではチャット欄がプレイヤーの中に入るので、クリックがプレイヤーに
 *           伝わると再生/停止が切り替わる。ここで止める
 *   - タッチ: スマホのプレイヤーは touch イベントで再生/停止を切り替える。click と別に
 *           発火するので、touch も同じように止める（止めないとチャットを触るたびに動画が止まる）
 *
 * スマホ（狭い画面）では置き場所と大きさを変える。詳しくは STYLE の COMPACT を参照。
 */
(() => {
    const HOST_ID = 'wp-chat-host';
    const MAX_SHOWN = 100;
    const TOAST_MS = 5000;

    // 狭い画面（スマホ）かどうかの判定は protocol.js の WP.isCompact() に集めてある。
    // 結果は host 要素の data-compact 属性に入れ、CSS はそれを見る。
    const STYLE = `
        /*
         * 置き場所もここで決める（mount で inline に書くと、この指定が効かなくなる）。
         * 下端は Prime / Netflix のシークバーと再生ボタンにかからない高さ。
         * --wp-kb はスマホのキーボードが隠している高さ（watchViewport が visualViewport から測って入れる）。
         */
        :host {
            all: initial;
            position: fixed;
            right: 16px;
            /* PC はゲストの右側のチャット欄と同じく、再生バーの上（下から 96px）まで伸ばす（2026-09-14 ユーザー要望） */
            bottom: calc(96px + var(--wp-kb, 0px));
            z-index: 2147483647;
        }
        * { box-sizing: border-box; }
        .wrap {
            /* 大きな画面で小さく見えたので大きめに（2026-09-14 ユーザー要望） */
            font: 16px/1.5 system-ui, "Segoe UI", "Hiragino Sans", "Meiryo", sans-serif;
            color: #f2f2f4;
            display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
        }
        .panel {
            /*
             * 縦はできるだけ長く取る（ユーザー要望）。ただし上に伸ばしすぎると
             * 右上のパネル（ルームの操作）に重なるので、そこまでで止める。
             * このチャット欄の下端は画面下から 96px にある（上の :host）。
             *
             * --wp-top-reserve は、画面の上からパネルの下端までの高さ（ui.js が実際に測って入れる）。
             * 以前は「状態表示は4行で約90px」と決め打ちしていたが、パネルに操作ボタンと
             * 参加者一覧が入って背が伸び、**チャット欄の下に隠れて押せなくなった**（2026-09-13）。
             */
            width: 360px;
            /* 上の操作パネルとは重ねない（狭いウィンドウでは低くなる。パネルを畳めば伸びる） */
            height: calc(100vh - 96px - var(--wp-top-reserve, 190px) - 16px);
            display: flex; flex-direction: column;
            /* 映像が見えるよう、ほぼ透明にする（ゲストの PC と同じ。2026-09-14 ユーザー要望）。字は影で読めるようにする */
            background: rgba(0,0,0,.18);
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 12px;
            text-shadow: 0 0 3px #000, 0 1px 2px #000, 0 0 6px rgba(0,0,0,.8);
            overflow: hidden;
        }
        .panel[hidden] { display: none; }
        .head {
            display: flex; align-items: center; gap: 8px;
            padding: 8px 10px; border-bottom: 1px solid rgba(255,255,255,.1);
            font-weight: 600;
        }
        .head .title { flex: 1; }
        .head .count { font-weight: 400; color: #e0e0e6; font-size: 14px; }
        .icon-btn {
            all: unset; cursor: pointer; width: 24px; height: 24px; border-radius: 6px;
            display: grid; place-items: center; color: #d6d6de; font-size: 16px;
            touch-action: manipulation;
        }
        .msgs {
            flex: 1; overflow-y: auto; padding: 8px 10px;
            display: flex; flex-direction: column; gap: 6px;
            min-height: 60px;
            /* 指で流したときに、ページごと動いたり引っぱって再読み込みされたりしないように */
            touch-action: pan-y; overscroll-behavior: contain;
        }
        .msg { word-break: break-word; }
        .msg .name { font-weight: 700; margin-right: 6px; }
        .msg.me .body { background: rgba(58,109,240,.35); border-radius: 6px; padding: 1px 5px; }
        .msg.system { color: #9d9da8; font-size: 12px; text-align: center; }
        /* 入退出などのお知らせは、チャットの流れに混ぜず、この1行を上書きして出す（2026-09-14 ユーザー要望） */
        .notice { flex: none; margin: 6px 10px 0; padding: 2px 8px; border-radius: 6px; font-size: 14px; color: #ffd98a;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; background: rgba(255,255,255,.08); }
        .notice.fresh { animation: wpfresh 1.2s ease-out; }
        @keyframes wpfresh { from { background: rgba(255,204,51,.45); } to { background: rgba(255,255,255,.08); } }
        .msg.big .body { font-size: 28px; line-height: 1.2; }
        .empty { color: #8c8c96; font-size: 12px; text-align: center; margin: auto 0; }
        form { display: flex; gap: 6px; padding: 8px; }
        input {
            all: unset; flex: 1; min-width: 0;
            background: rgba(20,20,26,.55); border-radius: 8px;
            padding: 9px 12px; color: #fff; font-size: 16px; text-shadow: none;
        }
        input::placeholder { color: #9d9da8; }
        .send {
            all: unset; cursor: pointer; padding: 7px 12px; border-radius: 8px;
            background: #3a6df0; color: #fff; font-weight: 600; font-size: 15px; text-shadow: none;
            touch-action: manipulation;
        }
        .bubble {
            all: unset; cursor: pointer; position: relative;
            width: 46px; height: 46px; border-radius: 50%;
            display: grid; place-items: center; font-size: 22px;
            background: rgba(16,16,20,.82); border: 1px solid rgba(255,255,255,.18);
            box-shadow: 0 4px 16px rgba(0,0,0,.4);
            touch-action: manipulation;
        }
        .bubble[hidden] { display: none; }
        .badge {
            position: absolute; top: -4px; right: -4px; min-width: 18px; height: 18px;
            padding: 0 5px; border-radius: 9px; background: #e5484d; color: #fff;
            font-size: 11px; font-weight: 700; display: grid; place-items: center;
        }
        .badge[hidden] { display: none; }
        .toasts { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; }
        .toast {
            max-width: 280px; padding: 6px 10px; border-radius: 10px;
            background: rgba(16,16,20,.82); border: 1px solid rgba(255,255,255,.14);
            animation: in .18s ease-out;
        }
        .toast .name { font-weight: 700; margin-right: 6px; }
        .toast.out { opacity: 0; transition: opacity .4s; }
        @keyframes in { from { transform: translateY(6px); opacity: 0; } to { transform: none; opacity: 1; } }

        /*
         * 指で触る画面。ボタンが小さいと押せないので大きくする。
         * 入力欄の文字が 16px 未満だと、触った瞬間にブラウザが画面を拡大してしまう。
         */
        @media (pointer: coarse) {
            .icon-btn { width: 36px; height: 36px; font-size: 20px; }
            form { gap: 8px; }
            input { font-size: 16px; padding: 9px 12px; }
            .send { padding: 9px 14px; font-size: 15px; }
            .bubble { width: 54px; height: 54px; font-size: 26px; }
            .badge { min-width: 20px; height: 20px; border-radius: 10px; font-size: 12px; }
        }

        /* 触る画面では :hover が押したまま残るので、マウスのある画面だけに出す */
        @media (hover: hover) {
            .icon-btn:hover { background: rgba(255,255,255,.12); }
            .send:hover { background: #4b7cff; }
        }

        /*
         * 狭い画面（スマホ）。パソコンの見た目のままだと、スマホの横向き（高さ360px程度）では
         * パネルが画面からはみ出し、下端 150px と合わせて置き場所が無くなる。
         *   - 下端を 76px まで上げる（スマホのプレイヤーの操作列はパソコンより低い）
         *   - 高さは画面の割合で決める。dvh はブラウザの上下のバーを除いた実際の高さ
         *   - キーボードが出たら --wp-kb の分だけ持ち上げる（入力欄が隠れる）
         *   - backdrop-filter は再生しながらだと重いので、狭い画面では使わず背景を濃くする
         *
         * 幅・高さは vw / dvh ではなく --wp-vw / --wp-vh（実際に見えている大きさ）で決める。
         * ページが固定幅の viewport を宣言していると vw が画面の幅と一致しないため。
         */
        :host([data-compact]) {
            right: calc(8px + env(safe-area-inset-right, 0px));
            bottom: calc(76px + env(safe-area-inset-bottom, 0px) + var(--wp-kb, 0px));
        }
        :host([data-compact]) .wrap { gap: 6px; }
        :host([data-compact]) .panel {
            width: min(300px, calc(var(--wp-vw, 100vw) - 16px));
            height: auto;
            min-height: 0;
            max-height: min(calc(var(--wp-vh, 100vh) * 0.56), 420px);
            background: rgba(16,16,20,.88);
            border-color: rgba(255,255,255,.14);
            text-shadow: none;
        }
        :host([data-compact]) .wrap { font-size: 13px; line-height: 1.45; }
        :host([data-compact]) .msg.big .body { font-size: 22px; }
        :host([data-compact]) .notice { font-size: 12px; }
        :host([data-compact]) .msgs { min-height: 0; }
        :host([data-compact]) .head { padding: 6px 8px; }
        :host([data-compact]) .toast { max-width: min(260px, calc(var(--wp-vw, 100vw) - 24px)); }
    `;

    class Chat {
        /**
         * @param {{ onSend: (text: string) => void,
         *           onToggle?: (open: boolean) => void,
         *           onPopout?: () => void }} opts
         */
        constructor(opts) {
            this.onSend = opts.onSend;
            this.onToggle = opts.onToggle || (() => {});
            this.onPopout = opts.onPopout || (() => {});
            this.host = null;
            this.el = {};
            this.open = true;
            this.unread = 0;
            this.selfId = null;
            this.count = 0;
        }

        mount() {
            if (this.host) return this.host;
            const host = document.createElement('div');
            host.id = HOST_ID;
            // 置き場所と大きさは STYLE の :host で決める（画面の狭さで変わるため）
            // クリック・タッチ・ホイールがプレイヤーに伝わると再生/停止や音量が変わる（全画面時）。
            // スマホのプレイヤーは touch で再生/停止するので、click とは別に止める必要がある
            for (const t of ['click', 'dblclick', 'mousedown', 'mouseup', 'pointerdown', 'pointerup',
                             'touchstart', 'touchend', 'touchmove', 'wheel', 'contextmenu']) {
                host.addEventListener(t, (e) => e.stopPropagation());
            }
            const root = host.attachShadow({ mode: 'open' });
            root.innerHTML = `
                <style>${STYLE}</style>
                <div class="wrap">
                    <div class="toasts"></div>
                    <div class="panel">
                        <div class="head">
                            <span class="title">チャット</span>
                            <span class="count"></span>
                            <button class="icon-btn popout" title="別のウィンドウで開く" aria-label="別のウィンドウで開く">⧉</button>
                            <button class="icon-btn close" title="小さくする" aria-label="小さくする">－</button>
                        </div>
                        <div class="notice" hidden></div>
                        <div class="msgs"><div class="empty">まだメッセージはありません</div></div>
                        <form>
                            <input maxlength="500" placeholder="メッセージを入力（Enterで送信）" autocomplete="off">
                            <button class="send" type="submit">送信</button>
                        </form>
                    </div>
                    <button class="bubble" title="チャットを開く" aria-label="チャットを開く" hidden>💬<span class="badge" hidden></span></button>
                </div>`;

            this.el = {
                panel: root.querySelector('.panel'),
                msgs: root.querySelector('.msgs'),
                notice: root.querySelector('.notice'),
                count: root.querySelector('.count'),
                input: root.querySelector('input'),
                form: root.querySelector('form'),
                bubble: root.querySelector('.bubble'),
                badge: root.querySelector('.badge'),
                toasts: root.querySelector('.toasts')
            };

            // Enter での送信はフォームの送信として受ける。キー入力そのものは keyguard.js が
            // プレイヤーに渡らないよう止めているので、keydown では拾えない
            this.el.form.addEventListener('submit', (e) => {
                e.preventDefault();
                const text = this.el.input.value.trim();
                if (!text) return;
                this.onSend(text);
                this.el.input.value = '';
            });
            root.querySelector('.close').addEventListener('click', () => this.setOpen(false));
            // 別ウィンドウへ出したら、重なっているほうは畳む（二重に出しても邪魔なだけ）
            root.querySelector('.popout').addEventListener('click', () => {
                this.onPopout();
                this.setOpen(false, true);
            });
            this.el.bubble.addEventListener('click', () => this.setOpen(true));
            this.keepControlsAlive(root);

            this.host = host;
            this.watchViewport();
            // 全画面の間は ui.js の placeHosts が全画面の要素の中へ移し替える
            document.documentElement.appendChild(host);
            // 初期表示は人の操作ではないので覚えさせない。
            // 覚えさせると、畳んだまま開き直したときに「開いた」で上書きされてしまう
            this.setOpen(this.open, true);
            return host;
        }

        /*
         * チャット欄の上にマウスがある間も、プレイヤーに「マウスが動いている」と伝える（2026-09-16 ユーザー報告）。
         * Prime / Netflix は、しばらくマウスが動かないと操作バー（字幕・全画面など）を自分で隠す。
         * 右上のボタンへ動かす途中でこのチャット欄の上に入ると、プレイヤーには動きが届かず、
         * **押す直前にボタンが消えて押せなかった**（Brave のホストで発生）。
         * ここでは、こちらの上でマウスが動いたことを、映像の真ん中の位置としてページへ知らせるだけ（押す操作は送らない）。
         */
        keepControlsAlive(root) {
            let last = 0;
            const forward = () => {
                const now = Date.now();
                if (now - last < 300) return;      // 送りすぎない
                last = now;
                const videos = Array.from(document.querySelectorAll('video'))
                    .filter(v => Number.isFinite(v.duration) && v.duration >= 300);
                const v = videos.length ? videos.reduce((a, b) => (b.duration > a.duration ? b : a)) : null;
                const r = v && v.getBoundingClientRect();
                if (!r || r.width < 50 || r.height < 50) return;
                const x = Math.round(r.left + r.width / 2);
                const y = Math.round(r.top + r.height / 2);
                for (const type of ['mousemove', 'pointermove']) {
                    v.dispatchEvent(new MouseEvent(type, { bubbles: true, composed: true, clientX: x, clientY: y }));
                }
            };
            for (const type of ['mousemove', 'pointermove']) {
                root.addEventListener(type, forward, { passive: true });
            }
        }

        /** 狭い画面（スマホ）かどうか。判定は protocol.js に置いてある */
        isCompact() {
            return globalThis.WP.isCompact();
        }

        /**
         * 画面の大きさに合わせて、置き場所と大きさの手掛かりを host 要素に書く。
         * CSS からは属性（data-compact）と変数（--wp-vw / --wp-vh / --wp-kb）として見える。
         *
         * --wp-kb はスマホのキーボードで隠れた高さ。position:fixed の下端は
         * 隠れた分を数えてくれないので、その分だけ持ち上げないと入力欄が見えなくなる。
         * 今どこまで見えているかは visualViewport が持っている。
         */
        watchViewport() {
            if (!this.host) return;
            const vv = globalThis.visualViewport;
            const update = () => {
                const w = vv ? vv.width : globalThis.innerWidth;
                const h = vv ? vv.height : globalThis.innerHeight;
                const hidden = vv ? Math.max(0, globalThis.innerHeight - vv.height - vv.offsetTop) : 0;
                const s = this.host.style;
                s.setProperty('--wp-vw', w + 'px');
                s.setProperty('--wp-vh', h + 'px');
                // 数 px のずれはブラウザのバーの出入りなので無視する（キーボードは 150px 以上ある）
                s.setProperty('--wp-kb', (hidden > 80 ? hidden : 0) + 'px');
                if (this.isCompact()) this.host.setAttribute('data-compact', '');
                else this.host.removeAttribute('data-compact');
            };
            vv?.addEventListener('resize', update);
            vv?.addEventListener('scroll', update);
            globalThis.addEventListener('resize', update);
            globalThis.addEventListener('orientationchange', update);
            update();
        }

        setVisible(visible) {
            if (this.host) this.host.style.display = visible ? '' : 'none';
        }

        setSelf(id) { this.selfId = id; }

        setParticipants(n) {
            if (this.el.count) this.el.count.textContent = n ? `${n}人` : '';
        }

        /**
         * @param {boolean} open
         * @param {boolean} [silent] 人が押したのではない開閉（スマホの初期表示など）。
         *                           覚えさせない（次にパソコンで開いたときに畳まれないように）
         */
        setOpen(open, silent) {
            this.open = open;
            if (!this.host) return;
            this.el.panel.hidden = !open;
            this.el.bubble.hidden = open;
            if (open) {
                this.unread = 0;
                this.el.badge.hidden = true;
                this.el.toasts.textContent = '';
                this.scrollToEnd();
            }
            if (!silent) this.onToggle(open);
        }

        /** これまでのメッセージをまとめて入れる（ページを開いた時） */
        setHistory(list) {
            this.el.msgs.textContent = '';
            this.count = 0;
            this.el.notice.hidden = true;
            for (const m of list || []) this.append(m, false);
            if (this.count === 0) this.showEmpty();
            this.scrollToEnd();
        }

        /** 新しく届いたメッセージ */
        add(m) {
            if (m.type !== 'system') this.el.msgs.querySelector('.empty')?.remove();
            const nearEnd = this.el.msgs.scrollHeight - this.el.msgs.scrollTop - this.el.msgs.clientHeight < 40;
            this.append(m);
            if (nearEnd || m.senderId === this.selfId) this.scrollToEnd();
            if (!this.open && m.type === 'user') {
                this.unread++;
                this.el.badge.textContent = this.unread > 99 ? '99+' : String(this.unread);
                this.el.badge.hidden = false;
                this.toast(m);
            }
        }

        append(m, flash = true) {
            if (m.type === 'system') {
                showNotice(this.el.notice, m.content, flash);
                return;
            }
            const row = document.createElement('div');
            row.className = 'msg' + (m.senderId === this.selfId ? ' me' : '') +
                (isReaction(m.content) ? ' big' : '');
            const name = document.createElement('span');
            name.className = 'name';
            name.textContent = displayName(m);
            name.style.color = safeColor(m.color);
            const body = document.createElement('span');
            body.className = 'body';
            body.textContent = m.content;
            row.append(name, body);
            this.el.msgs.appendChild(row);
            this.count++;
            while (this.el.msgs.children.length > MAX_SHOWN) this.el.msgs.firstChild.remove();
        }

        showEmpty() {
            const e = document.createElement('div');
            e.className = 'empty';
            e.textContent = 'まだメッセージはありません';
            this.el.msgs.appendChild(e);
        }

        toast(m) {
            const t = document.createElement('div');
            t.className = 'toast';
            const name = document.createElement('span');
            name.className = 'name';
            name.textContent = displayName(m);
            name.style.color = safeColor(m.color);
            const body = document.createElement('span');
            body.textContent = m.content.length > 80 ? m.content.slice(0, 80) + '…' : m.content;
            t.append(name, body);
            this.el.toasts.appendChild(t);
            while (this.el.toasts.children.length > 3) this.el.toasts.firstChild.remove();
            setTimeout(() => {
                t.classList.add('out');
                setTimeout(() => t.remove(), 400);
            }, TOAST_MS);
        }

        scrollToEnd() {
            if (this.el.msgs) this.el.msgs.scrollTop = this.el.msgs.scrollHeight;
        }
    }

    /** 絵文字だけのメッセージは大きく出す */
    function isReaction(s) {
        // 絵文字の後ろに続く ZWJ（U+200D）と異体字セレクタ（U+FE0F）も許す（❤\uFE0F など）
        return typeof s === 'string' && s.length <= 8 &&
            /^\p{Extended_Pictographic}[\p{Extended_Pictographic}\u200D\uFE0F]*$/u.test(s);
    }

    /** サーバーから来た色は #RRGGBB だけ受け付ける（style に入れるため） */
    /** 表示する名前。ホストの発言（サーバーの判定）だけ 👑 を付け、名前に入った王冠の記号は消す（なりすまし防止） */
    /** 入退出などのお知らせは、チャットの流れに混ぜず、この1行を上書きして出す（2026-09-14 ユーザー要望）。文字は textContent でしか入れない */
    function showNotice(el, content, flash) {
        el.textContent = typeof content === 'string' ? content.slice(0, 200) : '';
        el.title = el.textContent;
        el.hidden = !el.textContent;
        el.classList.remove('fresh');
        if (flash) { void el.offsetWidth; el.classList.add('fresh'); }
    }

    function displayName(m) {
        const name = (typeof m.username === 'string' ? m.username : '').replace(/[👑♔♕♚♛🪅]/gu, '').slice(0, 20) || '？';
        return m.isHost === true ? '👑 ' + name : name;
    }

    function safeColor(c) {
        return typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c) ? c : '#cfd3ff';
    }

    globalThis.WPChat = Chat;
    globalThis.WPChat.HOST_ID = HOST_ID;
})();
